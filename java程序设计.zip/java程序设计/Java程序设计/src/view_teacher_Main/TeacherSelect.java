package view_teacher_Main;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.util.List;

import javax.swing.JTextArea;

import model.Teacher;
import dao.TeacherDao;
import View_main.DenLu;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class TeacherSelect extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_6;

	/**
	 * Create the panel.
	 */
	public TeacherSelect() {
		setLayout(null);
		DenLu d =new DenLu();
		String teacherNo=d.getId();
		TeacherDao td =new TeacherDao();
		List<Teacher> list = td.queryAll(teacherNo);
		Teacher t =list.get(0);
		
		JLabel label = new JLabel("\u5DE5\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(205, 14, 72, 18);
		add(label);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 18));
		textField.setText(t.getTeacherNo());
		textField.setEditable(false);
		textField.setBounds(269, 13, 174, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(537, 16, 72, 18);
		add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("����", Font.PLAIN, 18));
		textField_1.setText(t.getTeacherName());
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(605, 13, 174, 24);
		add(textField_1);
		
		JLabel label_2 = new JLabel("\u5E74\u9F84");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(205, 135, 72, 18);
		add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("����", Font.PLAIN, 18));
		textField_2.setText(String.valueOf(t.getTeacherAge()));
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(269, 129, 174, 24);
		add(textField_2);
		
		JLabel label_3 = new JLabel("\u6027\u522B");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(537, 135, 72, 18);
		add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("����", Font.PLAIN, 18));
		textField_3.setText(t.getTeacherSex());
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(605, 129, 174, 24);
		add(textField_3);
		
		JLabel label_4 = new JLabel("\u624B\u673A\u53F7");
		label_4.setFont(new Font("����", Font.PLAIN, 18));
		label_4.setBounds(32, 220, 72, 18);
		add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("����", Font.PLAIN, 18));
		textField_4.setText(t.getMobileNum());
		textField_4.setEditable(false);
		textField_4.setColumns(10);
		textField_4.setBounds(113, 219, 174, 24);
		add(textField_4);
		
		JLabel label_5 = new JLabel("\u6587\u51ED");
		label_5.setFont(new Font("����", Font.PLAIN, 18));
		label_5.setBounds(537, 220, 72, 18);
		add(label_5);
		
		JLabel label_6 = new JLabel("\u5DE5\u4F5C\u7ECF\u9A8C");
		label_6.setFont(new Font("����", Font.PLAIN, 18));
		label_6.setBounds(256, 282, 72, 18);
		add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("����", Font.PLAIN, 18));
		textField_6.setText(String.valueOf(t.getTeacherWork()));
		textField_6.setEditable(false);
		textField_6.setColumns(10);
		textField_6.setBounds(373, 281, 174, 24);
		add(textField_6);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 15));
		textArea.setText(t.getTeacherMess());;
		textArea.setEditable(false);
		textArea.setBounds(32, 379, 817, 82);
		add(textArea);
		
		JLabel label_7 = new JLabel("\u4E2A\u6027\u7B7E\u540D");
		label_7.setFont(new Font("����", Font.PLAIN, 18));
		label_7.setBounds(32, 348, 72, 18);
		add(label_7);
		
		JLabel label_8 = new JLabel("\u5E74");
		label_8.setFont(new Font("����", Font.PLAIN, 18));
		label_8.setBounds(561, 282, 72, 18);
		add(label_8);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon(t.getTeacherToxiang()));
		btnNewButton.setBounds(32, 16, 113, 122);
		add(btnNewButton);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setEnabled(false);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u4E13\u79D1", "\u672C\u79D1", "\u7814\u7A76\u751F", "\u7855\u58EB", "\u535A\u58EB", "\u535A\u58EB\u540E"}));
		comboBox.setBounds(605, 219, 174, 24);
		add(comboBox);
		comboBox.setSelectedItem(t.getTeacherWen());
		

	}
}
