package view_teacher_Main;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JButton;

import dao.StudentDao;
import dao.TeacherDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPasswordField;

import View_main.DenLu;

public class TeacherPasswd extends JPanel {
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JPasswordField passwordField_2;

	/**
	 * Create the panel.
	 */
	public TeacherPasswd() {
		setLayout(null);

		JLabel label = new JLabel("\u6B22\u8FCE\u4F7F\u7528\u540D\u5E08\u4FEE\u6539\u5BC6\u7801");
		label.setForeground(Color.RED);
		label.setFont(new Font("����", Font.PLAIN, 30));
		label.setBounds(286, 13, 346, 38);
		add(label);

		JLabel lblNewLabel = new JLabel("\u65E7\u5BC6\u7801");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(203, 78, 72, 30);
		add(lblNewLabel);

		JLabel label_1 = new JLabel("\u65B0\u5BC6\u7801");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(203, 150, 72, 18);
		add(label_1);

		JLabel label_2 = new JLabel("\u786E\u8BA4\u65B0\u5BC6\u7801");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(203, 220, 110, 18);
		add(label_2);

		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(passwordField.getText().equals("")){
					JOptionPane.showMessageDialog(null,"�������������");
					return;
				}
				DenLu d =new DenLu();
				String teacherNo=d.getId();
				TeacherDao td =new TeacherDao();
				String k = null;
				try {
					k = td.toxiang(teacherNo,passwordField.getText());
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
				if(!k.equals("")){
					if(passwordField_1.getText().equals(passwordField_2.getText()) &&!passwordField_1.getText().equals("") 
							&& !passwordField_2.getText().equals("")&& passwordField_1.getText().length()>=6&& passwordField_2.getText().length()>=6
							&& passwordField_2.getText().length()<=12&& passwordField_1.getText().length()<=12){
						int j=td.updatepasswd_ft(teacherNo,passwordField_1.getText());
						if(j>0){
							JOptionPane.showMessageDialog(null,"�޸ĳɹ�");
							passwordField_1.setText("");
							passwordField_2.setText("");
							passwordField.setText("");
						}
						else{
							JOptionPane.showMessageDialog(null,"ʧ�ܣ�δ֪����");
						}
					}
					else{
						JOptionPane.showMessageDialog(null,"�������벻һ�»򳤶�С��6λ����12λ������Ϊ��");
					}

				}
				else{
					JOptionPane.showMessageDialog(null,"Ȩ�������ѧ�Ŵ���");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(376, 350, 113, 27);
		add(button);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(338, 83, 269, 24);
		add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(338, 149, 269, 24);
		add(passwordField_1);
		
		passwordField_2 = new JPasswordField();
		passwordField_2.setBounds(338, 219, 269, 24);
		add(passwordField_2);

	}
}
