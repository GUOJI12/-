package view_teacher;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;

import java.awt.Color;

import javax.swing.JTable;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JRadioButton;
import javax.swing.table.DefaultTableModel;

import model.Teacher;
import dao.TeacherDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateTeacher extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTable table;
	private JTextField textField_5;
	String teacherNo;
	String teacherName;
	int teacherAge;
	String teacherSex;
	String teacherPasswd;
	JRadioButton rdbtnNewRadioButton,radioButton;
	DefaultTableModel tablemodel;
	/**
	 * Create the panel.
	 */
	public UpdateTeacher() {
		setLayout(null);
		
		JLabel label = new JLabel("\u5DE5\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(57, 36, 72, 24);
		add(label);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(57, 111, 72, 24);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u5E74\u9F84");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(57, 181, 72, 24);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u6027\u522B");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(485, 41, 72, 24);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u5BC6\u7801");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(485, 116, 72, 24);
		add(label_4);
		
		textField = new JTextField();
		textField.setBounds(138, 38, 210, 24);
		add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				SelectTeacher st = new SelectTeacher();
				st.queryAllTeacher(tablemodel,"select * from teacher where teacherNo="+"'"+textField.getText()+"'");
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(373, 37, 78, 27);
		add(button);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(138, 113, 210, 24);
		add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(138, 183, 210, 24);
		add(textField_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(560, 113, 210, 24);
		add(textField_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 266, 821, 214);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] t ={"����","����","����","�Ա�","����"};
		tablemodel.setColumnIdentifiers(t);
		SelectTeacher st = new SelectTeacher();
		st.queryAllTeacher(tablemodel,"select * from teacher");
		table.validate();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
					//��ȡ�ı�
					int count = table.getSelectedRow();//��ȡ��������к�
					teacherNo= (String) table.getValueAt(count, 0);
					teacherName=(String) table.getValueAt(count, 1);
					teacherAge=Integer.parseInt((String) table.getValueAt(count, 2));
					teacherSex=(String) table.getValueAt(count, 3);
					teacherPasswd =(String) table.getValueAt(count, 4);
					textField.setText(teacherNo);
					textField_1.setText(teacherName);
					textField_2.setText(teacherAge+"");
					textField_4.setText(teacherPasswd);
					if(teacherSex.equals("��")){
						rdbtnNewRadioButton.setSelected(true);
						radioButton.setSelected(false);
					}else if(teacherSex.equals("Ů")){
						radioButton.setSelected(true);
						rdbtnNewRadioButton.setSelected(false);
					}
			}
		});
		scrollPane.setViewportView(table);
		
		JButton button_1 = new JButton("\u786E\u8BA4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!textField.getText().equals(teacherNo)){
					JOptionPane.showMessageDialog(null,"ʧ��(���Ų����޸�)");
					textField.setText(teacherNo);
					return;
				}
				if(Integer.valueOf(textField_2.getText())<0||Integer.valueOf(textField_2.getText())>80){
					JOptionPane.showMessageDialog(null,"ʧ��(������Ϣ����ȷ(0--80֮��))");
					return;
				}
				TeacherDao td= new TeacherDao();
				Teacher t =new Teacher();
				t.setTeacherNo(textField.getText());
				t.setTeacherName(textField_1.getText());
				t.setTeacherAge(Integer.valueOf(textField_2.getText()));
				if(rdbtnNewRadioButton.isSelected()){
					t.setTeacherSex("��");
				}else if(radioButton.isSelected()){
					t.setTeacherSex("Ů");
				}				
				t.setTeacherPasswd(textField_4.getText());
				int k=td.update(t);
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectTeacher st = new SelectTeacher();
					st.queryAllTeacher(tablemodel,"select * from teacher");
					table.validate();
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
				}
				else{
					JOptionPane.showMessageDialog(null,"ʧ��");
				}
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(444, 226, 113, 27);
		add(button_1);
		
		JLabel label_5 = new JLabel("*\u6CE8:\u53EF\u9009\u62E9\u4E0B\u9762\u8868\u683C\u91CC\u7684\u5185\u5BB9\uFF0C\u4E5F\u53EF\u4EE5\u67E5\u627E\u5185\u5BB9");
		label_5.setForeground(Color.RED);
		label_5.setBounds(29, 235, 358, 18);
		add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setForeground(Color.RED);
		textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
		textField_5.setFont(new Font("����", Font.PLAIN, 18));
		textField_5.setEditable(false);
		textField_5.setBounds(766, 478, 86, 24);
		add(textField_5);
		textField_5.setColumns(10);
		
		 rdbtnNewRadioButton = new JRadioButton("\u7537");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(rdbtnNewRadioButton.isSelected()){
					radioButton.setSelected(false);
				}
			}
		});
		rdbtnNewRadioButton.setBounds(585, 37, 61, 27);
		add(rdbtnNewRadioButton);
		
		radioButton = new JRadioButton("\u5973");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if(radioButton.isSelected()){
					rdbtnNewRadioButton.setSelected(false);
				}
			
			}
		});
		radioButton.setBounds(709, 37, 61, 27);
		add(radioButton);

	}
}
