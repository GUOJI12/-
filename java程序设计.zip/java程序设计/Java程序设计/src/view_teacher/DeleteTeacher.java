package view_teacher;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import view_student.SelectStudent;
import dao.TeacherDao;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;

import javax.swing.JRadioButton;

import model.Teacher;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class DeleteTeacher extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	private JTextField textField_4;
	DefaultTableModel tablemodel;
	JRadioButton radioButton,radioButton_1;
	String file_print;
	/**
	 * Create the panel.
	 */
	public DeleteTeacher() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5DE5\u53F7");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(56, 41, 54, 24);
		add(lblNewLabel);
		
		JLabel label = new JLabel("\u59D3\u540D");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(56, 104, 54, 24);
		add(label);
		
		JLabel label_1 = new JLabel("\u5E74\u9F84");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(484, 104, 54, 24);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u6027\u522B");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(484, 41, 54, 24);
		add(label_2);
		
		textField = new JTextField();
		textField.setBounds(149, 43, 186, 24);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(149, 106, 186, 24);
		add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(570, 106, 186, 24);
		add(textField_2);
		
		JButton button = new JButton("\u5220\u9664");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TeacherDao td =new TeacherDao();
				int k=td.deleteId(textField.getText());
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectTeacher sst = new SelectTeacher();
					sst.queryAllTeacher(tablemodel,"select * from teacher");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(358, 40, 80, 27);
		add(button);
		
		JButton button_1 = new JButton("\u5220\u9664");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TeacherDao td =new TeacherDao();
				int k=td.deleteName(textField_1.getText());
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectTeacher sst = new SelectTeacher();
					sst.queryAllTeacher(tablemodel,"select * from teacher");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��");
				}
			
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(358, 105, 80, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u5220\u9664");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TeacherDao td =new TeacherDao();
				int k=0;
				if(radioButton.isSelected()){
					k=td.deleteSex("��");
				}else if(radioButton_1.isSelected()){
					k=td.deleteSex("Ů");
				}
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectTeacher sst = new SelectTeacher();
					sst.queryAllTeacher(tablemodel,"select * from teacher");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��");
				}
			
			
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(788, 42, 80, 27);
		add(button_2);
		
		JButton button_3 = new JButton("\u5220\u9664");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				TeacherDao td =new TeacherDao();
				int k=td.deleteAge(Integer.valueOf(textField_2.getText()));
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectTeacher sst = new SelectTeacher();
					sst.queryAllTeacher(tablemodel,"select * from teacher");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��");
				}
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(788, 105, 80, 27);
		add(button_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 203, 833, 274);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] t ={"����","����","����","�Ա�","����"};
		tablemodel.setColumnIdentifiers(t);
		SelectTeacher sst = new SelectTeacher();
		sst.queryAllTeacher(tablemodel,"select * from teacher");
		table.validate();
		scrollPane.setViewportView(table);
		
		textField_4 = new JTextField();
		textField_4.setForeground(Color.RED);
		textField_4.setFont(new Font("����", Font.PLAIN, 18));
		textField_4.setEditable(false);
		textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
		textField_4.setBounds(782, 477, 86, 24);
		add(textField_4);
		textField_4.setColumns(10);
		
		JLabel label_3 = new JLabel("\u9009\u62E9\u4F4D\u7F6E");
		label_3.setBounds(296, 157, 72, 18);
		add(label_3);
		
		final JButton btnNewButton = new JButton("\u6587\u4EF6");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					System.out.println("��");
					JFileChooser jfc = new JFileChooser();
					jfc.setDialogTitle("��ѡ���ļ�");
					jfc.showOpenDialog(null);
					jfc.setVisible(true);
					//��ȡ�û���ѡ��Ķ����ļ�
					File file =jfc.getSelectedFile();
					String s = file.toString();
					s=s.replace("\\","\\\\");
					file_print=s;
					btnNewButton.setText(file_print);
			}
		});
		btnNewButton.setBounds(404, 153, 186, 27);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u5BFC\u51FA/\u5907\u4EFD");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					if(file_print.equals("")){
						JOptionPane.showMessageDialog(null,"��ѡ���ļ�");
					}
					try
					{
						//���ļ�
						WritableWorkbook book=
						Workbook.createWorkbook(new File(file_print+".xls"));
						//������Ϊ����һҳ���Ĺ�����������0��ʾ���ǵ�һҳ
						WritableSheet sheet=book.createSheet("��һҳ",0);
						//��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
						//�Լ���Ԫ������Ϊtest
						String[] ss = {"����","����","����","�Ա�","����","ͷ��"};
						for(int i=0;i<ss.length;i++){
							Label label=new Label(i,0,ss[i]);
							sheet.addCell(label);
						}
						for(int i=1;i<tablemodel.getRowCount()+1;i++){
							for(int j=0;j<ss.length-1;j++){
								Label label=new Label(j,i,(String) table.getValueAt(i-1,j));
								//������õĵ�Ԫ�����ӵ���������
								sheet.addCell(label);
							}
						}
						for(int i=1;i<tablemodel.getRowCount()+1;i++){
							    TeacherDao td =new TeacherDao();
							    List<Teacher> let =  td.queryAll((String)table.getValueAt(i-1,0));
							    System.out.println(let.size());
							    Teacher t =let.get(0);
								Label label=new Label(5,i,t.getTeacherToxiang());
								//������õĵ�Ԫ�����ӵ���������
								sheet.addCell(label);
						}
						
						//д�����ݲ��ر��ļ�
						JOptionPane.showMessageDialog(null,"�ɹ�");
						book.write();
						book.close();
					}catch(Exception e)
					{
						System.out.println(e);
					}
			}
		});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton_1.setBounds(628, 153, 149, 27);
		add(btnNewButton_1);
		
		 radioButton = new JRadioButton("\u7537");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					radioButton_1.setSelected(false);
				}
			}
		});
		radioButton.setSelected(true);
		radioButton.setBounds(548, 42, 61, 27);
		add(radioButton);
		
		radioButton_1 = new JRadioButton("\u5973");
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton_1.isSelected()){
					radioButton.setSelected(false);
				}
			
			}
		});
		radioButton_1.setBounds(684, 42, 61, 27);
		add(radioButton_1);

	}

}
