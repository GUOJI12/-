package view_teacher;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import view_student.SelectStudent;
import model.Student;
import model.Teacher;
import dao.StudentDao;
import dao.TeacherDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import java.awt.Color;

public class AddTeacher extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table;
	String teacher_p;
	DefaultTableModel tablemodel;
	JRadioButton radioButton,radioButton_1;
	/**
	 * Create the panel.
	 */
	public AddTeacher() {
		setLayout(null);
		
		JLabel label = new JLabel("\u5DE5\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(93, 58, 49, 24);
		add(label);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(93, 118, 49, 24);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u5E74\u9F84");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(93, 185, 49, 24);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u6027\u522B");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(483, 58, 49, 24);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u5BC6\u7801");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(483, 118, 49, 24);
		add(label_4);
		
		textField = new JTextField();
		textField.setBounds(170, 60, 231, 24);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(170, 120, 231, 24);
		add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(170, 187, 231, 24);
		add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setText("456789");
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(546, 115, 231, 24);
		add(textField_3);
		
		radioButton = new JRadioButton("\u7537");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					radioButton_1.setSelected(false);
				}
			}
		});
		radioButton.setSelected(true);
		radioButton.setBounds(563, 59, 62, 27);
		add(radioButton);
		
		radioButton_1 = new JRadioButton("\u5973");
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton_1.isSelected()){
					radioButton.setSelected(false);
				}
			
			}
		});
		radioButton_1.setBounds(700, 59, 62, 27);
		add(radioButton_1);
		
		JButton button = new JButton("\u5BFC\u5165\u6DFB\u52A0");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("��");
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("��ѡ���ļ�");
				jfc.showOpenDialog(null);
				jfc.setVisible(true);
				//��ȡ�û���ѡ��Ķ����ļ�
				File file =jfc.getSelectedFile();
				String s1 = file.toString();
				s1=s1.replace("\\","\\\\");
				teacher_p=s1;
			File file1 = new File(teacher_p);
			int k=0;
			int s2=0;
			try {		
				String[][] add = readColumn(file,6);
				System.out.println(add[0][1]);
				for(int i=1;i<add.length;i++){
					    TeacherDao sd = new TeacherDao();
					    Teacher t = new Teacher();
					    t.setTeacherNo(add[i][0]);
					    t.setTeacherName(add[i][1]);
					    t.setTeacherAge(Integer.valueOf(add[i][2]));
					    t.setTeacherSex(add[i][3]);
					    t.setTeacherPasswd(add[i][4]);
					    t.setTeacherToxiang(add[i][5]);
						k=sd.add(t);
						if(k>0){
							s2=k;
						}
					}
				} 
				 catch (Exception e) {
					 e.printStackTrace();
				}
				if(s2>0){
					JOptionPane.showMessageDialog(null,"�ɹ������ܲ����������������޷������ӣ�");
					tablemodel.setRowCount(0);//������е�ԭ������
					SelectTeacher st = new SelectTeacher();
					st.queryAllTeacher(tablemodel,"select * from teacher");
					table.validate();//ˢ��
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
				}
				else{
					JOptionPane.showMessageDialog(null,"ʧ�ܣ����������޷������ӣ�");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(93, 261, 113, 27);
		add(button);
		
		JButton button_1 = new JButton("\u786E\u8BA4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField.getText().equals("")||textField_1.getText().equals("")||textField_2.getText().equals("")){
					JOptionPane.showMessageDialog(null,"ʧ�ܣ�������Ϣ��ȫ��");
					return;
				}		
				int k=0;
				TeacherDao td = new TeacherDao();
				Teacher t = new Teacher();
				t.setTeacherNo(textField.getText());
				t.setTeacherName(textField_1.getText());
				t.setTeacherAge(Integer.valueOf(textField_2.getText()));
				if(radioButton.isSelected()){
					t.setTeacherSex("��");
				}else if(radioButton_1.isSelected()){
					t.setTeacherSex("Ů");
				}
				if(Integer.valueOf(textField_2.getText())<0||Integer.valueOf(textField_2.getText())>80){
					JOptionPane.showMessageDialog(null,"ʧ��(������Ϣ����ȷ(0--80֮��))");
					return;
				}
				t.setTeacherPasswd(textField_3.getText());
				t.setTeacherToxiang("C:\\\\Users\\\\GUOJI\\\\Desktop\\\\javas\\\\xia.png");
				k=td.add(t);
			if(k>0){
				JOptionPane.showMessageDialog(null,"�ɹ�");
				SelectTeacher st = new SelectTeacher();
				st.queryAllTeacher(tablemodel,"select * from teacher");
				table.validate();//ˢ��
				textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
			else{
				JOptionPane.showMessageDialog(null,"ʧ��(���ݿ��ܴ���)");
			}
		  
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(403, 261, 113, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u91CD\u7F6E");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				radioButton_1.setSelected(false);
				radioButton.setSelected(true);
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(664, 261, 113, 27);
		add(button_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 334, 824, 152);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] t ={"����","����","����","�Ա�","����"};
		tablemodel.setColumnIdentifiers(t);
		
		SelectTeacher st = new SelectTeacher();
		st.queryAllTeacher(tablemodel,"select * from teacher");
		table.validate();
		scrollPane.setViewportView(table);
		
		textField_4 = new JTextField();
		textField_4.setForeground(Color.RED);
		textField_4.setFont(new Font("����", Font.PLAIN, 18));
		textField_4.setEditable(false);
		textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
		textField_4.setBounds(752, 486, 86, 27);
		add(textField_4);
		textField_4.setColumns(10);

	}
	public static String[][] readColumn(File file, int index) throws Exception {
		InputStream inputStream = new FileInputStream(file.getAbsoluteFile());

		// �½�����ȡ������
		Workbook workbook = Workbook.getWorkbook(inputStream);

		// ��ȡ��������index��0��ʼ��0��ӦSheet1
		Sheet sheet = workbook.getSheet(0);

		// ��ȡExcel����
		int rows = sheet.getRows();

		// ��ȡExcel����
		int columns = sheet.getColumns();
		String[][] s = new String[rows][index];
		for (int i =0; i < rows; i++) {
			// ��ȡ��Ԫ��
			for(int j=0;j<index;j++){
				Cell cell = sheet.getCell(j, i);
				// ��ȡ��Ԫ������
				s[i][j]=cell.getContents();
			}
		}
		return s;
	}

}
