package view_teacher;

import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Student;
import model.Teacher;
import dao.StudentDao;
import dao.TeacherDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.Random;
import java.awt.Color;

public class SelectTeacher extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTable table;
	DefaultTableModel tablemodel;
	JRadioButton radioButton_1,radioButton;
	/**
	 * Create the panel.
	 */
	public SelectTeacher() {
		setLayout(null);
		
		JButton btnNewButton = new JButton("\u5168\u90E8\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				queryAllTeacher(tablemodel,"select * from teacher");
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.setBounds(188, 13, 113, 27);
		add(btnNewButton);
		
		JLabel label = new JLabel("\u5DE5\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(92, 76, 57, 21);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(188, 76, 245, 24);
		add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u6309\u5DE5\u53F7\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				queryAllTeacher(tablemodel,"select * from teacher where teacherNo="+"'"+textField.getText()+"'");
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(519, 73, 160, 27);
		add(button);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(92, 126, 57, 21);
		add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(188, 126, 245, 24);
		add(textField_1);
		
		JButton button_1 = new JButton("\u6309\u59D3\u540D\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				queryAllTeacher(tablemodel,"select * from teacher where teacherName="+"'"+textField_1.getText()+"'");
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(519, 123, 160, 27);
		add(button_1);
		
		JLabel label_2 = new JLabel("\u5E74\u9F84");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(92, 171, 57, 21);
		add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(188, 171, 245, 24);
		add(textField_2);
		
		JButton button_2 = new JButton("\u6309\u5E74\u9F84\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				queryAllTeacher(tablemodel,"select * from teacher where teacherAge="+"'"+textField_2.getText()+"'");
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(519, 168, 160, 27);
		add(button_2);
		
		JLabel label_3 = new JLabel("\u6027\u522B");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(92, 222, 57, 21);
		add(label_3);
		
		JButton button_3 = new JButton("\u6309\u6027\u522B\u67E5\u8BE2");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String sex="";
				if(radioButton.isSelected()){
					sex="��";
				}else if(radioButton_1.isSelected()){
						sex="Ů";
					}
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				queryAllTeacher(tablemodel,"select * from teacher where teacherSex="+"'"+sex+"'");
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(519, 219, 160, 27);
		add(button_3);
		
		 radioButton = new JRadioButton("\u7537");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					radioButton_1.setSelected(false);
				}
			}
		});
		radioButton.setSelected(true);
		radioButton.setBounds(200, 221, 74, 27);
		add(radioButton);
		
		 radioButton_1 = new JRadioButton("\u5973");
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton_1.isSelected()){
					radioButton.setSelected(false);
				}
			
			}
		});
		radioButton_1.setBounds(358, 221, 62, 27);
		add(radioButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 276, 791, 200);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] t ={"����","����","����","�Ա�","����"};
		tablemodel.setColumnIdentifiers(t);
		table.validate();
		
		scrollPane.setViewportView(table);
		
		textField_3 = new JTextField();
		textField_3.setForeground(Color.RED);
		textField_3.setFont(new Font("����", Font.PLAIN, 18));
		textField_3.setEditable(false);
		textField_3.setBounds(701, 475, 104, 24);
		add(textField_3);
		textField_3.setColumns(10);
		
		JButton button_4 = new JButton("\u6743\u9650\u7801");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tablemodel.getRowCount()<0){
					JOptionPane.showMessageDialog(null,"���Ȳ�ѯ��ʦ");
					return;
				}
				int x=0;
				for(int tm=0;tm<tablemodel.getRowCount();tm++){
					String teacherNo =(String) table.getValueAt(tm, 0);
					TeacherDao td =new TeacherDao();
					Random r =new Random();
					int sum=0;
					for(int i=0;i<4;i++){
						sum=sum+r.nextInt(1000);
					}
					int k = td.updateq(teacherNo, sum);
					x=x+k;
					sum=0;
				}
				if(x==tablemodel.getRowCount()){
					JOptionPane.showMessageDialog(null,"�ɹ�");
				}
			}
		});
		button_4.setFont(new Font("����", Font.PLAIN, 18));
		button_4.setBounds(420, 15, 113, 27);
		add(button_4);

	}
	public static void queryAllTeacher(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		TeacherDao sd = new TeacherDao();
		List<Teacher> list = sd.query(sql);
		String[] s = new String[5];
		for(int i=0;i<list.size();i++)
		{
			Teacher teacher=list.get(i);			
			s[0] = teacher.getTeacherNo();
			s[1] = teacher.getTeacherName();
			s[2] =String.valueOf(teacher.getTeacherAge());
			s[3] = teacher.getTeacherSex();
			s[4] = teacher.getTeacherPasswd();
			tablemodel.addRow(s);
		}
	}
}
