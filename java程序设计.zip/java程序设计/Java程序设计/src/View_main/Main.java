package View_main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;

import java.awt.Font;

import javax.swing.JMenuItem;

import view_course.AddCourse;
import view_course.DeleteCourse;
import view_course.SelectCourse;
import view_course.UpdateCourse;
import view_sc.DeleteSc;
import view_sc.Delete_jieke;
import view_sc.SelectSc;
import view_sc.SelectScore;
import view_student.AddStudent_add;
import view_student.DeleteStudent;
import view_student.SelectStudent;
import view_student.UpdateStudent;
import view_teacher.AddTeacher;
import view_teacher.DeleteTeacher;
import view_teacher.SelectTeacher;
import view_teacher.UpdateTeacher;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 901, 609);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu = new JMenu("\u5B66\u751F\u4FE1\u606F\u7BA1\u7406");
		menu.setForeground(Color.RED);
		menu.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu);
		
		JMenuItem menuItem = new JMenuItem("\u67E5\u8BE2\u5B66\u751F");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new SelectStudent());
				contentPane.validate();
			}
		});
		menuItem.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem);
		
		JMenuItem menuItem_2 = new JMenuItem("\u6DFB\u52A0\u5B66\u751F");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new AddStudent_add());
				contentPane.validate();
			}
		});
		menuItem_2.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem_2);
		
		JMenuItem menuItem_3 = new JMenuItem("\u4FEE\u6539\u5B66\u751F");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new UpdateStudent());
				contentPane.validate();
			}
		});
		menuItem_3.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem_3);
		
		JMenuItem menuItem_4 = new JMenuItem("\u5220\u9664(\u5BFC\u51FA)\u5B66\u751F");
		menuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new DeleteStudent());
				contentPane.validate();
			}
		});
		menuItem_4.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem_4);
		
		JMenu menu_1 = new JMenu("\u6559\u5E08\u4FE1\u606F\u7BA1\u7406");
		menu_1.setForeground(Color.BLUE);
		menu_1.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_1);
		
		JMenuItem menuItem_5 = new JMenuItem("\u67E5\u8BE2\u6559\u5E08");
		menuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				contentPane.removeAll();
				contentPane.add(new SelectTeacher());
				contentPane.validate();
			
			}
		});
		menuItem_5.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_5);
		
		JMenuItem menuItem_1 = new JMenuItem("\u6DFB\u52A0\u6559\u5E08");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {


				contentPane.removeAll();
				contentPane.add(new AddTeacher());
				contentPane.validate();
			
			
			}
		});
		menuItem_1.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_1);
		
		JMenuItem menuItem_6 = new JMenuItem("\u4FEE\u6539\u6559\u5E08");
		menuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new UpdateTeacher());
				contentPane.validate();		
			}
		});
		menuItem_6.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_6);
		
		JMenuItem menuItem_7 = new JMenuItem("\u5220\u9664(\u5BFC\u51FA)\u6559\u5E08");
		menuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new DeleteTeacher());
				contentPane.validate();	
			}
		});
		menuItem_7.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_7);
		
		JMenu menu_2 = new JMenu("");
		menuBar.add(menu_2);
		
		JMenu menu_3 = new JMenu("\u9009\u8BFE\u4FE1\u606F\u7BA1\u7406");
		menu_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		menu_3.setForeground(Color.PINK);
		menu_3.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_3);
		
		JMenuItem menuItem_8 = new JMenuItem("\u9009\u8BFE\u4FE1\u606F\u67E5\u8BE2(\u5BFC\u51FA)");
		menuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new SelectSc());
				contentPane.validate();	
			}
		});
		menuItem_8.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_8);
		
		JMenuItem menuItem_9 = new JMenuItem("\u9000\u8BFE\u7BA1\u7406");
		menuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new DeleteSc());
				contentPane.validate();	
			}
		});
		
		JMenuItem menuItem_10 = new JMenuItem("\u6210\u7EE9\u7BA1\u7406(\u5BFC\u51FA)");
		menuItem_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new SelectScore());
				contentPane.validate();	
			}
		});
		menuItem_10.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_10);
		menuItem_9.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_9);
		
		JMenuItem menuItem_21 = new JMenuItem("\u5220\u9664\u7ED3\u8BFE\u8BFE\u7A0B");
		menuItem_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new Delete_jieke());
				contentPane.validate();
			}
		});
		menuItem_21.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_21);
		
		JMenu menu_4 = new JMenu("");
		menuBar.add(menu_4);
		
		JMenu menu_5 = new JMenu("\u8BFE\u7A0B\u4FE1\u606F\u7BA1\u7406");
		menu_5.setForeground(Color.MAGENTA);
		menu_5.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_5);
		
		JMenuItem menuItem_11 = new JMenuItem("\u67E5\u8BE2\u8BFE\u7A0B");
		menuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new SelectCourse());
				contentPane.validate();	
			}
		});
		menuItem_11.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_5.add(menuItem_11);
		
		JMenuItem menuItem_12 = new JMenuItem("\u6DFB\u52A0\u8BFE\u7A0B");
		menuItem_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new AddCourse());
				contentPane.validate();	
			
			}
		});
		menuItem_12.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_5.add(menuItem_12);
		
		JMenuItem menuItem_13 = new JMenuItem("\u4FEE\u6539\u8BFE\u7A0B");
		menuItem_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new UpdateCourse());
				contentPane.validate();	
			}
		});
		menuItem_13.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_5.add(menuItem_13);
		
		JMenuItem menuItem_14 = new JMenuItem("\u5220\u9664(\u5BFC\u51FA)\u8BFE\u7A0B");
		menuItem_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new DeleteCourse());
				contentPane.validate();	
			}
		});
		menuItem_14.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_5.add(menuItem_14);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}
}
