package View_main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import model.Course;
import model.SC;
import model.Student;
import model.ZuoYe;
import dao.CourseDao;
import dao.ScDao;
import dao.ShokeDao;
import dao.ZuoDao;

import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;

public class TeacherZuye extends JFrame {

	private JPanel contentPane;
	String teacherNo;
	DefaultTableModel tablemodel;
	JTable table;
	JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	JTextArea textArea;
	private static int count=0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeacherZuye frame = new TeacherZuye();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TeacherZuye() {
		
		if(count<=0){
			JOptionPane.showMessageDialog(null,"����ϵͳȱ�ݣ�������ҵ��������ʱ�䣬���ⷢ������");
		}
		count++;
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 883, 568);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		getContentPane().setLayout(null);
		DenLu dl = new DenLu();
		teacherNo=dl.getId();
		contentPane.setLayout(null);
		JLabel lblNewLabel = new JLabel("\u8BFE\u7A0B");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel.setBounds(48, 317, 58, 30);
		getContentPane().add(lblNewLabel);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(102, 322, 205, 24);
		getContentPane().add(comboBox);
		CourseDao sc =new CourseDao();
		String sql = "select * from course,shoke where shoke.courseID=course.courseID and shoke.teacherNo='"+teacherNo+"'";
		List<Course> ls = sc.query(sql);
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox.addItem(ls.get(d).getCourseName());
            }	
		JButton btnNewButton = new JButton("\u5E03\u7F6E");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField.getText().equals("")){
					JOptionPane.showMessageDialog(null,"����д����");
					return ;
				}
				if(textField_1.getText().equals("")){
					JOptionPane.showMessageDialog(null,"��ѡ��ʱ��");
					return ;
				}
				if(textArea.getText().equals("")){
					JOptionPane.showMessageDialog(null,"����д��ҵ����");
					return ;
				}
				ZuoYe zy =new ZuoYe();
				zy.setTitle(textField.getText());
				zy.setBanji("");
				zy.setCourseName(String.valueOf(comboBox.getSelectedItem()));
				zy.setTeacherNo(teacherNo);
				zy.setNeiRong(textArea.getText());
				zy.setStatTime(textField_1.getText());
				zy.setJiezhiTime(textField_2.getText());
				ZuoDao zd =new ZuoDao();
				int k = zd.add(zy);
				if(k>0){
					JOptionPane.showMessageDialog(null,"�����ɹ�");
					ScDao sd =new ScDao();
					String sql ="select * from sc where teacherNo='"+teacherNo+"' and courseName='"+String.valueOf(comboBox.getSelectedItem())+"'" ;
					List<SC> list = sd.query1(sql);
					System.out.println(list.size());
					for(int i=0;i<list.size();i++){
						SC d =list.get(i);
						ZuoDao zdd = new ZuoDao();
						int ks = zdd.add_zuoyeTiJiao(d.getId(),teacherNo,String.valueOf(comboBox.getSelectedItem()),textField.getText(),"δ�ύ",textField_1.getText());

					}
					int j=sd.update_zuoye(teacherNo, String.valueOf(comboBox.getSelectedItem()));
					tablemodel.setRowCount(0);
					queryAllSc_t(tablemodel, "select * from zuoYE where teacherNo='"+teacherNo+"'");
					table.validate();
				}
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.setBounds(699, 319, 113, 27);
		getContentPane().add(btnNewButton);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("\u4F5C\u4E1A\u4FE1\u606F");
		lblNewLabel_1.setBounds(43, 24, 63, 30);
		getContentPane().add(lblNewLabel_1);
		
		JButton button = new JButton("\u8BBE\u7F6E\u5F00\u59CB\u622A\u6B62\u65F6\u95F4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TeacherZuye.this.dispose();
				Time t =new Time();
				t.setVisible(true);	
			}
		});
		Time t =new Time();
		button.setBounds(422, 321, 185, 27);
		getContentPane().add(button);
		 textArea = new JTextArea();
		 textArea.setBounds(48, 232, 744, 72);
		 getContentPane().add(textArea);
			
		JLabel lblNewLabel_2 = new JLabel("\u73ED\u7EA7");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(48, 403, 58, 24);
		getContentPane().add(lblNewLabel_2);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(102, 405, 205, 24);
		getContentPane().add(comboBox_1);
		ShokeDao sd =new ShokeDao();
		String sql1 ="select * from shoke where teacherNo='"+teacherNo+"' and shokeban is NOT NULL";
		String[] ssd = sd.query1(sql1);
		for(int d =0 ;d<ssd.length;d++){
			comboBox_1.addItem(ssd[d]);
		}
		
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(102, 447, 205, 24);
		getContentPane().add(comboBox_2);
            for(int d=0;d<ls.size();d++){
            	comboBox_2.addItem(ls.get(d).getCourseName());
            }	
		
		JButton button_4 = new JButton("\u5E03\u7F6E");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if(textField.getText().equals("")){
					JOptionPane.showMessageDialog(null,"����д����");
					return ;
				}
				if(textField_1.getText().equals("")){
					JOptionPane.showMessageDialog(null,"��ѡ��ʱ��");
					return ;
				}
				if(textArea.getText().equals("")){
					JOptionPane.showMessageDialog(null,"����д��ҵ����");
					return ;
				}
				ZuoYe zy =new ZuoYe();
				zy.setTitle(textField.getText());
				zy.setBanji(String.valueOf(comboBox_1.getSelectedItem()));
				zy.setCourseName(String.valueOf(comboBox_2.getSelectedItem()));
				zy.setTeacherNo(teacherNo);
				zy.setNeiRong(textArea.getText());
				zy.setStatTime(textField_1.getText());
				zy.setJiezhiTime(textField_2.getText());
				ZuoDao zd =new ZuoDao();
				int k = zd.add(zy);
				if(k>0){
					JOptionPane.showMessageDialog(null,"�����ɹ�");
					ScDao sd =new ScDao();
					String sql ="select * from sc,student where student.id=sc.id and teacherNo='"+teacherNo+"' and courseName='"+String.valueOf(comboBox.getSelectedItem())+"' and student.banji='"+String.valueOf(comboBox_1.getSelectedItem())+"'" ;					
					List<SC> list = sd.query1(sql);
					System.out.println(list.size());
					for(int i=0;i<list.size();i++){
						SC d =list.get(i);
						ZuoDao zdd = new ZuoDao();
						int ks = zdd.add_zuoyeTiJiao(d.getId(),teacherNo,String.valueOf(comboBox.getSelectedItem()),textField.getText(),"δ�ύ",textField_1.getText());
					}
					ScDao sd1 =new ScDao();
					int j=sd1.update_zuoye(teacherNo, String.valueOf(comboBox.getSelectedItem()));
					tablemodel.setRowCount(0);
					queryAllSc_t(tablemodel, "select * from zuoYE where teacherNo='"+teacherNo+"'");
					table.validate();
				}
				
			
			}
		});
		button_4.setFont(new Font("����", Font.PLAIN, 18));
		button_4.setBounds(699, 418, 113, 27);
		getContentPane().add(button_4);
		
		JLabel label = new JLabel("\u8BFE\u7A0B");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(48, 442, 58, 30);
		getContentPane().add(label);
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(48, 55, 780, 108);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"�γ���","����","����","�༶","��ʼʱ��","��ֹʱ��"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		queryAllSc_t(tablemodel, "select * from zuoYE where teacherNo='"+teacherNo+"'");
		table.validate();
		scrollPane.setViewportView(table);
		
		JLabel label_1 = new JLabel("\u4F5C\u4E1A\u5E03\u7F6E");
		label_1.setBounds(43, 169, 63, 30);
		getContentPane().add(label_1);
		
		textField = new JTextField();
		textField.setBounds(298, 175, 200, 24);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\u6807\u9898");
		lblNewLabel_3.setBounds(250, 176, 35, 30);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u5185\u5BB9");
		lblNewLabel_4.setBounds(48, 212, 94, 24);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\u9009\u4E2D\u8981\u5220\u9664\u7684\u4F5C\u4E1A\u540E\uFF0C\u70B9\u51FB\u5220\u9664\u4F5C\u4E1A");
		lblNewLabel_5.setForeground(Color.RED);
		lblNewLabel_5.setBounds(611, 195, 254, 24);
		getContentPane().add(lblNewLabel_5);
		
		JButton button_1 = new JButton("\u8BBE\u7F6E\u5F00\u59CB\u622A\u6B62\u65F6\u95F4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TeacherZuye.this.dispose();
				Time t =new Time();
				t.setVisible(true);	
			}
		});
		button_1.setBounds(422, 420, 185, 27);
		getContentPane().add(button_1);
		
		JLabel lblNewLabel_6 = new JLabel("\u5F00\u59CB\u65F6\u95F4");
		lblNewLabel_6.setBounds(222, 367, 63, 18);
		contentPane.add(lblNewLabel_6);
		
		textField_1 = new JTextField();
		textField_1.setText(t.startS());
		textField_1.setEditable(false);
		textField_1.setBounds(309, 364, 185, 24);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel label_2 = new JLabel("\u622A\u6B62\u65F6\u95F4");
		label_2.setBounds(516, 361, 63, 30);
		contentPane.add(label_2);
		
		textField_2 = new JTextField();
		
		textField_2.setText(t.startJ());
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(593, 365, 185, 24);
		contentPane.add(textField_2);
		
		JButton button_2 = new JButton("\u67E5\u8BE2\u4F5C\u4E1A");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				queryAllSc_t(tablemodel, "select * from zuoYE where teacherNo='"+teacherNo+"'");
				table.validate();
			}
		});
		button_2.setBounds(349, 15, 113, 27);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("\u5220\u9664\u4F5C\u4E1A");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int count = table.getSelectedRow();
				String courseName = (String) table.getValueAt(count, 0);
				String title = (String) table.getValueAt(count, 1);
				String startTime = (String) table.getValueAt(count, 4);
				ZuoDao zd =new ZuoDao();
				int i=zd.deleteSex(teacherNo, courseName, startTime);
				if(i>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					zd.delete_zuoyeTiJiao(teacherNo, courseName, startTime);
					tablemodel.setRowCount(0);
					queryAllSc_t(tablemodel, "select * from zuoYE where teacherNo='"+teacherNo+"'");
					table.validate();
				}
			}
		});
		button_3.setBounds(699, 171, 113, 27);
		contentPane.add(button_3);

	
	}
	public static void queryAllSc_t(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ZuoDao zd =new ZuoDao();
		List<ZuoYe> list =zd.query(sql);
		String[] s = new String[8];
		for(int i=0;i<list.size();i++)
		{
			ZuoYe zy =list.get(i);
			s[0] = zy.getCourseName();
			s[1] = zy.getTitle();
			s[2] = zy.getNeiRong();
			s[3] = zy.getBanji();
			s[4] = zy.getStatTime();
			s[5] = zy.getJiezhiTime();
			tablemodel.addRow(s);
		}
	}
}
