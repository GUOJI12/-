package View_main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;

import java.awt.Font;

import javax.swing.JButton;

import model.ZuoYe;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;

public class Time extends JFrame {

	private JPanel contentPane;
	private static String syear;
	private static String smonth;
	private static String sday;
	private static String sshi;
	private static String sfen;
	private static String smiao;
	private static String jyear;
	private static String jmonth;
	private static String jday;
	private static String jshi;
	private static String jfen;
	private static String jmiao;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Time frame = new Time();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	protected void setDefaultLookAndFeelDecorated(int hideOnClose) {
		// TODO �Զ����ɵķ������
		
	}

	/**
	 * Create the frame.
	 */
	public Time() {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 499, 367);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5E74");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel.setBounds(22, 51, 26, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u6708");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(22, 91, 26, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel label = new JLabel("\u5F00\u59CB\u65F6\u95F4");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(30, 13, 120, 27);
		contentPane.add(label);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(78, 52, 72, 24);
		contentPane.add(comboBox);
		for(int i=2022;i<3000;i++){
			comboBox.addItem(i);
		}
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(78, 94, 72, 24);
		contentPane.add(comboBox_1);
		for(int i=1;i<13;i++){
			comboBox_1.addItem(i);
		}
		
		JLabel label_1 = new JLabel("\u65E5");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(22, 134, 26, 27);
		contentPane.add(label_1);
		
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(78, 137, 72, 24);
		contentPane.add(comboBox_2);
		for(int i=1;i<32;i++){
			comboBox_2.addItem(i);
		}
		
		JLabel label_2 = new JLabel("\u65F6");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(22, 181, 26, 27);
		contentPane.add(label_2);
		
		
		final JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setBounds(78, 184, 72, 24);
		contentPane.add(comboBox_3);
		for(int i=1;i<25;i++){
			if(i<10){
			  comboBox_3.addItem("0"+i);
			}
			else{
				comboBox_3.addItem(i);
			}			
		}
		
		JLabel label_3 = new JLabel("\u5206");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(22, 226, 26, 27);
		contentPane.add(label_3);
		
		final JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(78, 229, 72, 24);
		contentPane.add(comboBox_4);
		for(int i=1;i<61;i++){
			if(i<10){
				comboBox_4.addItem("0"+i);
				}
				else{
					comboBox_4.addItem(i);
				}	
		}
		
		JLabel label_4 = new JLabel("\u79D2");
		label_4.setFont(new Font("����", Font.PLAIN, 18));
		label_4.setBounds(22, 271, 26, 27);
		contentPane.add(label_4);
		
		final JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setBounds(78, 274, 72, 24);
		contentPane.add(comboBox_5);
		for(int i=1;i<61;i++){
			if(i<10){
				comboBox_5.addItem("0"+i);
				}
				else{
					comboBox_5.addItem(i);
				}	
		}
		final JComboBox comboBox_12 = new JComboBox();
		comboBox_12.setBounds(331, 54, 72, 24);
		contentPane.add(comboBox_12);
		for(int i=2022;i<3000;i++){
			comboBox_12.addItem(i);
		}
		
		JLabel label_6 = new JLabel("\u6708");
		label_6.setFont(new Font("����", Font.PLAIN, 18));
		label_6.setBounds(282, 97, 26, 27);
		contentPane.add(label_6);
		
		final JComboBox comboBox_13 = new JComboBox();
		comboBox_13.setBounds(331, 94, 72, 24);
		contentPane.add(comboBox_13);
		for(int i=1;i<13;i++){
			comboBox_13.addItem(i);
		}
		
		JLabel label_7 = new JLabel("\u65E5");
		label_7.setFont(new Font("����", Font.PLAIN, 18));
		label_7.setBounds(282, 134, 26, 27);
		contentPane.add(label_7);
		
		final JComboBox comboBox_14 = new JComboBox();
		comboBox_14.setBounds(331, 137, 72, 24);
		contentPane.add(comboBox_14);
		for(int i=1;i<32;i++){
			if(i<10){
				comboBox_14.addItem("0"+i);
				}
				else{
					comboBox_14.addItem(i);
				}
		}
		
		JLabel label_8 = new JLabel("\u65F6");
		label_8.setFont(new Font("����", Font.PLAIN, 18));
		label_8.setBounds(282, 181, 26, 27);
		contentPane.add(label_8);
		
		final JComboBox comboBox_15 = new JComboBox();
		comboBox_15.setBounds(331, 184, 72, 24);
		contentPane.add(comboBox_15);
		for(int i=1;i<25;i++){
			if(i<10){
				comboBox_15.addItem("0"+i);
				}
				else{
					comboBox_15.addItem(i);
				}
		}
		
		JLabel label_9 = new JLabel("\u5206");
		label_9.setFont(new Font("����", Font.PLAIN, 18));
		label_9.setBounds(282, 226, 26, 27);
		contentPane.add(label_9);
		
		final JComboBox comboBox_16 = new JComboBox();
		comboBox_16.setBounds(331, 229, 72, 24);
		contentPane.add(comboBox_16);
		for(int i=1;i<61;i++){
			if(i<10){
				comboBox_16.addItem("0"+i);
				}
				else{
					comboBox_16.addItem(i);
				}
		}
		
		JLabel label_10 = new JLabel("\u79D2");
		label_10.setFont(new Font("����", Font.PLAIN, 18));
		label_10.setBounds(282, 271, 26, 27);
		contentPane.add(label_10);
		
		final JComboBox comboBox_17 = new JComboBox();
		comboBox_17.setBounds(331, 274, 72, 24);
		contentPane.add(comboBox_17);
		for(int i=1;i<61;i++){
			if(i<10){
				comboBox_17.addItem("0"+i);
				}
				else{
					comboBox_17.addItem(i);
				}
		}

		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				syear = String.valueOf(comboBox.getSelectedItem());
				smonth = String.valueOf(comboBox_1.getSelectedItem());
				sday = String.valueOf(comboBox_2.getSelectedItem());
				sshi = String.valueOf(comboBox_3.getSelectedItem());
				sfen = String.valueOf(comboBox_4.getSelectedItem());
				smiao = String.valueOf(comboBox_5.getSelectedItem());
				jyear = String.valueOf(comboBox_12.getSelectedItem());
				jmonth = String.valueOf(comboBox_13.getSelectedItem());
				jday = String.valueOf(comboBox_14.getSelectedItem());
				jshi = String.valueOf(comboBox_15.getSelectedItem());
				jfen = String.valueOf(comboBox_16.getSelectedItem());
				jmiao = String.valueOf(comboBox_17.getSelectedItem());
				System.out.println(Double.valueOf(syear+smonth+sday+sshi+sfen+smiao));
				System.out.println(Double.valueOf(jyear+jmonth+jday+jshi+jfen+jmiao));
				if(Double.valueOf(syear+smonth+sday+sshi+sfen+smiao)<Double.valueOf(jyear+jmonth+jday+jshi+jfen+jmiao))
				{
					Time.this.dispose();
					TeacherZuye t =new TeacherZuye();
					t.setVisible(true);
				}
				else{
					JOptionPane.showMessageDialog(null,"��ֹʱ��С�ڿ�ʼʱ��");
				}
			
			}
		});
		
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(164, 271, 113, 27);
		contentPane.add(button);
		
		JLabel label_5 = new JLabel("\u5E74");
		label_5.setFont(new Font("����", Font.PLAIN, 18));
		label_5.setBounds(282, 51, 26, 27);
		contentPane.add(label_5);
		
		
	}
	
	public String startS(){
		String stratK =syear+"-"+smonth+"-"+sday+" "+sshi+":"+sfen+":"+smiao;
		return stratK;
	}
	public String startJ(){
		String stratL =jyear+"-"+jmonth+"-"+jday+" "+jshi+":"+jfen+":"+jmiao;
		return stratL;	
	}
}
