package View_main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dao.StudentDao;
import dao.TeacherDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPasswordField;



public class UpdatePasswd extends JFrame {

	private JPanel contentPane;
	JTextField textField_1,textField;
	JRadioButton radioButton,radioButton_1;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdatePasswd frame = new UpdatePasswd();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdatePasswd() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 526, 491);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\u5FD8\u8BB0\u5BC6\u7801");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(203, 13, 111, 18);
		getContentPane().add(lblNewLabel);
		
		JLabel label = new JLabel("\u5B66\u53F7/\u5DE5\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(69, 41, 111, 24);
		getContentPane().add(label);
		
		textField = new JTextField();
		textField.setBounds(203, 44, 202, 24);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		radioButton = new JRadioButton("\u5B66\u751F");
		radioButton.setSelected(true);
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					radioButton_1.setSelected(false);
				}
			}
		});
		radioButton.setBounds(213, 77, 59, 37);
		getContentPane().add(radioButton);
		
		radioButton_1 = new JRadioButton("\u6559\u5E08");
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton_1.isSelected()){
					radioButton.setSelected(false);
				}
			
			}
		});
		radioButton_1.setBounds(337, 77, 59, 37);
		getContentPane().add(radioButton_1);
		
		JLabel label_1 = new JLabel("\u6743\u9650\u7801");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(69, 116, 72, 18);
		getContentPane().add(label_1);
		
		 textField_1 = new JTextField();
		textField_1.setBounds(203, 115, 202, 24);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel label_2 = new JLabel("\u65B0\u5BC6\u7801");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(69, 184, 72, 18);
		getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("\u786E\u8BA4\u65B0\u5BC6\u7801");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(69, 248, 111, 18);
		getContentPane().add(label_3);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField.getText().equals("")){
					JOptionPane.showMessageDialog(null,"��������ѧ�Ż򹤺�");
					return;
				}
				if(radioButton.isSelected()){
					StudentDao sd =new StudentDao();
					String k=sd.selectup(textField.getText(),Integer.valueOf(textField_1.getText()));
				    if(!k.equals("")){
				    	if(passwordField.getText().equals(passwordField_1.getText()) &&!passwordField.getText().equals("") 
				    		&& !passwordField_1.getText().equals("")&& passwordField.getText().length()>=6&& passwordField_1.getText().length()>=6
				    		&& passwordField_1.getText().length()<=12&& passwordField.getText().length()<=12){
				    		int j=sd.updatepasswd(textField.getText(),Integer.valueOf(textField_1.getText()),passwordField.getText());
				    	    if(j>0){
				    	    	 JOptionPane.showMessageDialog(null,"�޸ĳɹ����Զ��˻�������");
				    	    	 UpdatePasswd.this.dispose();
								 DenLu sc = new DenLu();
								 sc.setVisible(true);
				    	    }
				    	    else{
				    	    	JOptionPane.showMessageDialog(null,"ʧ�ܣ�δ֪����");
				    	    }
				    	}
				    	else{
				    		JOptionPane.showMessageDialog(null,"�������벻һ�»򳤶�С��6λ����12λ������Ϊ��");
				    	}
				    	
				    }
				    else{
				    	JOptionPane.showMessageDialog(null,"Ȩ�������ѧ�Ŵ���");
				    }
				}
				//��ʦ
				if(radioButton_1.isSelected()){
					TeacherDao sd =new TeacherDao();
					String k=sd.selectup(textField.getText(),Integer.valueOf(textField_1.getText()));
				    if(!k.equals("")){
				    	if(passwordField.getText().equals(passwordField_1.getText()) &&!passwordField.getText().equals("") 
				    		&& !passwordField_1.getText().equals("")&& passwordField.getText().length()>=6&& passwordField_1.getText().length()>=6
				    		&& passwordField_1.getText().length()<=12&& passwordField.getText().length()<=12){
				    		int j=sd.updatepasswd(textField.getText(),Integer.valueOf(textField_1.getText()),passwordField.getText());
				    	    if(j>0){
				    	    	 JOptionPane.showMessageDialog(null,"�޸ĳɹ����Զ��˻�������");
				    	    	 UpdatePasswd.this.dispose();
								 DenLu sc = new DenLu();
								 sc.setVisible(true);
				    	    }
				    	    else{
				    	    	JOptionPane.showMessageDialog(null,"ʧ�ܣ�δ֪����");
				    	    }
				    	}
				    	else{
				    		JOptionPane.showMessageDialog(null,"�������벻һ�»򳤶�С��6λ����12λ������Ϊ��");
				    	}
				    	
				    }
				    else{
				    	JOptionPane.showMessageDialog(null,"Ȩ�������ѧ�Ŵ���");
				    }
				
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(40, 328, 113, 27);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("\u8FD4\u56DE");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			     UpdatePasswd.this.dispose();
				 DenLu sc = new DenLu();
				 sc.setVisible(true);
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(357, 328, 113, 27);
		getContentPane().add(button_1);
		
		JButton button_2 = new JButton("\u8054\u7CFB\u5B66\u6821\u7BA1\u7406\u5458");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				bing.Main.main(null);
			}
		});
		button_2.setBounds(189, 417, 144, 27);
		getContentPane().add(button_2);
		
		JLabel label_4 = new JLabel("*\u6CE8:\u6743\u9650\u7801\u9700\u4ECE\u7BA1\u7406\u5458\u53D6\u5F97");
		label_4.setForeground(Color.RED);
		label_4.setBounds(69, 139, 276, 18);
		getContentPane().add(label_4);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(203, 183, 202, 24);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(203, 247, 202, 24);
		contentPane.add(passwordField_1);

	}

}
