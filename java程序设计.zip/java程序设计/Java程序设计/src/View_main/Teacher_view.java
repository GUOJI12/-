package View_main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import javax.swing.JPopupMenu;

import v_teacher_kaike.TeacherGua_student;
import v_teacher_kaike.TeacherJieke;
import v_teacher_kaike.TeacherKaiKe;
import v_teacher_kaike.TeacherLuru_student;
import v_teacher_kaike.TeacherSelect_student;
import v_teacher_kaike.TeacherZuoye_tijiaot;
import view_teacher_Main.TeacherPasswd;
import view_teacher_Main.TeacherSelect;
import view_teacher_Main.TeacherUpdate;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Teacher_view extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teacher_view frame = new Teacher_view();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teacher_view() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 917, 619);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu = new JMenu("\u4E2A\u4EBA\u4FE1\u606F");
		menu.setForeground(Color.ORANGE);
		menu.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu);
		
		JMenuItem menuItem = new JMenuItem("\u67E5\u770B\u4E2A\u4EBA\u4FE1\u606F");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				contentPane.removeAll();
				contentPane.add(new TeacherSelect());
				contentPane.validate();	
			}
		});
		menuItem.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("\u5B8C\u5584\u4E2A\u4EBA\u4FE1\u606F");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherUpdate());
				contentPane.validate();	
			}
		});
		menuItem_1.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem_1);
		
		JMenuItem menuItem_2 = new JMenuItem("\u4FEE\u6539\u5BC6\u7801");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherPasswd());
				contentPane.validate();	
			}
		});
		menuItem_2.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem_2);
		
		JMenu menu_1 = new JMenu("\u6388\u8BFE\u7BA1\u7406");
		menu_1.setForeground(Color.PINK);
		menu_1.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_1);
		
		JMenuItem menuItem_3 = new JMenuItem("\u5F00\u8BBE\u8BFE\u7A0B");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherKaiKe());
				contentPane.validate();	
				
			}
		});
		menuItem_3.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_3);
		
		JMenuItem menuItem_4 = new JMenuItem("\u7ED3\u8BFE");
		menuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherJieke());
				contentPane.validate();	
			}
		});
		menuItem_4.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_4);
		
		JMenu menu_3 = new JMenu("\u8003\u8BD5\u53CA\u8D4B\u5206");
		menu_3.setForeground(Color.BLUE);
		menu_3.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_3);
		
		JMenuItem menuItem_7 = new JMenuItem("\u67E5\u8BE2\u5B66\u751F");
		menuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherSelect_student());
				contentPane.validate();	
			}
		});
		menuItem_7.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_7);
		
		JMenuItem menuItem_8 = new JMenuItem("\u5F55\u5165\u6210\u7EE9");
		menuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherLuru_student());
				contentPane.validate();	
			}
		});
		menuItem_8.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_8);
		
		JMenuItem menuItem_9 = new JMenuItem("\u6302\u79D1\u5B66\u751F\u540D\u5355");
		menuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherGua_student());
				contentPane.validate();	
			}
		});
		menuItem_9.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_9);
		
		JMenu menu_2 = new JMenu("\u4F5C\u4E1A");
		menu_2.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_2);
		
		JMenuItem menuItem_5 = new JMenuItem("\u5E03\u7F6E\u4F5C\u4E1A");
		menuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TeacherZuye  t =new TeacherZuye();
				t.setVisible(true);
			}
		});
		menuItem_5.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_2.add(menuItem_5);
		
		JMenuItem menuItem_6 = new JMenuItem("\u67E5\u770B\u4F5C\u4E1A\u63D0\u4EA4\u60C5\u51B5");
		menuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new TeacherZuoye_tijiaot());
				contentPane.validate();	
			}
		});
		menuItem_6.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_2.add(menuItem_6);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}
}
