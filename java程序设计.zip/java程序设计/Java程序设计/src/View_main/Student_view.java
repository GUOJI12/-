package View_main;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import model.SC;
import model.Student;

import org.jfree.ui.RefineryUtilities;

import dao.CourseDao;
import dao.ScDao;
import dao.StudentDao;
import bing.san;
import view_student_Main.StudentPasswd;
import view_student_Main.StudentScoreAnalysis;
import view_student_Main.StudentSelectSc_long;
import view_student_Main.StudentSelect_xinxi;
import view_student_Main.StudentUpdate_xinxi;
import view_student_Main.StudentXunke;
import view_student_Main.Studentzuoye_select;
import view_student_Main.StudnetSelet_scjie;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.util.List;

public class Student_view extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_view frame = new Student_view();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_view() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 908, 556);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu = new JMenu("\u4E2A\u4EBA\u4FE1\u606F");
		menu.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu);
		
		JMenuItem menuItem = new JMenuItem("\u4E2A\u4EBA\u57FA\u672C\u4FE1\u606F");
		menuItem.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new StudentSelect_xinxi());
				contentPane.validate();	
			}
		});
		menu.add(menuItem);
		
		JMenuItem menuItem_1 = new JMenuItem("\u4E2A\u4EBA\u4FE1\u606F\u4FEE\u6539");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new StudentUpdate_xinxi());
				contentPane.validate();	
			}
		});
		menuItem_1.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem_1);
		
		JMenuItem menuItem_2 = new JMenuItem("\u4FEE\u6539\u5BC6\u7801");
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new StudentPasswd());
				contentPane.validate();	
			}
		});
		menuItem_2.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu.add(menuItem_2);
		
		JMenu menu_1 = new JMenu("\u8BFE\u7A0B\u4FE1\u606F");
		menu_1.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_1);
		
		JMenuItem menuItem_6 = new JMenuItem("\u67E5\u770B\u5DF2\u7ED3\u8BFE\u7A0B");
		menuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new StudnetSelet_scjie());
				contentPane.validate();	
			}
		});
		menuItem_6.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_6);
		
		JMenuItem menuItem_3 = new JMenuItem("\u67E5\u770B\u5DF2\u9009\u8BFE\u7A0B");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new StudentSelectSc_long());
				contentPane.validate();	
			}
		});
		menuItem_3.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_3);
		
		JMenuItem menuItem_4 = new JMenuItem("\u9009\u8BFE");
		menuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new StudentXunke());
				contentPane.validate();	
			}
		});
		menuItem_4.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_1.add(menuItem_4);
		
		JMenu menu_2 = new JMenu("\u4F5C\u4E1A");
		menu_2.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_2);
		
		JMenuItem menuItem_7 = new JMenuItem("\u67E5\u770B(\u63D0\u4EA4)\u4F5C\u4E1A");
		menuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.removeAll();
				contentPane.add(new Studentzuoye_select());
				contentPane.validate();	
				
			}
		});
		menuItem_7.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_2.add(menuItem_7);
		
		JMenu menu_3 = new JMenu("\u6210\u7EE9\u67E5\u8BE2");
		menu_3.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menuBar.add(menu_3);
		
		JMenuItem menuItem_8 = new JMenuItem("\u997C\u72B6\u56FE\u5206\u6790");
		menuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				DenLu dl =new DenLu();
				String studentId = dl.getId();
				String sql = "select * from sc,student,teacher where teacher.teacherNo=sc.teacherNo and sc.id=student.id and sc.id=+'"
				+studentId+"' and zhuantai='�ѽ��'";
				ScDao sd = new ScDao();
				StudentDao st =new StudentDao();
				CourseDao cd =new CourseDao();
				List<SC> list = sd.query(sql);
				if(list.size()<=0){
					JOptionPane.showMessageDialog(null,"���޽�ογ̣��ɼ�δ¼�룬�޷��鿴����");
					return;
				}
				san s = new san();
				s.main(null);
			
			}
			
		});
		menuItem_8.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_8);
		
		JMenuItem menuItem_9 = new JMenuItem("\u6210\u7EE9\u5206\u6790");
		menuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DenLu dl =new DenLu();
				String studentId = dl.getId();
				String sql = "select * from sc,student,teacher where teacher.teacherNo=sc.teacherNo and sc.id=student.id and sc.id=+'"
				+studentId+"' and zhuantai='�ѽ��'";
				ScDao sd = new ScDao();
				StudentDao st =new StudentDao();
				CourseDao cd =new CourseDao();
				List<SC> list = sd.query(sql);
				if(list.size()<=0){
					JOptionPane.showMessageDialog(null,"���޽�ογ̣��ɼ�δ¼�룬�޷��鿴����");
					return;
				}
				contentPane.removeAll();
				contentPane.add(new StudentScoreAnalysis());
				contentPane.validate();	
			}
		});
		menuItem_9.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 18));
		menu_3.add(menuItem_9);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}

}
