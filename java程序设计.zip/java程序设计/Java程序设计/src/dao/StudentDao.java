package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import sql_coon.DB;
import model.SC;
import model.Student;

public class StudentDao {
	Connection coon=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
	public List<Student> query(String sql){
		List list = null;
		coon = DB.openConn();
		try {
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			list = new ArrayList<Student>();
			while(rs.next()){
				Student s = new Student();
				s.setId(rs.getString("id"));
				s.setName(rs.getString("name"));
				s.setPassword(rs.getString("password"));
				s.setAge(rs.getInt("age"));
				s.setSex(rs.getString("sex"));
				s.setBanji(rs.getString("banji"));
				s.setGrad(rs.getString("grad"));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return list;
	}
	public List<Student> queryAll(String sql){
		List list = null;
		coon = DB.openConn();
		try {
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			list = new ArrayList<Student>();
			while(rs.next()){
				Student s = new Student();
				s.setId(rs.getString("id"));
				s.setName(rs.getString("name"));
				s.setPassword(rs.getString("password"));
				s.setAge(rs.getInt("age"));
				s.setSex(rs.getString("sex"));
				s.setBanji(rs.getString("banji"));
				s.setGrad(rs.getString("grad"));
				s.setPnum(rs.getString("pnum"));
				s.setToxiang(rs.getString("toxiang"));
				s.setGexing(rs.getString("gexing"));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return list;
	}
	public int add (Student s){//����
		int i = 0;
		coon=DB.openConn();
		String sql = "insert into student(id,name,password,age,sex,banji,grad,toxiang) values(?,?,?,?,?,?,?,?)";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, s.getId());
			ps.setString(2, s.getName());
			ps.setString(3, s.getPassword());
			ps.setInt(4, s.getAge());
			ps.setString(5, s.getSex());
			ps.setString(6, s.getBanji());
			ps.setString(7, s.getGrad());
			ps.setString(8,s.getToxiang());
			i=ps.executeUpdate();
			if(i==1){
				System.out.println("���ӳɹ�!");
			}else{
				System.out.println("����ʧ��!");
			}

		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int update (Student s){//�޸�
		int i = 0;
		coon=DB.openConn();
		String sql = "update student set name=?,password=?,age=?,sex=?,banji=? where id=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, s.getName());
			ps.setString(2, s.getPassword());
			ps.setInt(3, s.getAge());
			ps.setString(4, s.getSex());
			ps.setString(5, s.getBanji());
			ps.setString(6, s.getId());
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int update1 (Student s){//�޸�
		int i = 0;
		coon=DB.openConn();
		String sql = "update student set age=?,toxiang=?,pnum=?,gexing=? where id=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setInt(1,s.getAge());
			ps.setString(2,s.getToxiang());
			ps.setString(3,s.getPnum());
			ps.setString(4,s.getGexing());
			ps.setString(5, s.getId());
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public String selectup (String id,int quanxian){//�飬ѧ�ţ�Ȩ����
		int i = 0;
		String s ="";
		coon=DB.openConn();
		String sql = "select * from student where id=? and quanxian=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,id);
			ps.setInt(2,quanxian);
			rs=ps.executeQuery();	
			while(rs.next()){
				s = rs.getString("name");
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return s;
	}
	public int updatepasswd (String id,int quanxian,String passwd){//�޸�����
		int i = 0;
		coon=DB.openConn();
		String sql = "update student set password=? where id=? and quanxian=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,passwd);
			ps.setString(2,id);
			ps.setInt(3,quanxian);
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int updateq (String id,int quanxian){//�޸�Ȩ����
		int i = 0;
		coon=DB.openConn();
		String sql = "update student set quanxian=? where id=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setInt(1,quanxian);
			ps.setString(2,id);
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int deleteId (String id){//ɾ����ѧ��
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from student where id=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, id);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteName (String name){//ɾ��������
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from student where name=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, name);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteBanji (String banji){//ɾ�����༶
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from student where banji=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, banji);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteAge (int age){//ɾ��������
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from student where age=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setInt(1, age);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteSex (String sex){//ɾ��������
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from student where sex=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, sex);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteGrad (String grad){//ɾ�����꼶
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from student where grad=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, grad);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int updatepasswd (String id,String passwd){//�޸�����
		int i = 0;
		coon=DB.openConn();
		String sql = "update student set password=? where id=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,passwd);
			ps.setString(2,id);
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public String toxiang(String id,String passwd) throws Exception{//�鿴
		coon=DB.openConn();
		String sql = "select * from student where id=? and password=?";
		String to="";
		try {
			ps = coon.prepareStatement(sql);
			ps.setString(1,id);
			ps.setString(2,passwd);
			rs = ps.executeQuery();
			while(rs.next()){
				to=rs.getString("toxiang");
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return to;
	}
	//��״ͼ
	public List<SC> query_b(String sql){
		List list=null;
		coon=DB.openConn();
		try {
			ps=coon.prepareStatement(sql);
			rs=ps.executeQuery();//��ѯ��Q ��������UPDATE
			list=new ArrayList<SC>();
			while(rs.next())
			{
				SC s=new SC();
				s.setId(rs.getString(1));
				s.setCourseName(rs.getString(2));
				s.setScore(rs.getDouble(3));
				s.setTeacherNo(rs.getString(4));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return list;
	}
	public double sum(String sql){

		double sum=0;

		coon=DB.openConn();
		try {
			ps=coon.prepareStatement(sql);
			rs=ps.executeQuery();//��ѯ��Q ��������UPDATE

			while(rs.next())
			{
				SC s=new SC();
  			   sum=sum+rs.getDouble(3);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return sum;
	}
	public int tj(String sql){

		int ts=0;

		coon=DB.openConn();
		try {
			ps=coon.prepareStatement(sql);
			rs=ps.executeQuery();//��ѯ��Q ��������UPDATE
			while(rs.next())
			{
				ts++;		
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return ts;
	}
}
