package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.SC;
import model.ScoreAll;
import model.Student;
import sql_coon.DB;

public class ScDao {
	Connection coon=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
		public List<SC> query(String sql){
			List list = null;
			coon = DB.openConn();
			try {
				ps = coon.prepareStatement(sql);
				rs = ps.executeQuery();
				list = new ArrayList<SC>();
				while(rs.next()){
					SC s = new SC();
					s.setId(rs.getString("id"));
					s.setCourseName(rs.getString("courseName"));
					s.setScore(rs.getDouble("score"));
					s.setTeacherNo(rs.getString("teacherNo"));
					s.setTeacherName(rs.getString("teacherName"));
					s.setGuake(rs.getString("guake"));
					s.setZhuantai(rs.getString("zhuantai"));
					list.add(s);
				}
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return list;
			
		}
		public int addSc (SC s){//����ѡ��
			int i = 0;
			coon=DB.openConn();
			String sql = "insert into sc(id,courseName,score,teacherNo,zhuantai) values(?,?,?,?,?)";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, s.getId());
				ps.setString(2,s.getCourseName());
				ps.setDouble(3,0);
				ps.setString(4,s.getTeacherNo());
				ps.setString(5,s.getZhuantai());
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}
		public List<SC> query1(String sql){
			List list = null;
			coon = DB.openConn();
			try {
				ps = coon.prepareStatement(sql);
				rs = ps.executeQuery();
				list = new ArrayList<SC>();
				while(rs.next()){
					SC s = new SC();
					s.setId(rs.getString("id"));
					s.setCourseName(rs.getString("courseName"));
					s.setScore(rs.getDouble("score"));
					s.setTeacherNo(rs.getString("teacherNo"));
					s.setSjtai(rs.getString("sjtai"));
					list.add(s);
				}
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return list;
		}
		public List<ScoreAll> query2(String sql){
			List list = null;
			coon = DB.openConn();
			try {
				ps = coon.prepareStatement(sql);
				rs = ps.executeQuery();
				list = new ArrayList<ScoreAll>();
				while(rs.next()){
					ScoreAll sa = new ScoreAll();
					sa.setId(rs.getString("id"));
					sa.setName(rs.getString("name"));
					sa.setBanji(rs.getString("banji"));
					sa.setGrad(rs.getString("grad"));
					sa.setScoreAll(rs.getDouble("scsum"));
					sa.setXuefenAll(rs.getDouble("xuefen"));
					list.add(sa);
				}
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return list;
		}
		public int deleteId (String id){//ɾ����ѧ��
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from sc where id=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, id);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
			
		}
		public int deleteIn (String id,String courseName){//ɾ����ѧ�ţ��γ�
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from sc where id=? and courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, id);
				ps.setString(2,courseName);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;	
		}
		public int deleteCourseName (String courseName){//ɾ�����γ�
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from sc where courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, courseName);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
			
		}
		public int deleteTn (String teacherNo,String courseName){//ɾ������ʦ�ţ��γ�
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from sc where teacherNo=? and courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, teacherNo);
				ps.setString(2,courseName);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;	
		}
		public int deleteShoke (String teacherNo,String courseName){//ɾ����ѧ�ţ��γ�
		int i = 0;
		coon=DB.openConn();
		String sql = "update sc set zhuantai=? where teacherNo=? and courseName=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,"�ѽ��");
			ps.setString(2, teacherNo);
			ps.setString(3,courseName);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;	
	}
		public int update_ID (SC s){//�޸�
			int i = 0;
			coon=DB.openConn();
			String sql = "update sc set score=? where id=? and courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setDouble(1, s.getScore());
				ps.setString(2,s.getId());
				ps.setString(3,s.getCourseName());
				i=ps.executeUpdate();	
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}
		public int update (SC s){//�޸�
			int i = 0;
			coon=DB.openConn(); 
			String sql = "update sc set guake=? where id=? and courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1,"�ҿ�");
				ps.setString(2, s.getId());
				ps.setString(3,s.getCourseName());
				i=ps.executeUpdate();	
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}
		public int update1 (SC s){//�޸�
			int i = 0;
			coon=DB.openConn(); 
			String sql = "update sc set guake=? where id=? and courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1,"");
				ps.setString(2, s.getId());
				ps.setString(3,s.getCourseName());
				i=ps.executeUpdate();	
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}
		public int update_zuoye (String teacherNo,String CourseName){//�޸�
			int i = 0;
			coon=DB.openConn(); 
			String sql = "update sc set sjtai=? where teacherNo=? and courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1,"δ�Ͻ�");
				ps.setString(2, teacherNo);
				ps.setString(3,CourseName);
				i=ps.executeUpdate();	
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}
		
		public int update_sc (String id,String teacherNo,String CourseName){//�޸�
			int i = 0;
			coon=DB.openConn(); 
			String sql = "update sc set sjtai=? where  id=? and teacherNo=? and courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1,"���Ͻ�");
				ps.setString(2, id);
				ps.setString(3,teacherNo);
				ps.setString(4, CourseName);
				i=ps.executeUpdate();	
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}


}
