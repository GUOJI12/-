package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Student;
import model.Teacher;
import sql_coon.DB;

public class TeacherDao {
	Connection coon=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
	public List<Teacher> query(String sql){
		List list = null;
		coon = DB.openConn();
		try {
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			list = new ArrayList<Teacher>();
			while(rs.next()){
				Teacher t = new Teacher();
				t.setTeacherNo(rs.getString("teacherNo"));
				t.setTeacherName(rs.getString("teacherName"));
				t.setTeacherPasswd(rs.getString("teacherPasswd"));
				t.setTeacherAge(rs.getInt("teacherAge"));
				t.setTeacherSex(rs.getString("teacherSex"));
				list.add(t);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return list;
	}
	public List<Teacher> queryAll(String teacherNo){//��ѯȫ��
		List list = null;
		coon = DB.openConn();
		try {
			ps = coon.prepareStatement("select * from teacher where teacherNo=?");
			ps.setString(1,teacherNo);
			rs = ps.executeQuery();
			list = new ArrayList<Teacher>();
			while(rs.next()){
				Teacher t = new Teacher();
				t.setTeacherNo(rs.getString("teacherNo"));
				t.setTeacherName(rs.getString("teacherName"));
				t.setTeacherAge(rs.getInt("teacherAge"));
				t.setTeacherSex(rs.getString("teacherSex"));
				t.setTeacherToxiang(rs.getString("teacherToxiang"));
				t.setMobileNum(rs.getString("mobileNum"));
				t.setTeacherWen(rs.getString("teacherWen"));
				t.setTeacherWork(rs.getDouble("teacherWork"));
				t.setTeacherMess(rs.getString("teacherMess"));
				list.add(t);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return list;
	}
	public int add (Teacher t){//����
		int i = 0;
		coon=DB.openConn();
		String sql = "insert into teacher(teacherNo,teacherName,teacherAge,teacherSex,teacherPasswd,teacherToxiang) values(?,?,?,?,?,?)";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,t.getTeacherNo());
			ps.setString(2,t.getTeacherName());
			ps.setInt(3,t.getTeacherAge());
			ps.setString(4,t.getTeacherSex());
			ps.setString(5,t.getTeacherPasswd());
			ps.setString(6,t.getTeacherToxiang());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int update (Teacher t){//�޸�
		int i = 0;
		coon=DB.openConn();
		String sql = "update teacher set teacherName=?,teacherAge=?,teacherSex=?,teacherPasswd=? where teacherNo=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,t.getTeacherName());
			ps.setInt(2,t.getTeacherAge() );
			ps.setString(3, t.getTeacherSex());
			ps.setString(4,t.getTeacherPasswd());
			ps.setString(5,t.getTeacherNo());
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int updateT (Teacher t){//�޸�
		int i = 0;
		coon=DB.openConn();
		String sql = "update teacher set teacherAge=?,mobileNum=?,teacherToxiang=?,teacherWen=?,teacherWork=?,teacherMess=? where teacherNo=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setInt(1,t.getTeacherAge());
			ps.setString(2,t.getMobileNum());
			ps.setString(3,t.getTeacherToxiang());
			ps.setString(4,t.getTeacherWen());
			ps.setDouble(5,t.getTeacherWork());
			ps.setString(6,t.getTeacherMess());
			ps.setString(7,t.getTeacherNo());
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	
	public int deleteId (String teacherNo){//ɾ��������
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from teacher where teacherNo=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,teacherNo);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteName (String teacherName){//ɾ��������
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from teacher where teacherName=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, teacherName);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteAge (int teacherAge){//ɾ��������
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from teacher where teacherAge=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setInt(1, teacherAge);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteSex (String teacherSex){//ɾ�����Ա�
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from teacher where teacherSex=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, teacherSex);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public String selectup (String teacherNo,int quanxian){//�飬���ţ�Ȩ����
		int i = 0;
		String s ="";
		coon=DB.openConn();
		String sql = "select * from teacher where teacherNo=? and quanxian=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,teacherNo);
			ps.setInt(2,quanxian);
			rs=ps.executeQuery();	
			while(rs.next()){
				s = rs.getString("teacherName");
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return s;
	}
	public int updatepasswd (String teacherNo,int quanxian,String passwd){//�޸�����
		int i = 0;
		coon=DB.openConn();
		String sql = "update teacher set teacherPasswd=? where teacherNo=? and quanxian=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,passwd);
			ps.setString(2,teacherNo);
			ps.setInt(3,quanxian);
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int updatepasswd_ft (String teacherNo,String passwd){//�޸�����
		int i = 0;
		coon=DB.openConn();
		String sql = "update teacher set teacherPasswd=? where teacherNo=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,passwd);
			ps.setString(2,teacherNo);
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int updateq (String teacherNo,int quanxian){//�޸�Ȩ����
		int i = 0;
		coon=DB.openConn();
		String sql = "update teacher set quanxian=? where teacherNo=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setInt(1,quanxian);
			ps.setString(2,teacherNo);
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public String toxiang(String teacherNo,String passwd) throws Exception{//�鿴ͷ��
		coon=DB.openConn();
		String sql = "select * from teacher where teacherNo=? and teacherPasswd=?";
		String to="";
		try {
			ps = coon.prepareStatement(sql);
			ps.setString(1,teacherNo);
			ps.setString(2,passwd);
			rs = ps.executeQuery();
			while(rs.next()){
				to=rs.getString("teacherToxiang");
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return to;
	}
}
