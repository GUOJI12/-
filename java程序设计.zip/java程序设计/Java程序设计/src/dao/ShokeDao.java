package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.SC;
import sql_coon.DB;

public class ShokeDao {
	Connection coon=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
	public String query(String sql){
		coon = DB.openConn();
		String s ="";
		try {
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				s = rs.getString("courseID");
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return s;
		
	}
	public String[] query1(String sql){
		coon = DB.openConn();
		int count=0;
		try {
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				count++;
			}
			String[] s = new String[count];
			count=0;
			rs = ps.executeQuery();
			while(rs.next()){
				s[count] = rs.getString("shokeban");
				count++;
			}
			return s;
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return null;
	}
	
	
	public int shokeAdd(String teacherNo,String courseId) throws Exception{//����
		coon=DB.openConn();
		String sql = "insert into shoke(teacherNo,courseID) values(?,?)";
		int i=0;
			try {
				ps = coon.prepareStatement(sql);
				ps.setString(1,teacherNo);
				ps.setString(2,courseId);
				i= ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			return i;
	}
	public int shokeAdd_banji(String teacherNo,String courseId,String shokeban) throws Exception{//����
		coon=DB.openConn();
		String sql = "insert into shoke(teacherNo,courseID,shokeban) values(?,?,?)";
		int i=0;
			try {
				ps = coon.prepareStatement(sql);
				ps.setString(1,teacherNo);
				ps.setString(2,courseId);
				ps.setString(3,shokeban);
				i= ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			return i;
	}
	public int deleteID (String teacherNo,String courseID){//ɾ�����γ���
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from shoke where teacherNo=? and courseID=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, teacherNo);
			ps.setString(2, courseID);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	//��ѯȫ��
		public Object[][] selectAll_course(String sql) throws Exception{
			coon=DB.openConn();
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			int count=0;
			while(rs.next()){
				count++;
			}
			rs = ps.executeQuery();
			Object[][] info = new Object[count][7];
			//ת��
			count=0;
			while(rs.next()){
				info[count][0] = rs.getString(1);
				info[count][1] = rs.getString(2);
				info[count][2] = rs.getString(3);
				info[count][3] = rs.getString(4);
				info[count][4] = rs.getString(5);
				info[count][5] = rs.getString(6);
				info[count][6] = rs.getString(7);
				count++;
			}
			return info;
		}
}
