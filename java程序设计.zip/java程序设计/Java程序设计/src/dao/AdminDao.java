package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import sql_coon.DB;

public class AdminDao {
	Connection coon=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
	public String toxiangAdmin(String id,String passwd) throws Exception{//�鿴
		coon=DB.openConn();
		String sql = "select * from admin where admin_no=? and admin_passwd=?";
		String to="";
			try {
				ps = coon.prepareStatement(sql);
				ps.setString(1,id);
				ps.setString(2,passwd);
				rs = ps.executeQuery();
				while(rs.next()){
					to=rs.getString("admin_name");
				}
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			return to;
	}
}
