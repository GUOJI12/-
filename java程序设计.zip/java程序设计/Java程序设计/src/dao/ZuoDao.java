package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Teacher;
import model.ZuoYe;
import model.ZuoYeTai;
import sql_coon.DB;

public class ZuoDao {
	Connection coon=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
	public List<ZuoYe> query(String sql){
		List list = null;
		coon = DB.openConn();
		try {
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			list = new ArrayList<ZuoYe>();
			while(rs.next()){
				ZuoYe zy = new ZuoYe();
				zy.setTeacherNo(rs.getString("teacherNo"));
				zy.setStatTime(rs.getString("statTime"));
				zy.setJiezhiTime(rs.getString("jiezhiTime"));
				zy.setNeiRong(rs.getString("neiRong"));
				zy.setBanji(rs.getString("banji"));
				zy.setCourseName(rs.getString("courseName"));
				zy.setTitle(rs.getString("title"));
				list.add(zy);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return list;
	}
	public List<ZuoYeTai> query_ZuoYeTai(String sql){
		List list = null;
		coon = DB.openConn();
		try {
			ps = coon.prepareStatement(sql);
			rs = ps.executeQuery();
			list = new ArrayList<ZuoYeTai>();
			while(rs.next()){
				ZuoYeTai zyt = new ZuoYeTai();
				zyt.setCourseName(rs.getString("courseName"));
				zyt.setId(rs.getString("id"));
				zyt.setStartTime(rs.getString("startTime"));
				zyt.setTeacherNo(rs.getString("teacherNo"));
				zyt.setZuoye(rs.getString("zuoye"));
				zyt.setZhuangtai(rs.getString("zhuangtai"));	
				list.add(zyt);
			}
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return list;
	}
	
	public int add (ZuoYe z){//����
		int i = 0;
		coon=DB.openConn();
		String sql = "insert into zuoye(teacherNo,statTime,courseName,jiezhiTime,neiRong,banji,title) values(?,?,?,?,?,?,?)";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,z.getTeacherNo());
			ps.setString(2,z.getStatTime());
			ps.setString(3,z.getCourseName());
			ps.setString(4,z.getJiezhiTime());
			ps.setString(5,z.getNeiRong());
			ps.setString(6,z.getBanji());
			ps.setString(7, z.getTitle());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	public int add_zuoyeTiJiao (String id,String teacherNo,String courseName,String zuoye,String zhuangtai,String startTime){//����
		int i = 0;
		coon=DB.openConn();
		String sql = "insert into zuoyeTIJiao(id,teacherNo,courseName,zuoye,zhuangtai,startTime) values(?,?,?,?,?,?)";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,id);
			ps.setString(2,teacherNo);
			ps.setString(3,courseName);
			ps.setString(4,zuoye);
			ps.setString(5,zhuangtai);
			ps.setString(6, startTime);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	
	public int delete_zuoyeTiJiao(String teacherNo,String courseName,String startTime){//ɾ������ʦ��,�γ�ɾ��
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from zuoyetijiao where teacherNo=? and courseName=? and startTime=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, teacherNo);
			ps.setString(2, courseName);
			ps.setString(3, startTime);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int deleteSex (String teacherNo,String courseName,String statTime){//ɾ������ʦ��,�γ�ɾ��
		int i = 0;
		coon=DB.openConn();
		String sql = "delete from zuoye where teacherNo=? and courseName=? and statTime=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1, teacherNo);
			ps.setString(2, courseName);
			ps.setString(3, statTime);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;

	}
	public int update (String id,String courseName,String teacherNo,String startTime,String zuoye){//�޸�
		int i = 0;
		coon=DB.openConn();
		String sql = "update zuoyetijiao set zhuangtai=? where id=? and courseName=? and teacherNo=? and startTime=? and zuoye=?";
		try {
			ps=coon.prepareStatement(sql);
			ps.setString(1,"���ύ");
			ps.setString(2,id);
			ps.setString(3,courseName);
			ps.setString(4,teacherNo);
			ps.setString(5,startTime);
			ps.setString(6, zuoye);
			i=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally{
			DB.closeConn(coon);
			DB.closeConn(ps);
			DB.closeConn(rs);
		}
		return i;
	}
	
}
