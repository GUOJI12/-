package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import sql_coon.DB;
import model.Course;
import model.Student;

public class CourseDao {
	Connection coon=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
		public List<Course> query(String sql){
			List list = null;
			coon = DB.openConn();
			try {
				ps = coon.prepareStatement(sql);
				rs = ps.executeQuery();
				list = new ArrayList<Course>();
				while(rs.next()){
					Course c = new Course();
					c.setCourseID(rs.getString("courseID"));
					c.setCourseName(rs.getString("courseName"));
					c.setXingzhi(rs.getString("xingzhi"));
					c.setXuefen(rs.getDouble("xuefen"));
					c.setXueshi(rs.getDouble("xueshi"));
					list.add(c);
				}
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return list;
		}
		public int add (Course c){//����
			int i = 0;
			coon=DB.openConn();
			String sql = "insert into course values(?,?,?,?,?)";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1,c.getCourseID());
				ps.setString(2,c.getCourseName());
				ps.setString(3,c.getXingzhi());
				ps.setDouble(4, c.getXuefen());
				ps.setDouble(5,c.getXueshi());
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}
		public int update (Course c){//�޸�
			int i = 0;
			coon=DB.openConn();
			String sql = "update course set courseName=?,xingzhi=?,xuefen=?,xueshi=? where courseID=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1,c.getCourseName());
				ps.setString(2,c.getXingzhi());
				ps.setDouble(3,c.getXuefen());
				ps.setDouble(4,c.getXueshi());
				ps.setString(5,c.getCourseID());
				i=ps.executeUpdate();	
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
		}
		public int deleteId (String courseID){//ɾ�����γ̺�
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from course where courseID=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, courseID);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
			
		}
		public int deleteName (String courseName){//ɾ�����γ���
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from course where courseName=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, courseName);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
			
		}
		public int deleteXingzhi (String xingzhi){//ɾ��������
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from course where xingzhi=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setString(1, xingzhi);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
			
		}
		public int deleteXuefen (double xuefen){//ɾ����ѧ��
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from course where xuefen=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setDouble(1, xuefen);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
			
		}
		public int deleteXueshi (double xueshi){//ɾ����ѧʱ
			int i = 0;
			coon=DB.openConn();
			String sql = "delete from course where xueshi=?";
			try {
				ps=coon.prepareStatement(sql);
				ps.setDouble(1, xueshi);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			finally{
				DB.closeConn(coon);
				DB.closeConn(ps);
				DB.closeConn(rs);
			}
			return i;
			
		}
}
