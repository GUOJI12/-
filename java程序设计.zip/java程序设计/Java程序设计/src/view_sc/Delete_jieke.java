package view_sc;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.Color;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.StudentDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Delete_jieke extends JPanel {
	private JTable table;
	DefaultTableModel tablemodel;
	private JTextField textField;

	/**
	 * Create the panel.
	 */
	public Delete_jieke() {
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(39, 57, 795, 249);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"�γ̺�","�γ���","����","ѧʱ","ѧ��","��ʦ","��ʦ��","״̬"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		String sql = "select * from sc,course,teacher where teacher.teacherNo=sc.teacherNo and sc.courseName=course.courseName and zhuantai='�ѽ��'";
		queryAllSc_slong(tablemodel,sql);
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("\u5DF2\u7ED3\u8BFE\u7A0B");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(39, 33, 78, 18);
		add(label);
		
		JButton button = new JButton("\u4E00\u952E\u5220\u9664");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ScDao s = new ScDao();
				int i=0;
				for(int count=0;count<tablemodel.getRowCount();count++){
					i=s.deleteTn(String.valueOf(tablemodel.getValueAt(count,6)),String.valueOf(tablemodel.getValueAt(count,1)));
				}
				if(i>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					tablemodel.setRowCount(0);
					String sql = "select * from sc,course,teacher where teacher.teacherNo=sc.teacherNo and sc.courseName=course.courseName and zhuantai='�ѽ��'";
					queryAllSc_slong(tablemodel,sql);
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(387, 349, 113, 27);
		add(button);
		
		JLabel label_1 = new JLabel("*\u6CE8:\u53EF\u4E00\u952E\u5220\u9664\u7ED3\u8BFE\u8BFE\u7A0B");
		label_1.setForeground(Color.RED);
		label_1.setBounds(372, 389, 314, 18);
		add(label_1);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 18));
		textField.setText("��"+tablemodel.getRowCount()+"��¼");
		textField.setEditable(false);
		textField.setBounds(750, 307, 86, 24);
		add(textField);
		textField.setColumns(10);

	}
	public static void queryAllSc_slong(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ScDao sd = new ScDao();
		StudentDao st =new StudentDao();
		CourseDao cd =new CourseDao();
		List<SC> list = sd.query(sql);
		for (int i = 0; i < list.size() - 1; i++) {
            for (int j = list.size() - 1; j > i; j--) {
                if (list.get(j).getCourseName().equals(list.get(i).getCourseName())) {
                	list.remove(j);
                }
            }
		}
		String[] s = new String[8];
		for(int i=0;i<list.size();i++)
		{
			SC sc=list.get(i);
			List<Course> cs = cd.query("select * from course where courseName="+"'"+sc.getCourseName()+"'");
			Course c = cs.get(0);
			s[0] = c.getCourseID();
			s[1]=sc.getCourseName();
			s[2]=c.getXingzhi();
			s[3]=String.valueOf(c.getXueshi());
			s[4]=String.valueOf(c.getXuefen());
			s[5]=sc.getTeacherName();
			s[6]=sc.getTeacherNo();
			s[7]=sc.getZhuantai();
			System.out.println(s[7]);
			tablemodel.addRow(s);
		}
	}

}
