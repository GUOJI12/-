package view_sc;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;

import java.awt.Color;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.SC;
import dao.ScDao;

import javax.swing.DefaultComboBoxModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DeleteSc extends JPanel {
	private JTextField textField;
	private JTable table;
	private JTextField textField_1;
	DefaultTableModel tablemodel;
	JComboBox comboBox,comboBox_1;

	/**
	 * Create the panel.
	 */
	public DeleteSc() {
		setLayout(null);

		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(47, 53, 72, 24);
		add(label);

		textField = new JTextField();
		textField.setBounds(120, 55, 205, 24);
		add(textField);
		textField.setColumns(10);

		JButton button = new JButton("\u5B66\u751F\u9000\u8BFE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField.getText().equals("")){
					JOptionPane.showMessageDialog(null,"��������ѧ��");
					return;
				}
				if(comboBox.getSelectedItem().equals("��ѡ��")){
					JOptionPane.showMessageDialog(null,"��ѡ��γ�");
					return;
				}
				if(comboBox.getSelectedItem().equals("ȫ���γ�")){
					ScDao sd =new ScDao();
					int k=sd.deleteId(textField.getText());
					if(k>0){
						JOptionPane.showMessageDialog(null,"�ɹ�");
						String sql ="select * from sc,teacher where sc.teacherNo=teacher.teacherNo and sc.id="
								+ ""+"'"+textField.getText()+"' and sc.courseName="+"'"+comboBox.getSelectedItem()+"'";
						SelectSc sc =new SelectSc();
						sc.queryAllSc(tablemodel,sql);
						table.validate();
						textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
					}
					return;
				}
				ScDao sd =new ScDao();
				int k=sd.deleteIn(textField.getText(),String.valueOf(comboBox.getSelectedItem()));
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					String sql ="select * from sc,teacher where sc.teacherNo=teacher.teacherNo and sc.id="
							+ ""+"'"+textField.getText()+"' and sc.courseName="+"'"+comboBox.getSelectedItem()+"'";
					SelectSc sc =new SelectSc();
					sc.queryAllSc(tablemodel,sql);
					table.validate();
					textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				return;
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(770, 52, 113, 27);
		add(button);

		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(130, 157, 72, 24);
		add(label_1);

		JButton button_1 = new JButton("\u8BFE\u7A0B\u9000\u8BFE");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ScDao sd =new ScDao();
				int k=sd.deleteCourseName(String.valueOf(comboBox_1.getSelectedItem()));
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					comboBox_1.removeItem(comboBox_1.getSelectedItem());
					String sql ="select * from sc,teacher where sc.teacherNo=teacher.teacherNo";
					SelectSc sc =new SelectSc();
					sc.queryAllSc(tablemodel,sql);
					table.validate();
					textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
				}
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(605, 156, 113, 27);
		add(button_1);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(34, 248, 816, 222);
		add(scrollPane);

		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�","��ʦ��"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		String sql ="select * from sc,teacher where sc.teacherNo=teacher.teacherNo";
		SelectSc sc =new SelectSc();
		sc.queryAllSc(tablemodel,sql);
		table.validate();


		table.validate();
		scrollPane.setViewportView(table);

		JButton button_2 = new JButton("\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField.getText().equals("")){
					JOptionPane.showMessageDialog(null,"��������ѧ��");
					return;
				}
				if(comboBox.getSelectedItem().equals("��ѡ��")){
					JOptionPane.showMessageDialog(null,"��ѡ��γ�");
					return;
				}
				if(comboBox.getSelectedItem().equals("ȫ���γ�")){
					String sql ="select * from sc,teacher where sc.teacherNo=teacher.teacherNo and sc.id="
							+ ""+"'"+textField.getText()+"'";
					SelectSc sc =new SelectSc();
					sc.queryAllSc(tablemodel,sql);
					table.validate();
					textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
					return;
				}
				String sql ="select * from sc,teacher where sc.teacherNo=teacher.teacherNo and sc.id="
						+ ""+"'"+textField.getText()+"' and sc.courseName="+"'"+comboBox.getSelectedItem()+"'";
				SelectSc sc =new SelectSc();
				sc.queryAllSc(tablemodel,sql);
				table.validate();
				textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(628, 52, 113, 27);
		add(button_2);

		JButton button_3 = new JButton("\u67E5\u8BE2");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String sql ="select * from sc,teacher where sc.teacherNo=teacher.teacherNo and sc.courseName="+"'"+comboBox_1.getSelectedItem()+"'";
				SelectSc sc =new SelectSc();
				sc.queryAllSc(tablemodel,sql);
				table.validate();
				textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(446, 156, 113, 27);
		add(button_3);

		JLabel label_2 = new JLabel("\u8BFE\u7A0B");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(339, 53, 72, 24);
		add(label_2);

		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u8BF7\u9009\u62E9", "\u5168\u90E8\u8BFE\u7A0B"}));
		comboBox.setBounds(414, 55, 200, 24);
		add(comboBox);
		ScDao sc1 =new ScDao();
		List<SC> ls = sc1.query1("select * from sc");
		for (int i = 0; i < ls.size() - 1; i++) {
			for (int j = ls.size() - 1; j > i; j--) {
				if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
					ls.remove(j);
				}
			}
		}
		for(int d=0;d<ls.size();d++){
			comboBox.addItem(ls.get(d).getCourseName());
		}

		comboBox_1 = new JComboBox();
		comboBox_1.setBounds(211, 159, 200, 24);
		add(comboBox_1);
		for(int d=0;d<ls.size();d++){
			comboBox_1.addItem(ls.get(d).getCourseName());
		}

		JLabel lblNewLabel = new JLabel("*\u6CE8:\u5B66\u751F\u9000\u8BFE,\u8F93\u5165\u5B66\u53F7\u548C\u8981\u9000\u7684\u8BFE\u7A0B");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(171, 92, 472, 18);
		add(lblNewLabel);

		JLabel label_3 = new JLabel("*\u6CE8:\u8BFE\u7A0B\u540D\u9000\u8BFE\uFF0C\u9009\u62E9\u5373\u9000\u6389\u8BE5\u8BFE\u7A0B\u6240\u6709\u5B66\u751F");
		label_3.setForeground(Color.RED);
		label_3.setBounds(171, 194, 472, 18);
		add(label_3);

		textField_1 = new JTextField();
		textField_1.setForeground(Color.RED);
		textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
		textField_1.setFont(new Font("����", Font.PLAIN, 18));
		textField_1.setEditable(false);
		textField_1.setBounds(764, 467, 86, 24);
		add(textField_1);
		textField_1.setColumns(10);

	}
}
