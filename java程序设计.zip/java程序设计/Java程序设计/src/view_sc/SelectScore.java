package view_sc;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.Color;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.SC;
import model.ScoreAll;
import model.Student;
import dao.ScDao;
import dao.StudentDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class SelectScore extends JPanel {
	private JTextField textField;
	private JTable table;
	DefaultTableModel tablemodel;
	private JTextField textField_1;
	String file_print;
	/**
	 * Create the panel.
	 */
	public SelectScore() {
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 13, 855, 299);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�༶","�꼶","�ܳɼ�","��ѧ��"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		String sql ="select * from zong";
		queryAllScore(tablemodel,sql);
		table.validate();
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(95, 340, 72, 21);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(193, 340, 213, 24);
		add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String sql ="select * from zong where id="+"'"+textField.getText()+"'";
				queryAllScore(tablemodel,sql);
				table.validate();
				textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(444, 337, 113, 27);
		add(button);
		
		final JButton btnNewButton = new JButton("\u6587\u4EF6");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("��");
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("��ѡ���ļ�");
				jfc.showOpenDialog(null);
				jfc.setVisible(true);
				//��ȡ�û���ѡ��Ķ����ļ�
				File file =jfc.getSelectedFile();
				String s = file.toString();
				s=s.replace("\\","\\\\");
				file_print=s;
				btnNewButton.setText(file_print);		
			}
		});
		btnNewButton.setBounds(193, 417, 213, 27);
		add(btnNewButton);
		
		JLabel label_1 = new JLabel("\u9009\u62E9\u4F4D\u7F6E");
		label_1.setBounds(95, 421, 72, 18);
		add(label_1);
		
		JButton btnNewButton_1 = new JButton("\u6210\u7EE9\u5BFC\u51FA");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tablemodel.getRowCount()==0){
					JOptionPane.showMessageDialog(null,"�������ݣ����Ȳ�ѯ");
					return ;
				}
				if(file_print.equals("")){
					JOptionPane.showMessageDialog(null,"����ѡ���ļ�");
					return ;
				}
				try
				{
					//���ļ�
					WritableWorkbook book=
					Workbook.createWorkbook(new File(file_print+".xls"));
					//������Ϊ����һҳ���Ĺ�����������0��ʾ���ǵ�һҳ
					WritableSheet sheet=book.createSheet("��һҳ",0);
					//��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
					//�Լ���Ԫ������Ϊtest
					String[] ss = {"ѧ��","����","�༶","�꼶","�ܳɼ�","��ѧ��"};
					for(int i=0;i<ss.length;i++){
						Label label=new Label(i,0,ss[i]);
						sheet.addCell(label);
					}
					for(int i=1;i<tablemodel.getRowCount()+1;i++){
						for(int j=0;j<ss.length;j++){
							Label label=new Label(j,i,(String) table.getValueAt(i-1,j));
							//������õĵ�Ԫ�����ӵ���������
							sheet.addCell(label);
						}
					}
					//д�����ݲ��ر��ļ�
					JOptionPane.showMessageDialog(null,"�ɹ�");
					book.write();
					book.close();
				}catch(Exception e)
				{
					System.out.println(e);
				}
			
			
			}
		});
		btnNewButton_1.setBounds(444, 417, 196, 27);
		add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("*\u6CE8:\u672C\u754C\u9762\u53EA\u80FD\u5168\u90E8\u5BFC\u51FA\uFF0C\u65E0\u6CD5\u5355\u4E2A\u5BFC\u51FA");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(349, 450, 328, 18);
		add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.RED);
		textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
		textField_1.setFont(new Font("����", Font.PLAIN, 18));
		textField_1.setEditable(false);
		textField_1.setBounds(783, 312, 86, 24);
		add(textField_1);
		textField_1.setColumns(10);
		
		JButton button_1 = new JButton("\u5168\u90E8\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				String sql ="select * from zong";
				queryAllScore(tablemodel,sql);
				table.validate();
				textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(641, 339, 113, 27);
		add(button_1);
		
	}
	public static void queryAllScore(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ScDao sd = new ScDao();
		List<ScoreAll> list = sd.query2(sql);
		String[] s = new String[6];
		for(int i=0;i<list.size();i++)
		{
			ScoreAll sa =list.get(i);
			s[0] = sa.getId();
			s[1] = sa.getName();
			s[2] = sa.getBanji();
			s[3] = sa.getGrad();
			s[4] = String.valueOf(sa.getScoreAll());
			s[5] = String.valueOf(sa.getXuefenAll());
			tablemodel.addRow(s);
		}
	}
}
