package view_student;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JButton;

import model.Student;
import dao.StudentDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;

public class AddStudent_add extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_5;
	String sex="��";
	DefaultTableModel tablemodel = null;
	JRadioButton radioButton,radioButton_1;
	JComboBox comboBox;
	private JTextField textField_3;
	private JTable table;
	private JTextField textField_4;
	String stp="";
;	/**
	 * Create the panel.
	 */
	public AddStudent_add() {
		setLayout(null);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(25, 38, 72, 30);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(111, 43, 243, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(25, 95, 72, 30);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u5E74\u9F84");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(25, 147, 72, 30);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u6027\u522B");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(492, 38, 72, 30);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u73ED\u7EA7");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(492, 95, 72, 30);
		add(label_4);
		
		JLabel label_5 = new JLabel("\u5BC6\u7801");
		label_5.setFont(new Font("����", Font.PLAIN, 20));
		label_5.setBounds(492, 147, 72, 30);
		add(label_5);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(111, 100, 243, 24);
		add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(111, 152, 243, 24);
		add(textField_2);
		
		textField_5 = new JTextField();
		textField_5.setText("123456");
		textField_5.setEditable(false);
		textField_5.setColumns(10);
		textField_5.setBounds(570, 152, 243, 24);
		add(textField_5);
		
		 radioButton = new JRadioButton("\u7537");
		 radioButton.setSelected(true);
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					radioButton_1.setSelected(false);
					sex="��";
				}
			}
		});
		radioButton.setBounds(574, 42, 72, 27);
		add(radioButton);
		radioButton_1 = new JRadioButton("\u5973");
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if(radioButton_1.isSelected()){
					radioButton.setSelected(false);
					sex="Ů";
				}
			
			}
		});
		radioButton_1.setBounds(717, 42, 62, 27);
		add(radioButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(25, 272, 846, 197);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss = {"ѧ��","����","����","����","�Ա�","�༶","�꼶"};
		tablemodel.setColumnIdentifiers(ss);
		table.validate();//ˢ��
		String sql = "select * from student";
		SelectStudent sst = new SelectStudent();
		sst.queryAllScore(tablemodel, sql);
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("\u5BFC\u5165\u6DFB\u52A0");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					System.out.println("��");
					JFileChooser jfc = new JFileChooser();
					jfc.setDialogTitle("��ѡ���ļ�");
					jfc.showOpenDialog(null);
					jfc.setVisible(true);
					//��ȡ�û���ѡ��Ķ����ļ�
					File file =jfc.getSelectedFile();
					String s1 = file.toString();
					s1=s1.replace("\\","\\\\");
					stp=s1;
				File file1 = new File(stp);
				int k=0;
				int s2=0;
				try {	
					String[][] add = readColumn(file, 8);
					System.out.println(add[0][1]);
					for(int i=1;i<add.length;i++){
						    StudentDao sd = new StudentDao();
							Student s = new Student();
							s.setId(add[i][0]);
							s.setName(add[i][1]);
							s.setPassword(add[i][2]);
							s.setAge(Integer.valueOf(add[i][3]));
							s.setSex(add[i][4]);
							s.setBanji(add[i][5]);
							if(add[i][6].equals("")){
							  s.setGrad(add[i][0].charAt(0)+""+add[i][0].charAt(1)+""+add[i][0].charAt(2)+""+add[i][0].charAt(3));
							}else{
								s.setGrad(add[i][6]);
							}
							if(add[i][7].equals("")){
								s.setToxiang("C:\\\\Users\\\\GUOJI\\\\Desktop\\\\javas\\\\xia.png");
								}else{
									s.setToxiang(add[i][7]);
								}
							;
							k=sd.add(s);
							if(k>0){
								s2=k;
							}
						}
						
					} 
					 catch (Exception e) {
						 e.printStackTrace();
					}
				if(s2>0){
					JOptionPane.showMessageDialog(null,"�ɹ������ܲ����������������޷������ӣ�");
					SelectStudent sst = new SelectStudent();
					String sql = "select * from student";
					sst.queryAllScore(tablemodel, sql);
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
				}
				else{
					JOptionPane.showMessageDialog(null,"ʧ�ܣ����������޷������ӣ�");
				}
					
				
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(87, 220, 113, 27);
		add(button);
		
		JButton button_1 = new JButton("\u786E\u8BA4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textField.getText().equals("")||textField_1.getText().equals("")||textField_2.getText().equals("")||textField_3.getText().equals("")||textField_5.getText().equals("")||sex.equals("")){
					JOptionPane.showMessageDialog(null,"ʧ�ܣ�������Ϣ��ȫ��");
					return;
				}		
				int k=0;
				StudentDao sd = new StudentDao();
				Student s = new Student();
				s.setId(textField.getText());
				s.setName(textField_1.getText());
				s.setPassword(textField_5.getText());
				if(Integer.valueOf(textField_2.getText())<0||Integer.valueOf(textField_2.getText())>80){
					JOptionPane.showMessageDialog(null,"ʧ��(������Ϣ����ȷ(0--80֮��))");
					return;
				}
				s.setAge(Integer.valueOf(textField_2.getText()) );
				s.setSex(sex);
				s.setBanji(textField_3.getText());
				String grad =String.valueOf(textField.getText().charAt(0))+String.valueOf(textField.getText().charAt(1))+String.valueOf(textField.getText().charAt(2))+String.valueOf(textField.getText().charAt(3));
				s.setGrad(grad);
				s.setToxiang("C:\\\\Users\\\\GUOJI\\\\Desktop\\\\javas\\\\xia.png");
				k=sd.add(s);
			if(k>0){
				JOptionPane.showMessageDialog(null,"�ɹ�");
				SelectStudent sst = new SelectStudent();
				String sql = "select * from student";
				sst.queryAllScore(tablemodel, sql);
				textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
			else{
				JOptionPane.showMessageDialog(null,"ʧ��(���ݿ��ܴ���)");
			}
		  }
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(403, 220, 113, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u91CD\u7F6E");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				radioButton.setSelected(true);
				radioButton_1.setSelected(false);
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(700, 222, 113, 27);
		add(button_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(570, 100, 243, 24);
		add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setForeground(Color.RED);
		textField_4.setFont(new Font("����", Font.PLAIN, 20));
		textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
		textField_4.setEditable(false);
		textField_4.setBounds(768, 482, 100, 24);
		add(textField_4);
		textField_4.setColumns(10);
	}
	public static String[][] readColumn(File file, int index) throws Exception {
		InputStream inputStream = new FileInputStream(file.getAbsoluteFile());

		// �½�����ȡ������
		Workbook workbook = Workbook.getWorkbook(inputStream);

		// ��ȡ��������index��0��ʼ��0��ӦSheet1
		Sheet sheet = workbook.getSheet(0);

		// ��ȡExcel����
		int rows = sheet.getRows();

		// ��ȡExcel����
		int columns = sheet.getColumns();
		String[][] s = new String[rows][index];
		for (int i = 0; i < rows; i++) {
			// ��ȡ��Ԫ��
			for(int j=0;j<index;j++){
				Cell cell = sheet.getCell(j, i);
				// ��ȡ��Ԫ������
				s[i][j]=cell.getContents();
			}
		}
		return s;
	}
}
