package view_student;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JRadioButton;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Calendar;
import java.util.List;

import javax.swing.JScrollPane;

import dao.StudentDao;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.Student;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import javax.swing.JComboBox;

public class DeleteStudent extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table;
	DefaultTableModel tablemodel;
	JRadioButton radioButton_1,radioButton;
	String file_print;
	JComboBox comboBox;
	/**
	 * Create the panel.
	 */
	public DeleteStudent() {
		setLayout(null);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(52, 56, 62, 26);
		add(label);
		
		JButton btnNewButton = new JButton("\u5220\u9664\u5E94\u5C4A\u6BD5\u4E1A\u751F");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentDao s =new StudentDao();
				Calendar now = Calendar.getInstance();//��ȡʱ��,����
				int k1=now.get(Calendar.YEAR);
				String k_1 =String.valueOf(k1-4);
				int k=s.deleteGrad(k_1);
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectStudent sst = new SelectStudent();
					sst.queryAllScore(tablemodel,"select * from student");
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���/Ҳ���ܲ�����)");
				}
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.setBounds(315, 13, 195, 27);
		add(btnNewButton);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(52, 113, 62, 26);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u73ED\u7EA7");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(52, 174, 62, 26);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u5E74\u9F84");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(480, 56, 62, 26);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u6027\u522B");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(480, 113, 62, 26);
		add(label_4);
		
		textField = new JTextField();
		textField.setBounds(131, 59, 205, 24);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(128, 116, 208, 24);
		add(textField_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(556, 59, 205, 24);
		add(textField_3);
		
		radioButton = new JRadioButton("\u7537");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					radioButton_1.setSelected(false);
				}
			
			}
		});
		radioButton.setBounds(564, 115, 73, 27);
		add(radioButton);
		
		radioButton_1 = new JRadioButton("\u5973");
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton_1.isSelected()){
					radioButton.setSelected(false);
				}
			}
		});
		radioButton_1.setBounds(688, 115, 73, 27);
		add(radioButton_1);
		
		JButton btnNewButton_1 = new JButton("\u5BFC\u51FA\u5907\u4EFD");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(file_print.equals("")){
					JOptionPane.showMessageDialog(null,"��ѡ���ļ�");
					return;
				}
				try
				{
					//���ļ�
					WritableWorkbook book=
					Workbook.createWorkbook(new File(file_print+".xls"));
					//������Ϊ����һҳ���Ĺ�����������0��ʾ���ǵ�һҳ
					WritableSheet sheet=book.createSheet("��һҳ",0);
					//��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
					//�Լ���Ԫ������Ϊtest
					String[] ss = {"ѧ��","����","����","����","�Ա�","�༶","�꼶","ͷ��"};
					for(int i=0;i<ss.length;i++){
						Label label=new Label(i,0,ss[i]);
						sheet.addCell(label);
					}
				
					for(int i=1;i<tablemodel.getRowCount()+1;i++){
						for(int j=0;j<ss.length-1;j++){
							Label label=new Label(j,i,(String) table.getValueAt(i-1,j));
							//������õĵ�Ԫ�����ӵ���������
							sheet.addCell(label);
						}
					}
					for(int i=1;i<tablemodel.getRowCount()+1;i++){
						    StudentDao sd =new StudentDao();
						    String sql = "select * from student where id='"+(String) table.getValueAt(i-1,0)+"'";
						    List<Student> lt = sd.queryAll(sql);
						    Student s = lt.get(0);
							Label label=new Label(7,i,s.getToxiang());
							//������õĵ�Ԫ�����ӵ���������
							sheet.addCell(label);
					}
					
					//д�����ݲ��ر��ļ�
					JOptionPane.showMessageDialog(null,"�ɹ�");
					book.write();
					book.close();
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
		});
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton_1.setBounds(717, 194, 122, 27);
		add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 242, 855, 231);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss = {"ѧ��","����","����","����","�Ա�","�༶","�꼶"};
		tablemodel.setColumnIdentifiers(ss);
		SelectStudent sst = new SelectStudent();
		sst.queryAllScore(tablemodel,"select * from student");
		table.validate();//ˢ��
		scrollPane.setViewportView(table);
		
		textField_4 = new JTextField();
		textField_4.setForeground(Color.RED);
		textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
		textField_4.setFont(new Font("����", Font.PLAIN, 18));
		textField_4.setEditable(false);
		textField_4.setBounds(764, 486, 105, 24);
		add(textField_4);
		textField_4.setColumns(10);
		
		JButton button = new JButton("\u5220\u9664");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentDao s =new StudentDao();
				int k=s.deleteId(textField.getText());
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectStudent sst = new SelectStudent();
					sst.queryAllScore(tablemodel,"select * from student");
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(372, 58, 73, 27);
		add(button);
		
		JButton button_1 = new JButton("\u5220\u9664");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentDao s =new StudentDao();
				int k=s.deleteName(textField_1.getText());
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectStudent sst = new SelectStudent();
					sst.queryAllScore(tablemodel,"select * from student");
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(372, 115, 73, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u5220\u9664");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentDao s =new StudentDao();
				int k=s.deleteBanji(String.valueOf(comboBox.getSelectedItem()));
				comboBox.removeItem(String.valueOf(comboBox.getSelectedItem()));
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectStudent sst = new SelectStudent();
					sst.queryAllScore(tablemodel,"select * from student");
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}
				else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(372, 176, 73, 27);
		add(button_2);
		
		JButton button_3 = new JButton("\u5220\u9664");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentDao s =new StudentDao();
				int k=s.deleteAge(Integer.valueOf(textField_3.getText()));
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectStudent sst = new SelectStudent();
					sst.queryAllScore(tablemodel,"select * from student");
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(796, 58, 73, 27);
		add(button_3);
		
		JButton button_4 = new JButton("\u5220\u9664");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentDao s =new StudentDao();
				int k=0;
				if(radioButton.isSelected()){
					k=s.deleteSex("��");
				}
				else if(radioButton_1.isSelected()){
					k=s.deleteSex("Ů");
				}
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					table.validate();//ˢ��
					SelectStudent sst = new SelectStudent();
					sst.queryAllScore(tablemodel,"select * from student");
					textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			
			}
		});
		button_4.setFont(new Font("����", Font.PLAIN, 18));
		button_4.setBounds(796, 115, 73, 27);
		add(button_4);
		
		JLabel label_5 = new JLabel("\u9009\u62E9\u4F4D\u7F6E");
		label_5.setFont(new Font("����", Font.PLAIN, 18));
		label_5.setBounds(479, 178, 88, 18);
		add(label_5);
		
		final JButton btnNewButton_2 = new JButton("\u6587\u4EF6");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("��");
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("��ѡ���ļ�");
				jfc.showOpenDialog(null);
				jfc.setVisible(true);
				//��ȡ�û���ѡ��Ķ����ļ�
				File file =jfc.getSelectedFile();
				String s = file.toString();
				s=s.replace("\\","\\\\");
				file_print=s;
				btnNewButton_2.setText(file_print);
			}
		});
		btnNewButton_2.setBounds(480, 196, 223, 27);
		add(btnNewButton_2);
		
		comboBox = new JComboBox();
		comboBox.setBounds(128, 177, 208, 24);
		add(comboBox);
		StudentDao sd = new StudentDao();
		List<Student> list = sd.query("select * from student");
		for (int i = 0; i < list.size() - 1; i++) {
            for (int j = list.size() - 1; j > i; j--) {
                if (list.get(j).getBanji().equals(list.get(i).getBanji())) {
                	list.remove(j);
                }
            }
		}
            for(int d=0;d<list.size();d++){
            	comboBox.addItem(list.get(d).getBanji());
            }

	}
}
