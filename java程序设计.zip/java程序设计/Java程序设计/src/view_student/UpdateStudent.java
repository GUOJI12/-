package view_student;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

import dao.StudentDao;
import model.Student;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateStudent extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_5;
	private JTextField textField_4;
	private JTable table;
	DefaultTableModel tablemodel=null;
	String id;
	String name;
	String password;
	int  age;
	String sex;
	String banji;
	String grad;
	JRadioButton radioButton,radioButton_1;
	/**
	 * Create the panel.
	 */
	public UpdateStudent() {
		setLayout(null);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(68, 13, 58, 24);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(140, 15, 212, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(68, 80, 58, 24);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u73ED\u7EA7");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(68, 152, 58, 24);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u5E74\u9F84");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(447, 18, 58, 24);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u6027\u522B");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(447, 80, 58, 24);
		add(label_4);
		
		JLabel label_5 = new JLabel("\u5BC6\u7801");
		label_5.setFont(new Font("����", Font.PLAIN, 20));
		label_5.setBounds(447, 140, 58, 24);
		add(label_5);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(140, 82, 212, 24);
		add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(140, 154, 212, 24);
		add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(519, 15, 212, 24);
		add(textField_3);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(519, 142, 212, 24);
		add(textField_5);
		
		radioButton = new JRadioButton("\u7537");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					radioButton_1.setSelected(false);
				}
			}
		});
		radioButton.setBounds(515, 81, 63, 27);
		add(radioButton);
		
		radioButton_1 = new JRadioButton("\u5973");
		radioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton_1.isSelected()){
					radioButton.setSelected(false);
				}
			
			}
		});
		radioButton_1.setBounds(668, 81, 63, 27);
		add(radioButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 240, 840, 235);
		add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//��ȡ�ı�
				int count = table.getSelectedRow();//��ȡ��������к�
				id = (String) table.getValueAt(count, 0);
				name=(String) table.getValueAt(count, 1);
				password=(String) table.getValueAt(count, 2);
				age=Integer.parseInt((String) table.getValueAt(count, 3));
				sex=(String) table.getValueAt(count, 4);
				banji=(String) table.getValueAt(count, 5);
				grad =(String) table.getValueAt(count, 6);
				textField.setText(id);
				textField_1.setText(name);
				textField_5.setText(password);
				textField_3.setText(age+"");
				textField_2.setText(banji);
				if(sex.equals("��")){
					radioButton.setSelected(true);
					radioButton_1.setSelected(false);
				}else if(sex.equals("Ů")){
					radioButton_1.setSelected(true);
					radioButton.setSelected(false);
				}
			}
		});
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss = {"ѧ��","����","����","����","�Ա�","�༶","�꼶"};
		tablemodel.setColumnIdentifiers(ss);
		SelectStudent sst = new SelectStudent();
		String sql ="select * from student";
		sst.queryAllScore(tablemodel, sql);
		table.validate();//ˢ��
		scrollPane.setViewportView(table);
		
		textField_4 = new JTextField();
		textField_4.setForeground(Color.RED);
		textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
		textField_4.setFont(new Font("����", Font.PLAIN, 18));
		textField_4.setEditable(false);
		textField_4.setBounds(749, 483, 106, 24);
		add(textField_4);
		textField_4.setColumns(10);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Student s =new Student();
				StudentDao sd =new StudentDao();
				if(!id.equals(textField.getText())){
					s.setId(id);
					textField.setText(id);
					JOptionPane.showMessageDialog(null,"ѧ�Ų����޸�");
					return;
				}
				System.out.println("sad");
				s.setId(textField.getText());
				s.setName(textField_1.getText());
				s.setPassword(textField_5.getText());
				s.setAge(Integer.valueOf(textField_3.getText()));
				if(radioButton.isSelected()){
					s.setSex("��");
				}else if(radioButton_1.isSelected()){
					s.setSex("Ů");
				}
				s.setBanji(textField_2.getText());
				int k=sd.update(s);
				System.out.println(k);
				if(k>0){
					SelectStudent sst = new SelectStudent();
					sst.queryAllScore(tablemodel, "select * from student");
					table.validate();
					JOptionPane.showMessageDialog(null,"�ɹ�");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(526, 200, 113, 27);
		add(button);
		
		JButton button_1 = new JButton("\u67E5\u627E");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from student where id="+textField.getText();
				SelectStudent sst = new SelectStudent();
				sst.queryAllScore(tablemodel,sql);
				textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			
			}
		});
		button_1.setBounds(366, 14, 63, 27);
		add(button_1);
		
		JLabel lblNewLabel = new JLabel("*\u6CE8:\u53EF\u9009\u62E9\u4E0B\u9762\u8868\u683C\u91CC\u7684\u5185\u5BB9\uFF0C\u4E5F\u53EF\u4EE5\u67E5\u627E\u5185\u5BB9");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(115, 206, 358, 18);
		add(lblNewLabel);
		
		JButton button_2 = new JButton("\u5168\u90E8\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from student";
				SelectStudent sst = new SelectStudent();
				sst.queryAllScore(tablemodel,sql);
				textField_4.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button_2.setBounds(668, 200, 142, 27);
		add(button_2);

	}
}
