package view_student;

import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.Font;
import java.util.List;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Student;
import dao.StudentDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class SelectStudent extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	DefaultTableModel tablemodel = null;
	JRadioButton radioButton,rdbtnNewRadioButton;
	private JTextField textField_3;
	int flaf= 0;

	/**
	 * Create the panel.
	 */
	public SelectStudent() {
		setLayout(null);
		
		JButton button = new JButton("\u67E5\u8BE2\u5168\u90E8");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				queryAllScore(tablemodel,"select * from student");
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
				}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(251, 10, 123, 29);
		add(button);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(180, 59, 77, 29);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(305, 63, 236, 24);
		add(textField);
		textField.setColumns(10);
		
		JButton button_1 = new JButton("\u6309\u5B66\u53F7\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from student where id="+textField.getText();
				queryAllScore(tablemodel,sql);
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 20));
		button_1.setBounds(619, 62, 166, 27);
		add(button_1);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(180, 101, 77, 29);
		add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(305, 100, 236, 24);
		add(textField_1);
		textField_1.setColumns(10);
		
		JButton button_2 = new JButton("\u6309\u59D3\u540D\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				table.validate();
				String sql = "select * from student where name="+"'"+textField_1.getText()+"'";
				queryAllScore(tablemodel,sql);
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 20));
		button_2.setBounds(619, 102, 166, 27);
		add(button_2);
		
		JLabel label_2 = new JLabel("\u6027\u522B");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(180, 143, 77, 29);
		add(label_2);
		
		rdbtnNewRadioButton = new JRadioButton("\u7537");
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(rdbtnNewRadioButton.isSelected()){
					radioButton.setSelected(false);
				}
			}
		});
		rdbtnNewRadioButton.setBounds(309, 146, 62, 27);
		add(rdbtnNewRadioButton);
		
		radioButton = new JRadioButton("\u5973");
		radioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					rdbtnNewRadioButton.setSelected(false);
				}
			
			}
		});
		radioButton.setBounds(467, 146, 62, 27);
		add(radioButton);
		
		JButton button_3 = new JButton("\u6309\u6027\u522B\u67E5\u8BE2");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(radioButton.isSelected()){
					tablemodel.setRowCount(0);
					table.validate();
					String sql = "select * from student where sex="+"'"+"Ů"+"'";
					queryAllScore(tablemodel,sql);
					textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
				}
				if(rdbtnNewRadioButton.isSelected()){
					tablemodel.setRowCount(0);
					table.validate();
					String sql = "select * from student where sex="+"'"+"��"+"'";
					queryAllScore(tablemodel,sql);
					textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
				}
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 20));
		button_3.setBounds(619, 142, 166, 27);
		add(button_3);
		
		JLabel label_3 = new JLabel("\u73ED\u7EA7");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(180, 185, 77, 29);
		add(label_3);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(305, 182, 236, 24);
		add(comboBox);
		StudentDao sd = new StudentDao();
		List<Student> list = sd.query("select * from student");
		for (int i = 0; i < list.size() - 1; i++) {
            for (int j = list.size() - 1; j > i; j--) {
                if (list.get(j).getBanji().equals(list.get(i).getBanji())) {
                	list.remove(j);
                }
            }
		}
            for(int d=0;d<list.size();d++){
            	comboBox.addItem(list.get(d).getBanji());
            }
		

		JButton button_4 = new JButton("\u6309\u73ED\u7EA7\u67E5\u8BE2");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				table.validate();
				String sql = "select * from student where banji="+"'"+comboBox.getSelectedItem()+"'";
				queryAllScore(tablemodel,sql);
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			
			}
		});
		button_4.setFont(new Font("����", Font.PLAIN, 20));
		button_4.setBounds(619, 186, 166, 27);
		add(button_4);
		
		JLabel label_4 = new JLabel("\u5E74\u9F84");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(180, 227, 77, 29);
		add(label_4);
		
		textField_2 = new JTextField();
		textField_2.setBounds(305, 231, 236, 24);
		add(textField_2);
		textField_2.setColumns(10);
		
		JButton button_5 = new JButton("\u6309\u5E74\u9F84\u67E5\u8BE2");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				table.validate();
				String sql = "select * from student where age="+textField_2.getText();
				queryAllScore(tablemodel,sql);
				textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button_5.setFont(new Font("����", Font.PLAIN, 20));
		button_5.setBounds(619, 228, 166, 27);
		add(button_5);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 269, 867, 209);
		add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("����", Font.PLAIN, 16));
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss = {"ѧ��","����","����","����","�Ա�","�༶","�꼶"};
		tablemodel.setColumnIdentifiers(ss);
		table.validate();//ˢ��
		scrollPane.setViewportView(table);
		
		textField_3 = new JTextField();
		textField_3.setForeground(Color.RED);
		textField_3.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
		textField_3.setFont(new Font("����", Font.PLAIN, 18));
		textField_3.setEditable(false);
		textField_3.setBounds(781, 479, 89, 24);
		add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("\u6743\u9650\u7801");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(tablemodel.getRowCount()<0){
					JOptionPane.showMessageDialog(null,"���Ȳ�ѯѧ��");
					return;
				}
				int x=0;
				for(int tm=0;tm<tablemodel.getRowCount();tm++){
					String id =(String) table.getValueAt(tm, 0);
					StudentDao sd =new StudentDao();
					Random r =new Random();
					int sum=0;
					for(int i=0;i<4;i++){
						sum=sum+r.nextInt(1000);
					}
					int k = sd.updateq(id, sum);
					x=x+k;
					sum=0;
				}
				if(x==tablemodel.getRowCount()){
					JOptionPane.showMessageDialog(null,"�ɹ�");
				}
					
				
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.setBounds(495, 12, 113, 27);
		add(btnNewButton);
		
		JLabel label_5 = new JLabel("*\u6CE8\uFF1A\u7ED9\u6240\u6709\u5B66\u751F\u968F\u673A\u6743\u9650\u7801\uFF0C\u6743\u9650\u7801\u4EC5\u6709\u6821\u7BA1\u7406\u5458\u8BFE\u770B");
		label_5.setForeground(Color.RED);
		label_5.setFont(new Font("����", Font.PLAIN, 13));
		label_5.setBounds(505, 40, 337, 18);
		add(label_5);

	}
	public static void queryAllScore(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		StudentDao sd = new StudentDao();
		List<Student> list = sd.query(sql);
		String[] s = new String[7];
		for(int i=0;i<list.size();i++)
		{
			Student student=list.get(i);			
			s[0]=student.getId();
			s[1]=student.getName();
			s[2]=student.getPassword();
			s[3]=String.valueOf(student.getAge());
			s[4]=student.getSex();
			s[5]=student.getBanji();
			s[6]=student.getGrad();
			tablemodel.addRow(s);
		}
	}
}
