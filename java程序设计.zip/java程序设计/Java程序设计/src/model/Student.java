package model;

public class Student {//ѧ����set/get
	String id;
	String name;
	String password;
	int  age;
	String sex;
	String banji;
	String grad;
	String toxiang;
	String pnum;
	String gexing;
	public String getPnum() {
		return pnum;
	}
	public void setPnum(String pnum) {
		this.pnum = pnum;
	}
	public String getGexing() {
		return gexing;
	}
	public void setGexing(String gexing) {
		this.gexing = gexing;
	}
	public String getBanji() {
		return banji;
	}
	public void setBanji(String banji) {
		this.banji = banji;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getGrad() {
		return grad;
	}
	public void setGrad(String grad) {
		this.grad = grad;
	}
	public String getToxiang() {
		return toxiang;
	}
	public void setToxiang(String toxiang) {
		this.toxiang = toxiang;
	}
	
}
