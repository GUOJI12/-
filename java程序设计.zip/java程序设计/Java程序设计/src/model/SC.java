package model;

public class SC {
	String id;
	String courseName;
	double score;
	String teacherNo;
	String teacherName;
	String zhuantai;
	String guake;
	String sjtai;
	public String getSjtai() {
		return sjtai;
	}
	public void setSjtai(String sjtai) {
		this.sjtai = sjtai;
	}
	public String getGuake() {
		return guake;
	}
	public void setGuake(String guake) {
		this.guake = guake;
	}
	public String getZhuantai() {
		return zhuantai;
	}
	public void setZhuantai(String zhuantai) {
		this.zhuantai = zhuantai;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public String getTeacherNo() {
		return teacherNo;
	}
	public void setTeacherNo(String teacherNo) {
		this.teacherNo = teacherNo;
	}

}
