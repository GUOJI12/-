package model;

public class ScoreAll {
	String id;
	String name;
	String banji;
	String grad;
	double scoreAll;
	double xuefenAll;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBanji() {
		return banji;
	}
	public void setBanji(String banji) {
		this.banji = banji;
	}
	public String getGrad() {
		return grad;
	}
	public void setGrad(String grad) {
		this.grad = grad;
	}
	public double getScoreAll() {
		return scoreAll;
	}
	public void setScoreAll(double scoreAll) {
		this.scoreAll = scoreAll;
	}
	public double getXuefenAll() {
		return xuefenAll;
	}
	public void setXuefenAll(double xuefenAll) {
		this.xuefenAll = xuefenAll;
	}

}
