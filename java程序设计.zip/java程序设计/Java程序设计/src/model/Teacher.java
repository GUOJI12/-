package model;

public class Teacher {
	String teacherNo;
	String teacherName;
	int teacherAge;
	String teacherSex;
	String teacherPasswd;
	String teacherToxiang;
	String mobileNum;
	String teacherWen;
	double teacherWork;
	String teacherMess;
	public String getTeacherToxiang() {
		return teacherToxiang;
	}
	public void setTeacherToxiang(String teacherToxiang) {
		this.teacherToxiang = teacherToxiang;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public String getTeacherWen() {
		return teacherWen;
	}
	public void setTeacherWen(String teacherWen) {
		this.teacherWen = teacherWen;
	}
	public Double getTeacherWork() {
		return teacherWork;
	}
	public void setTeacherWork(Double teacherWork) {
		this.teacherWork = teacherWork;
	}
	public String getTeacherMess() {
		return teacherMess;
	}
	public void setTeacherMess(String teacherMess) {
		this.teacherMess = teacherMess;
	}
	public String getTeacherPasswd() {
		return teacherPasswd;
	}
	public void setTeacherPasswd(String teacherPasswd) {
		this.teacherPasswd = teacherPasswd;
	}
	public String getTeacherNo() {
		return teacherNo;
	}
	public void setTeacherNo(String teacherNo) {
		this.teacherNo = teacherNo;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public int getTeacherAge() {
		return teacherAge;
	}
	public void setTeacherAge(int teacherAge) {
		this.teacherAge = teacherAge;
	}
	public String getTeacherSex() {
		return teacherSex;
	}
	public void setTeacherSex(String teacherSex) {
		this.teacherSex = teacherSex;
	}
}
