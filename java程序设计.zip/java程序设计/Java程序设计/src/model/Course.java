package model;

public class Course {
	String courseID;
	String courseName;
	String xingzhi;
	double xuefen;
	double xueshi;
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getXingzhi() {
		return xingzhi;
	}
	public void setXingzhi(String xingzhi) {
		this.xingzhi = xingzhi;
	}
	public double getXuefen() {
		return xuefen;
	}
	public void setXuefen(double xuefen) {
		this.xuefen = xuefen;
	}
	public double getXueshi() {
		return xueshi;
	}
	public void setXueshi(double xueshi) {
		this.xueshi = xueshi;
	}
	
}
