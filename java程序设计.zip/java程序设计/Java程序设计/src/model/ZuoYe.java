package model;

public class ZuoYe {
	String teacherNo;
	String statTime;
	String courseName;
	String jiezhiTime;
	String neiRong;
	String banji;
	String title;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTeacherNo() {
		return teacherNo;
	}
	public void setTeacherNo(String teacherNo) {
		this.teacherNo = teacherNo;
	}
	public String getStatTime() {
		return statTime;
	}
	public void setStatTime(String statTime) {
		this.statTime = statTime;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getJiezhiTime() {
		return jiezhiTime;
	}
	public void setJiezhiTime(String jiezhiTime) {
		this.jiezhiTime = jiezhiTime;
	}
	public String getNeiRong() {
		return neiRong;
	}
	public void setNeiRong(String neiRong) {
		this.neiRong = neiRong;
	}
	public String getBanji() {
		return banji;
	}
	public void setBanji(String banji) {
		this.banji = banji;
	}

}
