package bing;
 
 
import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
 
//�������࣬���ڴ��������PortWaiter�Ĵ��������Լ���ͻ��˷�����Ϣ��
class Client extends Thread{
    Socket server;
    JTextArea messageArea;
    BufferedReader br;
    BufferedWriter bw;
    InputStream is;
    OutputStream os;
    int port;
    String address;
    Client(int port, JTextArea msgArea, String address) {
        this.port = port;
        this.messageArea = msgArea;
        this.address = address;
        this.start();
    }
 
    @Override
    public void run() {
        super.run();
        try {
            server = new Socket(address, port);
            messageArea.append("- �����ӵ����� " + server.getInetAddress().getLocalHost() + "\n");
            is = server.getInputStream();
            os = server.getOutputStream();
            br = new BufferedReader(new InputStreamReader(is));
            bw = new BufferedWriter(new OutputStreamWriter(os));
            while(true) {
                String newMsg = br.readLine();
                if (newMsg != null) {
                    messageArea.append(">> " + newMsg + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            if(e instanceof java.net.ConnectException)
                messageArea.append("- �޷����ӵ������������Ի����ַ�Ͷ˿ڡ�" + "\n");
            else
                messageArea.append("- ��Զ�������������ѶϿ���\n");
        }
    }
 
    public void sendMsg(String msg) {
        System.out.println("sendMsg");
        try {
            bw.write(msg + "\n");
            bw.flush();
            messageArea.append("                       "
            		+ "                                                                              ��:" + msg + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}