package bing;

import javax.swing.*;
 
public class Main {
 
    public static void main(String[] args) {
 
    	ClientWindow mainWindow = new ClientWindow();
 
    }
}