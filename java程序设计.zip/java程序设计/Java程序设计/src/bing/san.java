package bing;

import java.util.List;

import model.SC;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.RectangleInsets;

import View_main.DenLu;
import dao.StudentDao;
public class san{
	public static void main(String[] args){
		
		// ��һ���������ݼ�
		DefaultPieDataset dataset = new DefaultPieDataset();
		DenLu dl =new DenLu();
		String scv = dl.getId();
		StudentDao sd = new StudentDao();
		String sql="select * from sc where id='"+scv+"'";
		double numscore=sd.sum(sql);
		List<SC> list=sd.query_b(sql);
		int ts=sd.tj(sql);
		int s=ts;
		for(int i=0;i<ts;i++)
		{
			SC sc=list.get(i);
			String name=sc.getCourseName();
			sc.getScore();
			dataset.setValue(name+"("+sc.getScore()+"��)", sc.getScore());
			System.out.println("1");
		}
		// �ڶ�������һ��JFreeChart����
		JFreeChart chart1 = ChartFactory.createPieChart(
				"��һ����ͼ",
				dataset, true, // �Ƿ���ͼע
				true, // �Ƿ�����ʾ
				false // �Ƿ���URLS
				);
		// ������������ʾ
	
		PiePlot3D plot =new PiePlot3D(dataset);
		plot.setDepthFactor(0.10);
		plot.setShadowPaint(null);
		plot.setInsets(new RectangleInsets(100, 150, 100, 150));
		// ���ñ�ͼ����ʼ�Ƕ�
		plot.setStartAngle(45);
		plot.setForegroundAlpha(0.8f);
		plot.setBackgroundAlpha(0.9f);
		JFreeChart chart = new JFreeChart("�ɼ�����", JFreeChart.DEFAULT_TITLE_FONT, plot, true);
		chart.setBackgroundPaint(java.awt.Color.white);
		ChartFrame frame1 = new ChartFrame("test1", chart);
		frame1.setBounds(0, 0, 300, 300);
		frame1.pack();
		frame1.setVisible(true);
	}
}