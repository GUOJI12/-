package view_student_Main;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;
import java.util.List;

import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;

import View_main.DenLu;
import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.StudentDao;

public class StudnetSelet_scjie extends JPanel {
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	DefaultTableModel tablemodel;
	String studentId;
	private static double xuefenAll=0;
	private static double guakeCount=0;
	private static double scoreAll=0;
	JComboBox comboBox;
	private JTextField textField_2;
	/**
	 * Create the panel.
	 */
	public StudnetSelet_scjie() {
		setLayout(null);
		DenLu dl =new DenLu();
		studentId = dl.getId();
		xuefenAll=0;
		guakeCount=0;
		scoreAll=0;
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u4F7F\u7528\u660E\u5B66\u5DF2\u7ED3\u8BFE\u7A0B\u67E5\u8BE2");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 22));
		lblNewLabel.setBounds(114, 13, 609, 32);
		add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(23, 46, 833, 249);
		add(scrollPane);
		
		comboBox = new JComboBox();
		comboBox.setBounds(467, 389, 200, 24);
		add(comboBox);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�","��ʦ","״̬"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		String sql = "select * from sc,student,teacher where teacher.teacherNo=sc.teacherNo and sc.id=student.id and sc.id=+'"
		+studentId+"' and sc.zhuantai='�ѽ��'";
		queryAllSc_s(tablemodel,sql);
		String sql1 = "select * from sc where id='"+studentId+"' and score<60 and guake='�ҿ�'";
		ScDao sdd =new ScDao();
		List<SC> list = sdd.query1(sql1);
		System.out.println(list.size());
		for(int i=0;i<list.size();i++){
			SC scc =list.get(i);
			comboBox.addItem(scc.getCourseName());
		}
		table.validate();
		textField = new JTextField();
		textField.setText(String.valueOf(xuefenAll));
		textField.setEditable(false);
		textField.setBounds(227, 326, 172, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u5171\u83B7\u5F97\u5B66\u5206");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(97, 327, 116, 18);
		add(label);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.RED);
		textField_1.setText(String.valueOf(guakeCount));
		textField_1.setEditable(false);
		textField_1.setBounds(377, 389, 47, 24);
		add(textField_1);
		textField_1.setColumns(10);
		
		JLabel label_1 = new JLabel("\u5DF2\u6302\u8BFE\u7A0B");
		label_1.setForeground(Color.RED);
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(251, 390, 72, 18);
		add(label_1);
		
	
		
		JLabel label_2 = new JLabel("\u6709");
		label_2.setForeground(Color.BLACK);
		label_2.setBounds(355, 392, 21, 18);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u6761");
		label_3.setBounds(426, 392, 21, 18);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u603B\u5206");
		label_4.setFont(new Font("����", Font.PLAIN, 18));
		label_4.setBounds(439, 327, 56, 18);
		add(label_4);
		
		textField_2 = new JTextField();
		textField_2.setText(String.valueOf(scoreAll));
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(509, 326, 152, 24);
		add(textField_2);

	}
	public static void queryAllSc_s(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ScDao sd = new ScDao();
		StudentDao st =new StudentDao();
		CourseDao cd =new CourseDao();
		List<SC> list = sd.query(sql);
		String[] s = new String[10];
		for(int i=0;i<list.size();i++)
		{
			SC sc=list.get(i);			
			s[0]=sc.getId();
			List<Student> lss = st.query("select * from student where id="+"'"+sc.getId()+"'");
			Student sv = lss.get(0);
			s[1]=sv.getName();
			s[2]=sc.getCourseName();
			List<Course> cs = cd.query("select * from course where courseName="+"'"+sc.getCourseName()+"'");
			Course c = cs.get(0);
			s[3]=c.getXingzhi();
			s[4]=String.valueOf(c.getXueshi());
			s[5]=String.valueOf(c.getXuefen());
			xuefenAll=xuefenAll+Double.valueOf(s[5]);
			s[6]=String.valueOf(sc.getScore());
			scoreAll=scoreAll+Double.valueOf(s[6]);
			if(Double.valueOf(s[6])<60){
				guakeCount=guakeCount+1;
				xuefenAll=xuefenAll-Double.valueOf(s[5]);
			}
			s[7]=sc.getTeacherName();
			s[8]=sc.getGuake();
			tablemodel.addRow(s);
		}
	}
}
