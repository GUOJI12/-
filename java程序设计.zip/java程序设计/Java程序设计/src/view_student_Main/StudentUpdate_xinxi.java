package view_student_Main;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.Font;
import java.util.List;

import javax.swing.JTextField;
import javax.swing.JTextArea;

import model.Student;
import dao.StudentDao;
import View_main.DenLu;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;

public class StudentUpdate_xinxi extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	String studentId;
	String toxiangs="";
	/**
	 * Create the panel.
	 */
	public StudentUpdate_xinxi() {
		setLayout(null);
		DenLu dl =new DenLu();
		studentId=dl.getId();
		StudentDao sd = new StudentDao();
		String sql="select * from student where id='"+studentId+"'";
		List<Student> ls = sd.queryAll(sql);
		final Student s =ls.get(0);
		
		final JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("�ѱ���");
				jfc.showSaveDialog(null);
				File file =jfc.getSelectedFile();
				String s1= file.toString();
				String files = s1.replace("\\","\\\\");
				System.out.println(files.charAt(files.length()-1));
				if((files.charAt(files.length()-1)!='g'&&files.charAt(files.length()-2)!='n'&&files.charAt(files.length()-3)!='p')&&
				   (files.charAt(files.length()-1)!='G'&&files.charAt(files.length()-2)!='N'&&files.charAt(files.length()-3)!='P')&&
				   (files.charAt(files.length()-1)!='f'&&files.charAt(files.length()-2)!='i'&&files.charAt(files.length()-3)!='g'&&
				   (files.charAt(files.length()-1)!='F'&&files.charAt(files.length()-2)!='I'&&files.charAt(files.length()-3)!='G'))){
					JOptionPane.showMessageDialog(null,"����ͼƬ�ļ�");
					toxiangs="";
					return;
				}
				else{
					toxiangs =files;
					btnNewButton.setIcon(new ImageIcon(s.getToxiang()));
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon(s.getToxiang()));
		btnNewButton.setBounds(35, 23, 113, 122);
		add(btnNewButton);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(185, 46, 72, 18);
		add(label);
		
		textField = new JTextField();
		textField.setText(s.getId());
		textField.setEditable(false);
		textField.setBounds(246, 45, 213, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(546, 46, 47, 18);
		add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setText(s.getName());
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(607, 45, 213, 24);
		add(textField_1);
		
		JLabel label_2 = new JLabel("\u5E74\u7EA7");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(185, 135, 72, 18);
		add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setText(s.getGrad());
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(246, 132, 213, 24);
		add(textField_2);
		
		JLabel label_3 = new JLabel("\u73ED\u7EA7");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(546, 135, 72, 18);
		add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setText(s.getBanji());
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(607, 132, 213, 24);
		add(textField_3);
		
		JLabel label_4 = new JLabel("\u624B\u673A\u53F7");
		label_4.setFont(new Font("����", Font.PLAIN, 18));
		label_4.setBounds(353, 275, 72, 18);
		add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setText(s.getPnum());
		textField_4.setColumns(10);
		textField_4.setBounds(439, 274, 213, 24);
		add(textField_4);
		
		JLabel label_5 = new JLabel("\u5E74\u9F84");
		label_5.setFont(new Font("����", Font.PLAIN, 18));
		label_5.setBounds(468, 200, 72, 18);
		add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setText(String.valueOf(s.getAge()));
		textField_5.setColumns(10);
		textField_5.setBounds(546, 197, 213, 24);
		add(textField_5);
		
		JLabel label_6 = new JLabel("\u6027\u522B");
		label_6.setFont(new Font("����", Font.PLAIN, 18));
		label_6.setBounds(76, 200, 72, 18);
		add(label_6);
		
		textField_6 = new JTextField();
		textField_6.setText(s.getSex());
		textField_6.setEditable(false);
		textField_6.setColumns(10);
		textField_6.setBounds(164, 199, 213, 24);
		add(textField_6);
		
		JLabel label_7 = new JLabel("\u4E2A\u6027\u7B7E\u540D");
		label_7.setFont(new Font("����", Font.PLAIN, 18));
		label_7.setBounds(76, 309, 82, 18);
		add(label_7);
		
		final JTextArea textArea = new JTextArea();
		textArea.setText(s.getGexing());
		textArea.setBounds(76, 340, 734, 80);
		add(textArea);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(toxiangs.equals("")){
					toxiangs=s.getToxiang();
				}
				StudentDao sd1 = new StudentDao();
				Student s_do = new  Student();
				s_do.setAge(Integer.valueOf(textField_5.getText()));
				s_do.setPnum(textField_4.getText());
				s_do.setToxiang(toxiangs);
				s_do.setGexing(textArea.getText());
				s_do.setId(studentId);
				int i = sd1.update1(s_do);
				if(i>0){
					JOptionPane.showMessageDialog(null,"����ɹ�");
				}
				else{
					JOptionPane.showMessageDialog(null,"δ֪��������ϵ����Ա");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(389, 442, 113, 27);
		add(button);
		
	}
}
