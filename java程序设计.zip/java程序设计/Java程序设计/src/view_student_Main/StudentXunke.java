package view_student_Main;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import View_main.DenLu;
import model.SC;
import dao.ScDao;
import dao.ShokeDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudentXunke extends JPanel {
	private JTable table;
	DefaultTableModel tablemodel;
	JComboBox comboBox,comboBox_1;
	String studentId;
	/**
	 * Create the panel.
	 */
	public StudentXunke() {
		setLayout(null);
		DenLu dl =new DenLu();
		studentId=dl.getId();
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u4F7F\u7528\u660E\u6587\u9009\u8BFE\u7CFB\u7EDF");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 33));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(88, 13, 703, 63);
		add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 97, 816, 221);
		add(scrollPane);
		
		comboBox = new JComboBox();
		comboBox.setBounds(253, 358, 217, 24);
		add(comboBox);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setBounds(253, 414, 217, 24);
		add(comboBox_1);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"�γ̺�","�γ���","����","ѧʱ","ѧ��","��ʦ"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		ShokeDao sd = new ShokeDao();
		String sql = "select * from shokecha";
		try {
			String[] s = new String[6];
			Object[][] obj = sd.selectAll_course(sql);
			for(int i=0;i<obj.length;i++){
				s[0]=String.valueOf(obj[i][0]);
				comboBox.addItem(s[0]);
				s[1]=String.valueOf(obj[i][1]);
				comboBox_1.addItem(s[1]);
				s[2]=String.valueOf(obj[i][2]);
				s[3]=String.valueOf(obj[i][3]);
				s[4]=String.valueOf(obj[i][4]);
				s[5]=String.valueOf(obj[i][5]);
				tablemodel.addRow(s);
			}
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("\u8BFE\u7A0B");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(35, 71, 72, 18);
		add(label);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u53F7");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(167, 358, 72, 21);
		add(label_1);
		
	
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				ShokeDao sd = new ShokeDao();
				String sql = "select * from shokecha where courseID='"+String.valueOf(comboBox.getSelectedItem())+"'";
				try {
					String[] s = new String[6];
					Object[][] obj = sd.selectAll_course(sql);
					for(int i=0;i<obj.length;i++){
						s[0]=String.valueOf(obj[i][0]);
						s[1]=String.valueOf(obj[i][1]);
						s[2]=String.valueOf(obj[i][2]);
						s[3]=String.valueOf(obj[i][3]);
						s[4]=String.valueOf(obj[i][4]);
						s[5]=String.valueOf(obj[i][5]);
						tablemodel.addRow(s);
					}
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(500, 357, 113, 27);
		add(button);
		
		JButton button_1 = new JButton("\u9009\u8BFE");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				tablemodel.setRowCount(0);
				ShokeDao sd = new ShokeDao();
				String sql = "select * from shokecha where courseID='"+String.valueOf(comboBox.getSelectedItem())+"'";
				try {
					String[] s = new String[6];
					Object[][] obj = sd.selectAll_course(sql);
					s[0] = String.valueOf(obj[0][1]);//�γ���
					s[1] = String.valueOf(obj[0][6]);//��ʦ��
					ScDao sc =new ScDao();
					SC s2 = new SC();
					s2.setId(studentId);
					s2.setCourseName(s[0]);
					s2.setScore(0);
					s2.setTeacherNo(s[1]);
					s2.setZhuantai("�����ڿ�");
					int i=sc.addSc(s2);
					if(i>0){
						JOptionPane.showMessageDialog(null,"ѡ�γɹ�,����鿴ѡ����Ϣ����γ���Ϣ���޼�¼����ϵ����Ա)");
					}
					else{
						JOptionPane.showMessageDialog(null,"�ÿγ��Ѿ�ѡ�����޷��ٴν���ѡ��");
					}
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}

			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(645, 357, 113, 27);
		add(button_1);
		
		JLabel label_2 = new JLabel("\u8BFE\u7A0B\u540D");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(167, 414, 72, 21);
		add(label_2);
		
		
		
		JButton button_2 = new JButton("\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				tablemodel.setRowCount(0);
				ShokeDao sd = new ShokeDao();
				String sql = "select * from shokecha where courseName='"+String.valueOf(comboBox_1.getSelectedItem())+"'";
				try {
					String[] s = new String[6];
					Object[][] obj = sd.selectAll_course(sql);
					for(int i=0;i<obj.length;i++){
						s[0]=String.valueOf(obj[i][0]);
						s[1]=String.valueOf(obj[i][1]);
						s[2]=String.valueOf(obj[i][2]);
						s[3]=String.valueOf(obj[i][3]);
						s[4]=String.valueOf(obj[i][4]);
						s[5]=String.valueOf(obj[i][5]);
						tablemodel.addRow(s);
					}
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(500, 413, 113, 27);
		add(button_2);
		
		JButton button_3 = new JButton("\u9009\u8BFE");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				ShokeDao sd = new ShokeDao();
				String sql = "select * from shokecha where courseName='"+String.valueOf(comboBox_1.getSelectedItem())+"'";
				try {
					String[] s = new String[6];
					Object[][] obj = sd.selectAll_course(sql);
					s[0] = String.valueOf(obj[0][1]);//�γ���
					s[1] = String.valueOf(obj[0][6]);//��ʦ��
					ScDao sc =new ScDao();
					SC s2 = new SC();
					s2.setId(studentId);
					s2.setCourseName(s[0]);
					s2.setScore(0);
					s2.setTeacherNo(s[1]);
					s2.setZhuantai("�����ڿ�");
					int i=sc.addSc(s2);
					if(i>0){
						JOptionPane.showMessageDialog(null,"ѡ�γɹ�,����鿴ѡ����Ϣ����γ���Ϣ���޼�¼����ϵ����Ա)");
					}
					else{
						JOptionPane.showMessageDialog(null,"�ÿγ��Ѿ�ѡ�����޷��ٴν���ѡ��");
					}
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(645, 413, 113, 27);
		add(button_3);
		
		JLabel label_3 = new JLabel("*\u6CE8:\u4E3A\u9632\u6B62\u7F51\u7EDC\u62E5\u5835\uFF0C\u4E25\uD83C\uDE32\u91CD\u590D\u9009\u8BFE\uFF0C\u5982\u9700\u9000\u8BFE\u8054\u7CFB\u7BA1\u7406\u5458");
		label_3.setBounds(155, 474, 403, 18);
		add(label_3);
		
		JButton btnNewButton = new JButton("\u8054\u7CFB\u7BA1\u7406\u5458");
		btnNewButton.setBounds(606, 470, 113, 27);
		add(btnNewButton);
	}
	
}
