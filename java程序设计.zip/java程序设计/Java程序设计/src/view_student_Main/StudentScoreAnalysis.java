package view_student_Main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.StudentDao;
import View_main.DenLu;

public class StudentScoreAnalysis extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JComboBox comboBox;

	/**
	 * Create the panel.
	 */
	public StudentScoreAnalysis() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u60A8\u7684\u603B\u5206\u4E3A\uFF1A");
		lblNewLabel.setBounds(96, 73, 90, 32);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(230, 77, 169, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u6240\u6709\u79D1\u76EE\u6EE1\u5206\u4E3A:");
		label.setBounds(96, 118, 125, 32);
		add(label);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(230, 122, 169, 24);
		add(textField_1);
		
		JLabel label_1 = new JLabel("\u5171\u8BA1\u4E22\u5206\u6570\u4E3A:");
		label_1.setBounds(96, 166, 125, 32);
		add(label_1);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(230, 170, 169, 24);
		add(textField_2);
		
		JLabel label_2 = new JLabel("\u60A8\u7684\u4E22\u5206\u7387\u4E3A:");
		label_2.setBounds(96, 211, 125, 32);
		add(label_2);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(230, 215, 169, 24);
		add(textField_3);
		
		JLabel label_3 = new JLabel("\u8BC4\u4EF7:");
		label_3.setBounds(96, 261, 125, 32);
		add(label_3);
		
		comboBox = new JComboBox();
		comboBox.setForeground(Color.WHITE);
		comboBox.setEnabled(false);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u4F18\u79C0", "\u826F\u597D", "\u53CA\u683C", "\u8F83\u5DEE"}));
		comboBox.setBounds(230, 261, 169, 24);
		add(comboBox);
		
		JButton button = new JButton("\u5F00\u59CB\u5206\u6790");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DenLu dl =new DenLu();
				String scv = dl.getId();
				StudentDao sd = new StudentDao();
				String sql="select * from sc where id='"+scv+"'";
				
				double numscore=sd.sum(sql);
				textField.setText(String.valueOf(numscore));
				int ts=sd.tj(sql);
				textField_1.setText(String.valueOf(ts*100));
				textField_2.setText(String.valueOf(ts*100-numscore));
				double diufen=(ts*100-numscore)/ts/100;
				textField_3.setText(String.valueOf(diufen));
				if(diufen<=0.1)
				{
					comboBox.setSelectedIndex(0);
				}
				else if(diufen<=0.4)
				{
					comboBox.setSelectedIndex(1);
				}
				else
				{
					comboBox.setSelectedIndex(2);
				}
				
			
			}
		});
		button.setBounds(216, 343, 113, 27);
		add(button);

	}
}
