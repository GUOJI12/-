package view_student_Main;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JButton;

import View_main.DenLu;
import model.ZuoYe;
import model.ZuoYeTai;
import dao.ScDao;
import dao.StudentDao;
import dao.ZuoDao;

import java.awt.Color;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Studentzuoye_select extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	String studentId;
	JComboBox comboBox_1;
	JTextArea textArea;

	/**
	 * Create the panel.
	 */
	public Studentzuoye_select() {
		setLayout(null);
		DenLu dl =new DenLu();
		studentId = dl.getId();
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(368, 34, 163, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u9898\u76EE");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(282, 35, 72, 18);
		add(label);
		
		JLabel label_1 = new JLabel("\u4F5C\u4E1A\u5185\u5BB9");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(69, 64, 93, 18);
		add(label_1);
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(65, 95, 779, 134);
		add(textArea);
		
		JLabel label_2 = new JLabel("\u8BFE\u7A0B");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(101, 364, 72, 24);
		add(label_2);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setBounds(477, 366, 147, 24);
		add(comboBox_1);
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				comboBox_1.removeAllItems();
				ZuoDao zd =new ZuoDao();
				List<ZuoYeTai> list = zd.query_ZuoYeTai("select * from zuoyetijiao where id='"+studentId+"' and courseName='"+comboBox.getSelectedItem()+"' and zhuangtai='δ�ύ'");
				for (int i = 0; i < list.size() - 1; i++) {
		            for (int j = list.size() - 1; j > i; j--) {
		                if (list.get(j).getZuoye().equals(list.get(i).getZuoye())){
		                	list.remove(j);
		                }
		            }
				}
		            for(int d=0;d<list.size();d++){
		            	comboBox_1.addItem(list.get(d).getZuoye());
		            }		
			}
		});
		comboBox.setBounds(164, 366, 163, 24);
		add(comboBox);
		ZuoDao zd =new ZuoDao();
		List<ZuoYeTai> list = zd.query_ZuoYeTai("select * from zuoyetijiao where id='"+studentId+"'");
		for (int i = 0; i < list.size() - 1; i++) {
            for (int j = list.size() - 1; j > i; j--) {
                if (list.get(j).getCourseName().equals(list.get(i).getCourseName())){
                	list.remove(j);
                }
            }
		}
            for(int d=0;d<list.size();d++){
            	comboBox.addItem(list.get(d).getCourseName());
            }		
			
		
		JLabel label_3 = new JLabel("\u4F5C\u4E1A");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(418, 367, 72, 18);
		add(label_3);
		
		
		
		JLabel label_4 = new JLabel("\u5F00\u59CB\u65F6\u95F4");
		label_4.setFont(new Font("����", Font.PLAIN, 18));
		label_4.setBounds(122, 242, 84, 30);
		add(label_4);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(220, 247, 151, 24);
		add(textField_1);
		textField_1.setColumns(10);
		
		JLabel label_5 = new JLabel("\u622A\u6B62\u65F6\u95F4");
		label_5.setFont(new Font("����", Font.PLAIN, 18));
		label_5.setBounds(437, 242, 84, 30);
		add(label_5);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(535, 247, 182, 24);
		add(textField_2);
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					ZuoDao zd =new ZuoDao();
					List<ZuoYeTai> list = zd.query_ZuoYeTai("select * from zuoyetijiao where id='"+studentId+"' and courseName='"+comboBox.getSelectedItem()+"' and zuoye='"+comboBox_1.getSelectedItem()+"'");
					textField.setText(list.get(0).getZuoye());
					textField_1.setText(list.get(0).getStartTime());
					List<ZuoYe> lsit = zd.query("select * from zuoye where courseName='"+comboBox.getSelectedItem()+"' and title='"+comboBox_1.getSelectedItem()+"' and teacherNo='"+list.get(0).getTeacherNo()+"' and statTime='"+list.get(0).getStartTime()+"'");
					textField_2.setText(lsit.get(0).getJiezhiTime());
					textArea.setText(lsit.get(0).getNeiRong());
				}
			    
		});
		btnNewButton.setBounds(679, 365, 126, 27);
		add(btnNewButton);
		
		JButton button = new JButton("\u63D0\u4EA4\u4F5C\u4E1A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ZuoDao zd =new ZuoDao();
				List<ZuoYeTai> list = zd.query_ZuoYeTai("select * from zuoyetijiao where id='"+studentId+"' and courseName='"+comboBox.getSelectedItem()+"' and zuoye='"+comboBox_1.getSelectedItem()+"'");
				List<ZuoYe> lsit = zd.query("select * from zuoye where courseName='"+comboBox.getSelectedItem()+"' and title='"+comboBox_1.getSelectedItem()+"' and teacherNo='"+list.get(0).getTeacherNo()+"' and statTime='"+list.get(0).getStartTime()+"'");
				int i=zd.update(studentId, String.valueOf(comboBox.getSelectedItem()), lsit.get(0).getTeacherNo(), textField_1.getText(), String.valueOf(comboBox_1.getSelectedItem()));
				if(i>0){
			    	JOptionPane.showMessageDialog(null, "�ɹ�");
			    	comboBox_1.removeItem(comboBox_1.getSelectedItem());
			    	if(comboBox_1.getItemCount()==0){
			    		ScDao sd =new ScDao();
			    		int c= sd.update_sc(studentId, lsit.get(0).getTeacherNo(), String.valueOf(comboBox.getSelectedItem()));
			    	    if(c>0){
			    	    	JOptionPane.showMessageDialog(null, "���Ѿ��ɹ�����������ҵ");
			    	    }
			    	}
			    }
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(356, 409, 113, 27);
		add(button);
		
		JLabel lblNewLabel = new JLabel("\u5982\u679C\u5DF2\u7ECF\u5B8C\u6210\u4F5C\u4E1A\u5E76\u4E0A\u4F20\u81F3\u6307\u5B9A\u5730\u70B9\uFF0C\u5373\u53EF\u70B9\u51FB");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(143, 434, 326, 18);
		add(lblNewLabel);
		
		JLabel label_6 = new JLabel("\u672C\u7CFB\u7EDF\u65E0\u6CD5\u4E0A\u4F20\u4F5C\u4E1A\u5185\u5BB9");
		label_6.setForeground(Color.RED);
		label_6.setBounds(477, 434, 170, 18);
		add(label_6);
	}
	
}
