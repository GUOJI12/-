package view_student_Main;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.awt.Color;
import java.util.List;

import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.StudentDao;
import View_main.DenLu;

public class StudentSelectSc_long extends JPanel {
	private JTextField textField;
	private JTable table;
	DefaultTableModel tablemodel;
	String studentId;
	private static double xuefenAll=0;
	/**
	 * Create the panel.
	 */
	public StudentSelectSc_long() {
		xuefenAll=0;
		setLayout(null);
		DenLu dl = new DenLu();
		studentId=dl.getId();
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 75, 787, 276);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�","��ʦ","״̬"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		String sql = "select * from sc,student,teacher where teacher.teacherNo=sc.teacherNo and sc.id=student.id and sc.id=+'"
		+studentId+"' and zhuantai='�����ڿ�'";
		queryAllSc_slong(tablemodel,sql);
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u4F7F\u7528\u660E\u5B66\u5DF2\u9009\u8BFE\u7A0B\u67E5\u8BE2");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 25));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(217, 24, 399, 38);
		add(lblNewLabel);
		
		JLabel label = new JLabel("\u8BFE\u7A0B\u7ED3\u8BFE\u9884\u8BA1\u53EF\u83B7\u5B66\u5206");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(152, 388, 201, 28);
		add(label);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setText(String.valueOf(xuefenAll));
		textField.setBounds(397, 392, 241, 24);
		add(textField);
		textField.setColumns(10);

	}
	public static void queryAllSc_slong(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ScDao sd = new ScDao();
		StudentDao st =new StudentDao();
		CourseDao cd =new CourseDao();
		List<SC> list = sd.query(sql);
		String[] s = new String[10];
		for(int i=0;i<list.size();i++)
		{
			SC sc=list.get(i);			
			s[0]=sc.getId();
			List<Student> lss = st.query("select * from student where id="+"'"+sc.getId()+"'");
			Student sv = lss.get(0);
			s[1]=sv.getName();
			s[2]=sc.getCourseName();
			List<Course> cs = cd.query("select * from course where courseName="+"'"+sc.getCourseName()+"'");
			Course c = cs.get(0);
			s[3]=c.getXingzhi();
			s[4]=String.valueOf(c.getXueshi());
			s[5]=String.valueOf(c.getXuefen());
			xuefenAll=xuefenAll+Double.valueOf(s[5]);
			s[6]=String.valueOf(sc.getScore());
			s[7]=sc.getTeacherName();
			s[8]=sc.getGuake();
			tablemodel.addRow(s);
		}
	}
}
