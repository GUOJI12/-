package view_course;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import view_student.SelectStudent;
import dao.CourseDao;
import dao.StudentDao;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class DeleteCourse extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table;
	private JTextField textField_5;
	DefaultTableModel tablemodel;
	String file_print;
	/**
	 * Create the panel.
	 */
	public DeleteCourse() {
		setLayout(null);
		
		JLabel label = new JLabel("\u8BFE\u7A0B\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(58, 32, 72, 24);
		add(label);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(58, 100, 72, 24);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u6027\u8D28");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(58, 173, 72, 24);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u5B66\u5206");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(509, 32, 72, 24);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u5B66\u65F6");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(509, 100, 72, 24);
		add(label_4);
		
		textField = new JTextField();
		textField.setBounds(165, 34, 191, 24);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(165, 102, 191, 24);
		add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(165, 175, 191, 24);
		add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(595, 34, 191, 24);
		add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(595, 102, 191, 24);
		add(textField_4);
		
		JButton button = new JButton("\u5220\u9664");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CourseDao s =new CourseDao();
				int k=s.deleteId(textField.getText());
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectCourse sst = new SelectCourse();
					String sql ="select * from course";
					sst.queryAllCourse(tablemodel, sql);
					table.validate();//ˢ��
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(402, 33, 72, 27);
		add(button);
		
		JButton button_1 = new JButton("\u5220\u9664");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CourseDao s =new CourseDao();
				int k=s.deleteName(textField_1.getText());
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectCourse sst = new SelectCourse();
					String sql ="select * from course";
					sst.queryAllCourse(tablemodel, sql);
					table.validate();//ˢ��
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(402, 101, 72, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u5220\u9664");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CourseDao s =new CourseDao();
				int k=s.deleteXingzhi(textField_2.getText());
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectCourse sst = new SelectCourse();
					String sql ="select * from course";
					sst.queryAllCourse(tablemodel, sql);
					table.validate();//ˢ��
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			
			
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(402, 174, 72, 27);
		add(button_2);
		
		JButton button_3 = new JButton("\u5220\u9664");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {


				CourseDao s =new CourseDao();
				int k=s.deleteXuefen(Double.valueOf(textField_3.getText()));
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectCourse sst = new SelectCourse();
					String sql ="select * from course";
					sst.queryAllCourse(tablemodel, sql);
					table.validate();//ˢ��
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			
			
			
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(800, 31, 72, 27);
		add(button_3);
		
		JButton button_4 = new JButton("\u5220\u9664");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CourseDao s =new CourseDao();
				int k=s.deleteXueshi(Double.valueOf(textField_4.getText()));
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectCourse sst = new SelectCourse();
					String sql ="select * from course";
					sst.queryAllCourse(tablemodel, sql);
					table.validate();//ˢ��
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}else{
					JOptionPane.showMessageDialog(null,"ʧ��(���������ݹ���)");
				}
			}
		});
		button_4.setFont(new Font("����", Font.PLAIN, 18));
		button_4.setBounds(800, 99, 72, 27);
		add(button_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(25, 258, 845, 228);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss = {"�γ̺�","�γ���","����","ѧ��","ѧʱ"};
		tablemodel.setColumnIdentifiers(ss);
		SelectCourse sst = new SelectCourse();
		String sql ="select * from course";
		sst.queryAllCourse(tablemodel, sql);
		table.validate();//ˢ��
		scrollPane.setViewportView(table);
		
		textField_5 = new JTextField();
		textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
		textField_5.setForeground(Color.RED);
		textField_5.setFont(new Font("����", Font.PLAIN, 18));
		textField_5.setEditable(false);
		textField_5.setBounds(774, 491, 96, 24);
		add(textField_5);
		textField_5.setColumns(10);
		
		JLabel label_5 = new JLabel("\u9009\u62E9\u4F4D\u7F6E");
		label_5.setBounds(120, 227, 72, 18);
		add(label_5);
		
		final JButton btnNewButton = new JButton("\u6587\u4EF6");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					System.out.println("��");
					JFileChooser jfc = new JFileChooser();
					jfc.setDialogTitle("��ѡ���ļ�");
					jfc.showOpenDialog(null);
					jfc.setVisible(true);
					//��ȡ�û���ѡ��Ķ����ļ�
					File file =jfc.getSelectedFile();
					String s = file.toString();
					s=s.replace("\\","\\\\");
					file_print=s;
					btnNewButton.setText(file_print);
				}
		});
		btnNewButton.setBounds(223, 223, 209, 27);
		add(btnNewButton);
		
		JButton button_5 = new JButton("\u5907\u4EFD/\u5BFC\u51FA");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					//���ļ�
					WritableWorkbook book=
					Workbook.createWorkbook(new File(file_print+".xls"));
					//������Ϊ����һҳ���Ĺ�����������0��ʾ���ǵ�һҳ
					WritableSheet sheet=book.createSheet("��һҳ",0);
					//��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
					//�Լ���Ԫ������Ϊtest
					String[] ss = {"�γ̺�","�γ���","����","ѧ��","ѧʱ"};
					for(int i=0;i<ss.length;i++){
						Label label=new Label(i,0,ss[i]);
						sheet.addCell(label);
					}
				
					for(int i=1;i<tablemodel.getRowCount();i++){
						for(int j=0;j<ss.length;j++){
							Label label=new Label(j,i,(String) table.getValueAt(i-1,j));
							//������õĵ�Ԫ�����ӵ���������
							sheet.addCell(label);
						}
					}
					//д�����ݲ��ر��ļ�
					JOptionPane.showMessageDialog(null,"�ɹ�");
					book.write();
					book.close();
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
		});
		button_5.setForeground(Color.RED);
		button_5.setFont(new Font("����", Font.PLAIN, 18));
		button_5.setBounds(486, 223, 209, 27);
		add(button_5);

	}
}
