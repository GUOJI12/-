package view_course;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;

import model.Course;
import model.Student;
import view_student.SelectStudent;
import dao.CourseDao;
import dao.StudentDao;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class AddCourse extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	String stp;
	private JTable table;
	DefaultTableModel tablemodel;

	/**
	 * Create the panel.
	 */
	public AddCourse() {
		setLayout(null);
		
		JLabel label = new JLabel("\u8BFE\u7A0B\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(47, 24, 68, 27);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(129, 27, 190, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(47, 85, 68, 27);
		add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(129, 88, 190, 24);
		add(textField_1);
		
		JLabel label_2 = new JLabel("\u6027\u8D28");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(474, 24, 68, 27);
		add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(566, 27, 190, 24);
		add(textField_2);
		
		JLabel label_3 = new JLabel("\u5B66\u5206");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(474, 91, 68, 27);
		add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(566, 88, 190, 24);
		add(textField_3);
		
		JLabel label_4 = new JLabel("\u5B66\u65F6");
		label_4.setFont(new Font("����", Font.PLAIN, 18));
		label_4.setBounds(47, 151, 68, 27);
		add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(129, 154, 190, 24);
		add(textField_4);
		
		JButton button = new JButton("\u5BFC\u5165\u6DFB\u52A0");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("��");
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("��ѡ���ļ�");
				jfc.showOpenDialog(null);
				jfc.setVisible(true);
				//��ȡ�û���ѡ��Ķ����ļ�
				File file =jfc.getSelectedFile();
				String s1 = file.toString();
				s1=s1.replace("\\","\\\\");
				stp=s1;
			File file1 = new File(stp);
			int k=0;
			int s2=0;
			try {	
				String[][] add = readColumn(file, 5);
				for(int i=1;i<add.length;i++){
					    CourseDao sd = new CourseDao();
					    Course s = new Course();
					    s.setCourseID(add[i][0]);
					    s.setCourseName(add[i][1]);
					    s.setXingzhi(add[i][2]);
					    s.setXuefen(Double.valueOf(add[i][3]));
					    s.setXueshi(Double.valueOf(add[i][4]));
					    k=sd.add(s);
						if(k>0){
							s2=k;
						}
					}
					
				} 
				 catch (Exception e) {
					 e.printStackTrace();
				}
			if(s2>0){
				JOptionPane.showMessageDialog(null,"�ɹ������ܲ����������������޷������ӣ�");
				SelectCourse sst = new SelectCourse();
				String sql = "select * from course";
				sst.queryAllCourse(tablemodel, sql);
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
			else{
				JOptionPane.showMessageDialog(null,"ʧ�ܣ����������޷������ӣ�");
			}
			}
		});
		button.setForeground(Color.RED);
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(47, 211, 113, 27);
		add(button);
		
		JButton button_1 = new JButton("\u786E\u8BA4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int k=0;
				CourseDao sd = new CourseDao();
			    Course s = new Course();
			    s.setCourseID(textField.getText());
			    s.setCourseName(textField_1.getText());
			    s.setXingzhi(textField_2.getText());
			    s.setXuefen(Double.valueOf(textField_3.getText()));
			    s.setXueshi(Double.valueOf(textField_4.getText()));
			    k=sd.add(s);
			    if(k>0){
			    	JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectCourse sst = new SelectCourse();
					String sql = "select * from course";
					sst.queryAllCourse(tablemodel, sql);
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			    }
			    else{
			    	JOptionPane.showMessageDialog(null,"ʧ��");
			    }
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(411, 211, 113, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u91CD\u7F6E");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(714, 211, 113, 27);
		add(button_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(33, 289, 813, 196);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss = {"�γ̺�","�γ���","����","ѧ��","ѧʱ"};
		tablemodel.setColumnIdentifiers(ss);
		SelectCourse sst = new SelectCourse();
		String sql = "select * from course";
		sst.queryAllCourse(tablemodel, sql);
		table.validate();//ˢ��
		scrollPane.setViewportView(table);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("����", Font.PLAIN, 18));
		textField_5.setForeground(Color.RED);
		textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
		textField_5.setEditable(false);
		textField_5.setBounds(744, 491, 102, 24);
		add(textField_5);
		textField_5.setColumns(10);
	}
	public static String[][] readColumn(File file, int index) throws Exception {
		InputStream inputStream = new FileInputStream(file.getAbsoluteFile());

		// �½�����ȡ������
		Workbook workbook = Workbook.getWorkbook(inputStream);

		// ��ȡ��������index��0��ʼ��0��ӦSheet1
		Sheet sheet = workbook.getSheet(0);

		// ��ȡExcel����
		int rows = sheet.getRows();

		// ��ȡExcel����
		int columns = sheet.getColumns();
		String[][] s = new String[rows][index];
		for (int i = 1; i < rows; i++) {
			// ��ȡ��Ԫ��
			for(int j=0;j<index;j++){
				Cell cell = sheet.getCell(j, i);
				// ��ȡ��Ԫ������
				s[i][j]=cell.getContents();
			}
		}
		return s;
	}
}
