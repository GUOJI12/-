package view_course;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;

import java.awt.Color;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.CourseDao;
import model.Course;
import view_student.SelectStudent;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateCourse extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTable table;
	String courseID;
	String courseName;
	String xingzhi;
	double xuefen;
	double xueshi;
	DefaultTableModel tablemodel;
	/**
	 * Create the panel.
	 */
	public UpdateCourse() {
		setLayout(null);
		
		JLabel label = new JLabel("\u8BFE\u7A0B\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(62, 42, 68, 29);
		add(label);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(62, 113, 68, 29);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u6027\u8D28");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(62, 188, 68, 29);
		add(label_2);
		
		JLabel label_3 = new JLabel("\u5B66\u5206");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(515, 42, 68, 29);
		add(label_3);
		
		JLabel label_4 = new JLabel("\u5B66\u65F6");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(515, 113, 68, 29);
		add(label_4);
		
		textField = new JTextField();
		textField.setBounds(167, 46, 191, 24);
		add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(167, 117, 191, 24);
		add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(167, 192, 191, 24);
		add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(581, 46, 191, 24);
		add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(581, 117, 191, 24);
		add(textField_4);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!textField.getText().equals(courseID)){
					JOptionPane.showMessageDialog(null,"�γ̺��޷��޸ģ������޸�����ϵУ��");
				}
				Course c = new Course();
				CourseDao cd = new CourseDao();
				c.setCourseID(textField.getText());
				c.setCourseName(textField_1.getText());
				c.setXingzhi(textField_2.getText());
				c.setXuefen(Double.valueOf(textField_3.getText()));
				c.setXueshi(Double.valueOf(textField_4.getText()));
				int k=cd.update(c);
				if(k>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					SelectCourse sst = new SelectCourse();
					String sql ="select * from course";
					sst.queryAllCourse(tablemodel, sql);
					table.validate();//ˢ��
					textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
				}
				else{
					JOptionPane.showMessageDialog(null,"ʧ��");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(350, 243, 113, 27);
		add(button);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 314, 818, 164);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss = {"�γ̺�","�γ���","����","ѧ��","ѧʱ"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		SelectCourse sst = new SelectCourse();
		String sql ="select * from course";
		sst.queryAllCourse(tablemodel, sql);
		table.validate();//ˢ��
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int count = table.getSelectedRow();//��ȡ��������к�
				courseID = (String) table.getValueAt(count,0);
				courseName =  (String) table.getValueAt(count,1);
				xingzhi =  (String) table.getValueAt(count,2);
				xuefen = Double.valueOf((String) table.getValueAt(count,3));
				xueshi =Double.valueOf((String) table.getValueAt(count,4));
				textField.setText(courseID);
				textField_1.setText(courseName);
				textField_2.setText(xingzhi);
				textField_3.setText(String.valueOf(xuefen));
				textField_4.setText(String.valueOf(xueshi));
			}
		});
		scrollPane.setViewportView(table);
		
		textField_5 = new JTextField();
		textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
		textField_5.setForeground(Color.RED);
		textField_5.setEditable(false);
		textField_5.setFont(new Font("����", Font.PLAIN, 18));
		textField_5.setBounds(749, 477, 96, 24);
		add(textField_5);
		textField_5.setColumns(10);
		
		JButton button_1 = new JButton("\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				SelectCourse sst = new SelectCourse();
				
				String sql ="select * from course where courseID="+"'"+textField.getText()+"'";
				sst.queryAllCourse(tablemodel, sql);
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(386, 45, 77, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u5168\u90E8\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				SelectCourse sst = new SelectCourse();
				String sql ="select * from course";
				sst.queryAllCourse(tablemodel, sql);
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"����¼");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(606, 245, 113, 27);
		add(button_2);

	}
}
