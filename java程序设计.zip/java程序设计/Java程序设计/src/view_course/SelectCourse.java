package view_course;

import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Course;
import model.Student;
import dao.CourseDao;
import dao.StudentDao;

import java.awt.Color;
import java.util.List;

public class SelectCourse extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTable table;
	DefaultTableModel tablemodel;

	/**
	 * Create the panel.
	 */
	public SelectCourse() {
		setLayout(null);
		
		JButton button = new JButton("\u5168\u90E8\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				queryAllCourse(tablemodel, "select * from course");
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(384, 13, 113, 27);
		add(button);
		
		JLabel label = new JLabel("\u8BFE\u7A0B\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(188, 55, 65, 27);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(313, 58, 259, 24);
		add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("\u6309\u8BFE\u7A0B\u53F7\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from course where courseId="+textField.getText();
				queryAllCourse(tablemodel,sql);
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.setBounds(645, 55, 148, 27);
		add(btnNewButton);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u540D");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(188, 95, 65, 27);
		add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(313, 95, 259, 24);
		add(textField_1);
		
		JButton button_1 = new JButton("\u6309\u8BFE\u7A0B\u540D\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from course where courseName="+"'"+textField_1.getText()+"'";
				queryAllCourse(tablemodel,sql);
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(645, 92, 148, 27);
		add(button_1);
		
		JLabel label_2 = new JLabel("\u6027\u8D28");
		label_2.setFont(new Font("����", Font.PLAIN, 20));
		label_2.setBounds(188, 132, 65, 27);
		add(label_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(313, 132, 259, 24);
		add(textField_2);
		
		JButton button_2 = new JButton("\u6309\u6027\u8D28\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from course where xingzhi="+"'"+textField_2.getText()+"'";
				queryAllCourse(tablemodel,sql);
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(645, 132, 148, 27);
		add(button_2);
		
		JLabel label_3 = new JLabel("\u5B66\u5206");
		label_3.setFont(new Font("����", Font.PLAIN, 20));
		label_3.setBounds(188, 172, 65, 27);
		add(label_3);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(313, 175, 259, 24);
		add(textField_3);
		
		JButton button_3 = new JButton("\u6309\u5B66\u5206\u67E5\u8BE2");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from course where xuefen="+Double.valueOf(textField_3.getText());
				queryAllCourse(tablemodel,sql);
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(645, 172, 148, 27);
		add(button_3);
		
		JLabel label_4 = new JLabel("\u5B66\u65F6");
		label_4.setFont(new Font("����", Font.PLAIN, 20));
		label_4.setBounds(188, 212, 65, 27);
		add(label_4);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(313, 215, 259, 24);
		add(textField_4);
		
		JButton button_4 = new JButton("\u6309\u5B66\u65F6\u67E5\u8BE2");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				table.validate();//ˢ��
				String sql = "select * from course where xueshi="+Double.valueOf(textField_4.getText());
				queryAllCourse(tablemodel,sql);
				table.validate();//ˢ��
				textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
			}
		});
		button_4.setFont(new Font("����", Font.PLAIN, 18));
		button_4.setBounds(645, 212, 148, 27);
		add(button_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 263, 816, 211);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		tablemodel.setRowCount(0);//������е�ԭ������
		String[] ss = {"�γ̺�","�γ���","����","ѧ��","ѧʱ"};
		tablemodel.setColumnIdentifiers(ss);
		table.validate();//ˢ��
		scrollPane.setViewportView(table);
		
		textField_5 = new JTextField();
		textField_5.setText("��"+String.valueOf(tablemodel.getRowCount())+"��¼");
		textField_5.setForeground(Color.RED);
		textField_5.setFont(new Font("����", Font.PLAIN, 18));
		textField_5.setEditable(false);
		textField_5.setBounds(768, 473, 86, 24);
		add(textField_5);
		textField_5.setColumns(10);

	}
	public static void queryAllCourse(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		CourseDao sd = new CourseDao();
		List<Course> list = sd.query(sql);
		String[] s = new String[7];
		for(int i=0;i<list.size();i++)
		{
			Course course=list.get(i);			
			s[0]=course.getCourseID();
			s[1]=course.getCourseName();
			s[2]=course.getXingzhi();
			s[3]=String.valueOf(course.getXuefen());
			s[4]=String.valueOf(course.getXueshi());
			tablemodel.addRow(s);
		}
	}

}
