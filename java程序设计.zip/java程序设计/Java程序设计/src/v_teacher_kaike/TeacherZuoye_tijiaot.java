package v_teacher_kaike;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;

import java.awt.Font;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import View_main.DenLu;
import model.Student;
import model.ZuoYe;
import model.ZuoYeTai;
import dao.ScDao;
import dao.StudentDao;
import dao.ZuoDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;

public class TeacherZuoye_tijiaot extends JPanel {
	private JTable table;
	DefaultTableModel tablemodel;
	static String teacherNo;
	JComboBox comboBox_1,comboBox_2;
	private JTextField textField;
	/**
	 * Create the panel.
	 */
	public TeacherZuoye_tijiaot() {
		setLayout(null);
		DenLu dl = new DenLu();
		teacherNo=dl.getId();
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(43, 164, 794, 241);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�γ���","�༶","��ҵ","��ҵ�ύ״̬","��ֹʱ��"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		table.validate();
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("\u4F5C\u4E1A");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(162, 59, 45, 21);
		add(label);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(162, 13, 45, 21);
		add(label_1);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u8BF7\u9009\u62E9"}));
		comboBox.setBounds(221, 13, 241, 24);
		add(comboBox);
		ZuoDao sc =new ZuoDao();
		String sql ="select * from zuoye where teacherNo='"+teacherNo+"'";
		List<ZuoYe> ls = sc.query(sql);
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox.addItem(ls.get(d).getCourseName());
            }		
		
		comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"\u8BF7\u9009\u62E9"}));
		comboBox_1.setBounds(221, 59, 241, 24);
		add(comboBox_1);
		ZuoDao sc1 =new ZuoDao();
		String sql1 ="select * from zuoye where teacherNo='"+teacherNo+"'";
		List<ZuoYe> ls1 = sc.query(sql);
		for (int i = 0; i < ls1.size() - 1; i++) {
            for (int j = ls1.size() - 1; j > i; j--) {
                if (ls1.get(j).getTitle().equals(ls1.get(i).getTitle())) {
                	ls1.remove(j);
                }
            }
		}
            for(int d=0;d<ls1.size();d++){
            	comboBox_1.addItem(ls1.get(d).getTitle());
            }		
		
		JButton button = new JButton("\u67E5\u8BE2\uFF08\u672A\u63D0\u4EA4\uFF09");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(comboBox_1.getSelectedItem().equals("��ѡ��")&&comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao where courseName='"+String.valueOf(comboBox.getSelectedItem())+"' and zhuangtai='δ�ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox.getSelectedItem().equals("��ѡ��")&&comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao where zuoye='"+comboBox_1.getSelectedItem()+"' and zhuangtai='δ�ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox.getSelectedItem().equals("��ѡ��")&&comboBox_1.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and zhuangtai='δ�ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao where courseName='"+String.valueOf(comboBox.getSelectedItem())+"' and zuoye='"+comboBox_1.getSelectedItem()+"' and zhuangtai='δ�ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox_1.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and courseName='"+comboBox.getSelectedItem()+"' and zhuangtai='δ�ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and zuoye='"+comboBox_1.getSelectedItem()+"' and zhuangtai='δ�ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(!comboBox.getSelectedItem().equals("��ѡ��")&&!comboBox_1.getSelectedItem().equals("��ѡ��")&&!comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and zuoye='"+comboBox_1.getSelectedItem()+"' and courseName='"+comboBox.getSelectedItem()+"' and zhuangtai='δ�ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else{
					JOptionPane.showMessageDialog(null, "��ѡ��");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(543, 24, 210, 27);
		add(button);
		
		JLabel label_2 = new JLabel("\u73ED\u7EA7");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(162, 109, 45, 21);
		add(label_2);
		
		comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"\u8BF7\u9009\u62E9"}));
		comboBox_2.setBounds(221, 109, 241, 24);
		add(comboBox_2);
		ZuoDao sc12 =new ZuoDao();
		String sql12 ="select * from zuoye where teacherNo='"+teacherNo+"'";
		List<ZuoYe> ls12 = sc.query(sql);
		for (int i = 0; i < ls12.size() - 1; i++) {
            for (int j = ls12.size() - 1; j > i; j--) {
                if (ls12.get(j).getBanji().equals(ls12.get(i).getBanji())) {
                	ls12.remove(j);
                }
            }
		}
            for(int d=0;d<ls12.size();d++){
            	comboBox_2.addItem(ls12.get(d).getBanji());
            }		
		
		
		JButton button_1 = new JButton("\u67E5\u8BE2\uFF08\u5DF2\u63D0\u4EA4\uFF09");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(comboBox_1.getSelectedItem().equals("��ѡ��")&&comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao where courseName='"+String.valueOf(comboBox.getSelectedItem())+"' and zhuangtai='���ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				if(comboBox.getSelectedItem().equals("��ѡ��")&&comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao where zuoye='"+comboBox_1.getSelectedItem()+"' and zhuangtai='���ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				if(comboBox.getSelectedItem().equals("��ѡ��")&&comboBox_1.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and zhuangtai='���ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao where courseName='"+String.valueOf(comboBox.getSelectedItem())+"' and zuoye='"+comboBox_1.getSelectedItem()+"' and zhuangtai='���ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox_1.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and courseName='"+comboBox.getSelectedItem()+"' and zhuangtai='���ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and zuoye='"+comboBox_1.getSelectedItem()+"' and zhuangtai='���ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(!comboBox.getSelectedItem().equals("��ѡ��")&&!comboBox_1.getSelectedItem().equals("��ѡ��")&&!comboBox_2.getSelectedItem().equals("��ѡ��")){
					tablemodel.setRowCount(0);
					queryAllSc_zy(tablemodel, "select * from zuoyetijiao,student where student.id=zuoyetijiao.id and student.banji='"+comboBox_2.getSelectedItem()+"' and zuoye='"+comboBox_1.getSelectedItem()+"' and courseName='"+comboBox.getSelectedItem()+"' and zhuangtai='���ύ'");
					table.validate();
					textField.setText("��"+tablemodel.getRowCount()+"��¼");
				}
				else if(comboBox.getSelectedItem().equals("��ѡ��")&&comboBox_1.getSelectedItem().equals("��ѡ��")&&comboBox_2.getSelectedItem().equals("��ѡ��")){
					JOptionPane.showMessageDialog(null, "��ѡ��");
				}
			
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(543, 79, 210, 27);
		add(button_1);
		
		textField = new JTextField();
		textField.setText("��"+tablemodel.getRowCount()+"��¼");
		textField.setEditable(false);
		textField.setBounds(751, 403, 86, 24);
		add(textField);
		textField.setColumns(10);

	}
	public static void queryAllSc_zy(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ZuoDao zd =new ZuoDao();
		List<ZuoYeTai> list = zd.query_ZuoYeTai(sql);
		StudentDao sd =new StudentDao();
		String[] s = new String[7];
		for(int i=0;i<list.size();i++){
			ZuoYeTai zt = list.get(i);
			s[0]=zt.getId();
			List<Student> ls = sd.query("select * from student where id='"+s[0]+"'");
			Student ss= ls.get(0);
			s[1] = ss.getName();
			s[2] = zt.getCourseName();
			s[3] = ss.getBanji();
			s[4] = zt.getZuoye();
			s[5] = zt.getZhuangtai();
			List<ZuoYe> ls1 = zd.query("select * from zuoye where statTime='"+zt.getStartTime()+"' and teacherNo='"+teacherNo+"' and courseName='"+zt.getCourseName()+"'");
			ZuoYe zyy = ls1.get(0);
			s[6] = zyy.getJiezhiTime();
			tablemodel.addRow(s);
		}
		
	}
}
