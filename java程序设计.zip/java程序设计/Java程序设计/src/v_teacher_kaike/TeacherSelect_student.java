package v_teacher_kaike;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import View_main.DenLu;
import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.ShokeDao;
import dao.StudentDao;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class TeacherSelect_student extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	DefaultTableModel tablemodel;
	String teacherNo;
	/**
	 * Create the panel.
	 */
	public TeacherSelect_student() {
		setLayout(null);
		DenLu dl =new DenLu();
		teacherNo=dl.getId();
		JButton button = new JButton("\u5168\u90E8\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				String sql = "select * from sc where teacherNo='"+teacherNo+"'";
				queryAllSc_t(tablemodel,sql);
				table.validate();
				textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(331, 13, 113, 27);
		add(button);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(226, 62, 72, 18);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(300, 61, 217, 24);
		add(textField);
		textField.setColumns(10);
		
		JButton button_1 = new JButton("\u6309\u5B66\u53F7\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				String sql = "select * from sc where teacherNo='"+teacherNo+"' and id='"+textField.getText()+"'";
				queryAllSc_t(tablemodel,sql);
				table.validate();
				textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(577, 60, 142, 27);
		add(button_1);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(226, 118, 72, 18);
		add(label_1);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(300, 117, 217, 24);
		add(comboBox);
		CourseDao sc =new CourseDao();
		String sql = "select * from course,shoke where shoke.courseID=course.courseID and shoke.teacherNo='"+teacherNo+"'";
		List<Course> ls = sc.query(sql);
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox.addItem(ls.get(d).getCourseName());
            }		
		JButton button_2 = new JButton("\u6309\u8BFE\u7A0B\u540D\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					tablemodel.setRowCount(0);
					String sql = "select * from sc where teacherNo='"+teacherNo+"' and courseName='"+String.valueOf(comboBox.getSelectedItem())+"'";
					queryAllSc_t(tablemodel,sql);
					table.validate();
					textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(577, 116, 142, 27);
		add(button_2);
		
		JLabel label_2 = new JLabel("\u73ED\u7EA7");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(226, 167, 72, 18);
		add(label_2);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(300, 166, 217, 24);
		add(comboBox_1);
		ShokeDao sd =new ShokeDao();
		String sql1 ="select * from shoke where teacherNo='"+teacherNo+"' and shokeban is NOT NULL";
		String[] ssd = sd.query1(sql1);
		for(int d =0 ;d<ssd.length;d++){
			comboBox_1.addItem(ssd[d]);
		}
		
		JButton button_3 = new JButton("\u6309\u73ED\u7EA7\u67E5\u8BE2");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				String sql = "select * from student,shoke,sc where shoke.shokeban=student.banji and sc.id=student.id and shoke.teacherNo='"+teacherNo+"' and shoke.shokeban='"
				+comboBox_1.getSelectedItem()+"'";
				System.out.println(sql);
				queryAllSc_t(tablemodel,sql);
				table.validate();
				textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
		
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(577, 165, 142, 27);
		add(button_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(32, 237, 798, 235);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		table.validate();
		scrollPane.setViewportView(table);
		
		textField_1 = new JTextField();
		textField_1.setForeground(Color.RED);
		textField_1.setFont(new Font("����", Font.PLAIN, 18));
		textField_1.setText("��"+tablemodel.getRowCount()+"��¼");
		textField_1.setEditable(false);
		textField_1.setBounds(744, 473, 86, 24);
		add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("\u5BFC\u51FA\u8868\u683C\u5185\u5BB9");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null,"��ѡ���ļ�");
				System.out.println("��");
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("��ѡ���ļ�");
				jfc.showOpenDialog(null);
				jfc.setVisible(true);
				//��ȡ�û���ѡ��Ķ����ļ�
				File file =jfc.getSelectedFile();
				String s = file.toString();
				s=s.replace("\\","\\\\");
				String file_print;
				file_print=s;
				try
				{
					//���ļ�
					WritableWorkbook book=
					Workbook.createWorkbook(new File(file_print+".xls"));
					//������Ϊ����һҳ���Ĺ�����������0��ʾ���ǵ�һҳ
					WritableSheet sheet=book.createSheet("��һҳ",0);
					//��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
					//�Լ���Ԫ������Ϊtest
					String[] ss ={"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�"};
					for(int i=0;i<ss.length;i++){
						Label label=new Label(i,0,ss[i]);
						sheet.addCell(label);
					}
				
					for(int i=1;i<tablemodel.getRowCount()+1;i++){
						for(int j=0;j<ss.length;j++){
							Label label=new Label(j,i,(String) table.getValueAt(i-1,j));
							//������õĵ�Ԫ�����ӵ���������
							sheet.addCell(label);
						}
					}
					//д�����ݲ��ر��ļ�
					JOptionPane.showMessageDialog(null,"�ɹ�");
					book.write();
					book.close();
				}catch(Exception e)
				{
					System.out.println(e);
				}
			
				
			}
		});
		btnNewButton.setBounds(577, 13, 142, 27);
		add(btnNewButton);
		
		JLabel label_3 = new JLabel("*\u6CE8:\u5982\u9700\u5168\u90E8\u5BFC\u51FA\uFF0C\u9700\u70B9\u51FB\u5168\u90E8\u67E5\u8BE2");
		label_3.setForeground(Color.RED);
		label_3.setBounds(543, 39, 257, 18);
		add(label_3);
	}
	public static void queryAllSc_t(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ScDao sd = new ScDao();
		StudentDao st =new StudentDao();
		CourseDao cd =new CourseDao();
		List<SC> list = sd.query1(sql);
		String[] s = new String[8];
		for(int i=0;i<list.size();i++)
		{
			SC sc=list.get(i);			
			s[0]=sc.getId();
			List<Student> lss = st.query("select * from student where id="+"'"+sc.getId()+"'");
			Student sv = lss.get(0);
			s[1]=sv.getName();
			s[2]=sc.getCourseName();
			List<Course> cs = cd.query("select * from course where courseName="+"'"+sc.getCourseName()+"'");
			Course c = cs.get(0);
			s[3]=c.getXingzhi();
			s[4]=String.valueOf(c.getXueshi());
			s[5]=String.valueOf(c.getXuefen());
			s[6]=String.valueOf(sc.getScore());
			tablemodel.addRow(s);
		}
	}
}
