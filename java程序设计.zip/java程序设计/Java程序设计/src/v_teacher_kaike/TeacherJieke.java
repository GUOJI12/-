package v_teacher_kaike;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import View_main.DenLu;
import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.ShokeDao;
import dao.StudentDao;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class TeacherJieke extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	String ter;

	/**
	 * Create the panel.
	 */
	public TeacherJieke() {
		setLayout(null);
		DenLu dl =new DenLu();
		ter=dl.getId();
		JLabel label = new JLabel("\u5DE5\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 20));
		label.setBounds(239, 80, 85, 28);
		add(label);
		
		textField = new JTextField();
		textField.setBounds(338, 82, 217, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u53F7");
		label_1.setFont(new Font("����", Font.PLAIN, 20));
		label_1.setBounds(239, 159, 85, 28);
		add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(338, 161, 217, 24);
		add(textField_1);
		
		JButton btnNewButton = new JButton("\u7ED3\u8BFE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CourseDao cd = new CourseDao();
				String sql ="select * from course where courseID="+"'"+textField_1.getText()+"'";
				List<Course> lco = cd.query(sql);
				Course c =lco.get(0);
				String sql_sc = "select * from sc,teacher where sc.teacherNo=teacher.teacherNo and sc.teacherNo='"+ter+"' and sc.courseName='"+c.getCourseName()+"'";
				queryAllSc_beifen(sql_sc);
				ShokeDao skd = new ShokeDao();
				int i = skd.deleteID(textField.getText(),textField_1.getText());
				ScDao sd = new ScDao();
				int k=sd.deleteShoke(textField.getText(),c.getCourseName());
				c.getCourseName();
				if(i>0&&k>0){
					JOptionPane.showMessageDialog(null,"��γɹ���ף���ż����");
				}
				else{
					JOptionPane.showMessageDialog(null,"ʧ��");
				}
			}
		});
		btnNewButton.setBounds(355, 282, 113, 27);
		add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("*\u6CE8:\u7ED3\u8BFE\u524D\u8BF7\u5148\u5230\u67E5\u8BE2\u6210\u7EE9\u5904\u5BFC\u51FA\u672C\u8BFE\u7A0B\u5B66\u751F\u7684\u4FE1\u606F");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBounds(256, 314, 404, 18);
		add(lblNewLabel);
		
		JLabel label_2 = new JLabel("*\u6CE8:\u7ED3\u8BFE\u540E\uFF0C\u4F1A\u81EA\u52A8\u5907\u4EFD\u5B66\u751F\u4FE1\u606F\u5230\u7BA1\u7406\u5458\u5904\uFF0C\u5907\u67E5");
		label_2.setForeground(Color.RED);
		label_2.setBounds(256, 345, 404, 18);
		add(label_2);

	}
	public static void queryAllSc_beifen(String sql){
		ScDao sd = new ScDao();
		StudentDao st =new StudentDao();
		CourseDao cd =new CourseDao();
		List<SC> list = sd.query(sql);
		String[] s = new String[8];
			try
			{
				//���ļ�
				WritableWorkbook book=
				Workbook.createWorkbook(new File("C:\\Users\\GUOJI\\Desktop\\students\\����1.xls"));
				//������Ϊ����һҳ���Ĺ�����������0��ʾ���ǵ�һҳ
				WritableSheet sheet=book.createSheet("��һҳ",0);
				//��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
				//�Լ���Ԫ������Ϊtest
				String[] ss = {"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�","��ʦ��"};
				for(int i=0;i<ss.length;i++){
					Label label=new Label(i,0,ss[i]);
					sheet.addCell(label);
				}
				for(int i=0;i<list.size();i++)
				{
					SC sc=list.get(i);			
					s[0]=sc.getId();
					List<Student> lss = st.query("select * from student where id="+"'"+sc.getId()+"'");
					Student sv = lss.get(0);
					s[1]=sv.getName();
					s[2]=sc.getCourseName();
					List<Course> cs = cd.query("select * from course where courseName="+"'"+sc.getCourseName()+"'");
					Course c = cs.get(0);
					s[3]=c.getXingzhi();
					s[4]=String.valueOf(c.getXueshi());
					s[5]=String.valueOf(c.getXuefen());
					s[6]=String.valueOf(sc.getScore());
					s[7]=sc.getTeacherName();
					for(int j=0;j<ss.length;j++){
						Label label=new Label(j,i+1,s[j]);
						//������õĵ�Ԫ�����ӵ���������
						sheet.addCell(label);
					}
				}
				//д�����ݲ��ر��ļ�
				JOptionPane.showMessageDialog(null,"���ݳɹ�");
				book.write();
				book.close();
			}catch(Exception e)
			{
				System.out.println(e);
			}
	}

}
