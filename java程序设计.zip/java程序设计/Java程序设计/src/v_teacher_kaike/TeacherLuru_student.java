package v_teacher_kaike;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;

import java.awt.Color;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import View_main.DenLu;
import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.StudentDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TeacherLuru_student extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	JComboBox comboBox_1,comboBox_2;
	String teacherNo;
	DefaultTableModel tablemodel;
	/**
	 * Create the panel.
	 */
	public TeacherLuru_student() {
		setLayout(null);
		DenLu dl =new DenLu();
		teacherNo = dl.getId();
		JLabel lblNewLabel = new JLabel("\u8BFE\u7A0B");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 18));
		lblNewLabel.setBounds(233, 23, 48, 25);
		add(lblNewLabel);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(318, 25, 215, 24);
		add(comboBox);
		CourseDao sc =new CourseDao();
		String sql = "select * from course,shoke where shoke.courseID=course.courseID and shoke.teacherNo='"+teacherNo+"'";
		List<Course> ls = sc.query(sql);
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox.addItem(ls.get(d).getCourseName());
            }	
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				comboBox_1.removeAllItems();
				comboBox_2.removeAllItems();
				String sql = "select * from sc where teacherNo='"+teacherNo+"' and courseName='"+String.valueOf(comboBox.getSelectedItem())+"'";
				queryAllSc_t(tablemodel,sql);
				table.validate();
				ScDao sd =new ScDao();
				StudentDao std = new StudentDao();
				String sql1 ="select * from sc where courseName='"+String.valueOf(comboBox.getSelectedItem())+"'";
				List<SC> sc =sd.query1(sql1);
				for(int i=0;i<sc.size();i++){
					SC s = sc.get(i);
					String sql_s = "select * from student where id='"+s.getId()+"'";
					List<Student> lsst = std.query(sql_s);
					Student stt = lsst.get(0);			
					comboBox_1.addItem(s.getId());
					comboBox_2.addItem(stt.getName());
				}
				textField_2.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(588, 24, 113, 27);
		add(button);
		
		JLabel label = new JLabel("\u5B66\u53F7");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(76, 95, 72, 25);
		add(label);
		
		comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ScDao sd =new ScDao();
				String sql1 ="select * from sc where id='"+String.valueOf(comboBox_1.getSelectedItem())+"'";
				List<SC> sc =sd.query1(sql1);
				textField.setText(String.valueOf(sc.get(0).getScore()));
			}
		});
		comboBox_1.setBounds(162, 97, 171, 24);
		add(comboBox_1);
		
		
		
		JLabel label_1 = new JLabel("\u5F55\u5165\u6210\u7EE9");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(445, 95, 88, 25);
		add(label_1);
		
		textField = new JTextField();
		textField.setBounds(549, 97, 184, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_2 = new JLabel("\u59D3\u540D");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(76, 168, 72, 25);
		add(label_2);
		
		comboBox_2 = new JComboBox();
		comboBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ScDao sd =new ScDao();
				StudentDao sdd = new StudentDao();
				String sql ="select * from student where name='"+String.valueOf(comboBox_2.getSelectedItem())+"'";
				List<Student> lstt = sdd.query(sql);
				String sql1 ="select * from sc where id='"+lstt.get(0).getId()+"'";
				List<SC> sc =sd.query1(sql1);
				textField_1.setText(String.valueOf(sc.get(0).getScore()));
			}
		});
		comboBox_2.setBounds(162, 170, 171, 24);
		add(comboBox_2);
		
		JLabel label_3 = new JLabel("\u5F55\u5165\u6210\u7EE9");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(445, 173, 88, 25);
		add(label_3);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(549, 170, 184, 24);
		add(textField_1);
		
		JButton button_1 = new JButton("\u786E\u8BA4");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ScDao sd =new ScDao();
				SC s =new SC();
				s.setId(String.valueOf(comboBox_1.getSelectedItem()));
				s.setScore(Double.valueOf(textField.getText()));
				s.setCourseName(String.valueOf(comboBox.getSelectedItem()));
				int i = sd.update_ID(s);
				if(i>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					if(Double.valueOf(textField.getText())>=60){
						ScDao sd1 =new ScDao();
						SC s1 = new SC();
						s1.setId(String.valueOf(comboBox_1.getSelectedItem()));
						s1.setCourseName(String.valueOf(comboBox.getSelectedItem()));
						int j =sd.update1(s1);
					}
					tablemodel.setRowCount(0);
					String sql = "select * from sc where teacherNo='"+teacherNo+"' and courseName='"+String.valueOf(comboBox.getSelectedItem())+"'";
					queryAllSc_t(tablemodel,sql);
					table.validate();
					StudentDao std =new StudentDao();
					String sql_s = "select * from student where id='"+String.valueOf(comboBox_1.getSelectedItem())+"'";
					List<Student> lsst = std.query(sql_s);
					Student stt = lsst.get(0);	
					comboBox_2.removeItem(stt.getName());
					comboBox_1.removeItem(String.valueOf(comboBox_1.getSelectedItem()));		
				}
				else{
					JOptionPane.showMessageDialog(null,"δ֪������ϵ����Ա");
				}
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(765, 96, 113, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u786E\u8BA4");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ScDao sd =new ScDao();
				SC s =new SC();
				StudentDao s_do = new StudentDao();
				String sql_do ="select * from student where name='"+String.valueOf(comboBox_2.getSelectedItem())+"'";
				List<Student> lsr = s_do.query(sql_do);
				s.setId(lsr.get(0).getId());
				s.setScore(Double.valueOf(textField.getText()));
				s.setCourseName(String.valueOf(comboBox.getSelectedItem()));
				int i = sd.update_ID(s);
				if(i>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
					if(Double.valueOf(textField.getText())>=60){
						ScDao sd1 =new ScDao();
						SC s1 = new SC();
						s1.setId(lsr.get(0).getId());
						s1.setCourseName(String.valueOf(comboBox.getSelectedItem()));
						int j =sd.update1(s1);
					}
					tablemodel.setRowCount(0);
					String sql = "select * from sc where teacherNo='"+teacherNo+"' and courseName='"+String.valueOf(comboBox.getSelectedItem())+"'";
					queryAllSc_t(tablemodel,sql);
					table.validate();
					comboBox_2.removeItem(String.valueOf(comboBox_2.getSelectedItem()));
					comboBox_1.removeItem(lsr.get(0).getId());		
				}
				else{
					JOptionPane.showMessageDialog(null,"δ֪������ϵ����Ա");
				}
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(765, 169, 113, 27);
		add(button_2);
		
		JLabel label_4 = new JLabel("\u53EF\u4EE5\u5B66\u53F7\u5F55\u5165\uFF0C\u4E5F\u53EF\u59D3\u540D\u5F55\u5165");
		label_4.setForeground(Color.RED);
		label_4.setBounds(76, 59, 205, 18);
		add(label_4);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(33, 231, 834, 249);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		table.validate();
		table.setFont(new Font("����", Font.PLAIN, 18));
		scrollPane.setViewportView(table);
		
		textField_2 = new JTextField();
		textField_2.setText("��"+tablemodel.getRowCount()+"��¼");
		textField_2.setForeground(Color.RED);
		textField_2.setFont(new Font("����", Font.PLAIN, 18));
		textField_2.setEditable(false);
		textField_2.setBounds(777, 477, 86, 24);
		add(textField_2);
		textField_2.setColumns(10);

	}
	public static void queryAllSc_t(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ScDao sd = new ScDao();
		StudentDao st =new StudentDao();
		CourseDao cd =new CourseDao();
		List<SC> list = sd.query1(sql);
		String[] s = new String[8];
		for(int i=0;i<list.size();i++)
		{
			SC sc=list.get(i);			
			s[0]=sc.getId();
			List<Student> lss = st.query("select * from student where id="+"'"+sc.getId()+"'");
			Student sv = lss.get(0);
			s[1]=sv.getName();
			s[2]=sc.getCourseName();
			List<Course> cs = cd.query("select * from course where courseName="+"'"+sc.getCourseName()+"'");
			Course c = cs.get(0);
			s[3]=c.getXingzhi();
			s[4]=String.valueOf(c.getXueshi());
			s[5]=String.valueOf(c.getXuefen());
			s[6]=String.valueOf(sc.getScore());
			tablemodel.addRow(s);
		}
	}
}
