package v_teacher_kaike;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import view_student.SelectStudent;
import View_main.DenLu;
import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.ShokeDao;
import dao.StudentDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TeacherKaiKe extends JPanel {
	private JTextField textField;
	private JTable table;
	DefaultTableModel tablemodel;
	String teacherNo;
	JComboBox comboBox_3;
	/**
	 * Create the panel.
	 */
	public TeacherKaiKe() {
		setLayout(null);
		DenLu dl = new DenLu();
		teacherNo = dl.getId();
		JLabel label = new JLabel("\u6B22\u8FCE\u4F7F\u7528\u660E\u8BFE\u5F00\u8BFE\u7CFB\u7EDF");
		label.setForeground(Color.RED);
		label.setFont(new Font("����", Font.PLAIN, 30));
		label.setBounds(277, 13, 326, 35);
		add(label);
		
		JLabel label_1 = new JLabel("\u8BFE\u7A0B\u53F7");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(14, 66, 64, 29);
		add(label_1);
		
		JLabel label_2 = new JLabel("\u8BFE\u7A0B\u540D");
		label_2.setFont(new Font("����", Font.PLAIN, 18));
		label_2.setBounds(14, 128, 64, 29);
		add(label_2);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(92, 68, 200, 29);
		add(comboBox);
		CourseDao sc =new CourseDao();
		List<Course> ls = sc.query("select * from course");
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseID().equals(ls.get(i).getCourseID())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox.addItem(ls.get(d).getCourseID());
            }
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(92, 130, 200, 29);
		add(comboBox_1);
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox_1.addItem(ls.get(d).getCourseName());
            }
		
		JButton button = new JButton("\u67E5\u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				String sql = "select * from course where courseID="+"'"+comboBox.getSelectedItem()+"'";
				queryAllCourse(tablemodel,sql);
				table.validate();//ˢ��
				textField.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(320, 67, 113, 27);
		add(button);
		
		JButton button_1 = new JButton("\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);//������е�ԭ������
				String sql = "select * from course where courseName="+"'"+comboBox_1.getSelectedItem()+"'";
				queryAllCourse(tablemodel,sql);
				table.validate();//ˢ��
				textField.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(320, 129, 113, 27);
		add(button_1);
		
		JButton button_2 = new JButton("\u5F00\u8BBE\u8BFE\u7A0B");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ShokeDao skd = new ShokeDao();
				int i=0;
				try {
					i = skd.shokeAdd(teacherNo,String.valueOf(comboBox.getSelectedItem()));
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
				if(i>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
				}
				else{
					JOptionPane.showMessageDialog(null,"�ÿ������ڿΣ������ظ�����");
				}
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(461, 67, 113, 27);
		add(button_2);
		
		JButton button_3 = new JButton("\u5F00\u8BBE\u8BFE\u7A0B");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ShokeDao skd = new ShokeDao();
				int i=0;
				try {
					CourseDao cd =new CourseDao();
					String sql ="select * from course where courseName="+"'"+String.valueOf(comboBox_1.getSelectedItem())+"'";
					List<Course> list = cd.query(sql);
					Course c = list.get(0);;
					i = skd.shokeAdd(teacherNo,c.getCourseID());
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
				if(i>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
				}
				else{
					JOptionPane.showMessageDialog(null,"�ÿ������ڿΣ������ظ�����");
				}
			
			}
		});
		button_3.setFont(new Font("����", Font.PLAIN, 18));
		button_3.setBounds(461, 129, 113, 27);
		add(button_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 246, 832, 221);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		tablemodel.setRowCount(0);//������е�ԭ������
		String[] ss = {"�γ̺�","�γ���","����","ѧ��","ѧʱ"};
		tablemodel.setColumnIdentifiers(ss);
		queryAllCourse(tablemodel,"select * from course");
		table.validate();//ˢ��
		scrollPane.setViewportView(table);
		
		textField = new JTextField();
		textField.setText("��"+tablemodel.getRowCount()+"��¼");
		textField.setForeground(Color.RED);
		textField.setFont(new Font("����", Font.PLAIN, 18));
		textField.setEditable(false);
		textField.setBounds(773, 466, 86, 24);
		add(textField);
		textField.setColumns(10);
		
		JLabel label_3 = new JLabel("\u6388\u8BFE\u73ED");
		label_3.setFont(new Font("����", Font.PLAIN, 18));
		label_3.setBounds(14, 185, 67, 29);
		add(label_3);
		
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(92, 187, 200, 29);
		add(comboBox_2);
		StudentDao sd =new StudentDao();
		List<Student> lst = sd.query("select * from student");
		for (int i = 0; i < lst.size() - 1; i++) {
            for (int j = lst.size() - 1; j > i; j--) {
                if (lst.get(j).getBanji().equals(lst.get(i).getBanji())) {
                	lst.remove(j);
                }
            }
		}
            for(int d=0;d<lst.size();d++){
            	comboBox_2.addItem(lst.get(d).getBanji());
            }

		
		JButton button_5 = new JButton("\u6388\u8BFE");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CourseDao cd =new CourseDao();
				String sql ="select * from course where courseName="+"'"+String.valueOf(comboBox_3.getSelectedItem())+"'";
				List<Course> list = cd.query(sql);
				Course c = list.get(0);;
				ShokeDao skd =new ShokeDao();
				int i=0,l=0;
				try {
					String sql_shoke ="select * from shoke where teacherNo="+"'"+teacherNo+"' and shokeban='"+String.valueOf(comboBox_2.getSelectedItem())+"'";
					if(!skd.query(sql_shoke).equals("")){
						JOptionPane.showMessageDialog(null,"�����п����ڸð��ڿΣ������ظ�����");
						return;
					}
					i = skd.shokeAdd_banji(teacherNo,c.getCourseID(),String.valueOf(comboBox_2.getSelectedItem()));
					StudentDao sd = new StudentDao();
					System.out.println("s");
					String sql1 ="select * from student where banji="+"'"+String.valueOf(comboBox_2.getSelectedItem())+"'"; 
					List<Student> ls = sd.query(sql1);
					ScDao sc = new ScDao();
					for(int k=0;k<ls.size();k++){
						Student s = ls.get(k);
						SC sc1 = new SC();
						sc1.setId(s.getId());
						sc1.setCourseName(String.valueOf(comboBox_3.getSelectedItem()));
						sc1.setTeacherNo(teacherNo);
						sc1.setZhuantai("�����ڿ�");
						l = sc.addSc(sc1);
					}
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
				if(i>0&&l>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
				}
				else{
					JOptionPane.showMessageDialog(null,"�ÿ������ڿΣ������ظ�����");
				}
			}
		});
		button_5.setFont(new Font("����", Font.PLAIN, 18));
		button_5.setBounds(635, 186, 113, 27);
		add(button_5);
		
		JLabel label_4 = new JLabel("*\u6CE8:\u53EF\u9009\u62E9\u6388\u8BFE\u73ED\u7EA7\uFF0C\u4E5F\u53EF\u4E0D\u9009\u62E9");
		label_4.setForeground(Color.RED);
		label_4.setBounds(541, 215, 253, 18);
		add(label_4);
		
		JLabel label_5 = new JLabel("\u8BFE\u7A0B\u540D");
		label_5.setFont(new Font("����", Font.PLAIN, 18));
		label_5.setBounds(320, 185, 64, 29);
		add(label_5);
		
		comboBox_3 = new JComboBox();
		comboBox_3.setBounds(392, 187, 200, 29);
		add(comboBox_3);
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox_3.addItem(ls.get(d).getCourseName());
            }
		
	}
	public static void queryAllCourse(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		CourseDao sd = new CourseDao();
		List<Course> list = sd.query(sql);
		String[] s = new String[7];
		for(int i=0;i<list.size();i++)
		{
			Course course=list.get(i);			
			s[0]=course.getCourseID();
			s[1]=course.getCourseName();
			s[2]=course.getXingzhi();
			s[3]=String.valueOf(course.getXuefen());
			s[4]=String.valueOf(course.getXueshi());
			tablemodel.addRow(s);
		}
	}
}
