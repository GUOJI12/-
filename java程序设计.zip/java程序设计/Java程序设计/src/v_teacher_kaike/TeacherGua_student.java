package v_teacher_kaike;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.Font;
import java.util.List;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;

import View_main.DenLu;
import model.Course;
import model.SC;
import model.Student;
import dao.CourseDao;
import dao.ScDao;
import dao.ShokeDao;
import dao.StudentDao;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TeacherGua_student extends JPanel {
	private JTable table;
	String teacherNo;
	DefaultTableModel tablemodel;
	private JTextField textField;
	/**
	 * Create the panel.
	 */
	public TeacherGua_student() {
		setLayout(null);
		DenLu dl =new DenLu();
		teacherNo=dl.getId();
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 13, 834, 258);
		add(scrollPane);
		
		table = new JTable();
		tablemodel = (DefaultTableModel) table.getModel();
		String[] ss ={"ѧ��","����","�γ���","����","ѧʱ","ѧ��","�ɼ�"};
		tablemodel.setColumnIdentifiers(ss);
		tablemodel.setRowCount(0);
		table.validate();
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("\u4E00\u952E\u6302\u79D1");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int l=0;
				ScDao sd =new ScDao();
				SC s = new SC();
				for(int count=0;count<tablemodel.getRowCount();count++){
					s.setId((String) tablemodel.getValueAt(count,0));
					s.setCourseName((String) tablemodel.getValueAt(count,2));
					l=sd.update(s);
				}
				if(l>0){
					JOptionPane.showMessageDialog(null,"�ɹ�");
				}
			}
		});
		button.setFont(new Font("����", Font.PLAIN, 18));
		button.setBounds(294, 424, 113, 27);
		add(button);
		
		JLabel label = new JLabel("\u8BFE\u7A0B");
		label.setFont(new Font("����", Font.PLAIN, 18));
		label.setBounds(164, 300, 72, 27);
		add(label);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBounds(233, 303, 200, 24);
		add(comboBox);
		CourseDao sc =new CourseDao();
		String sql = "select * from course,shoke where shoke.courseID=course.courseID and shoke.teacherNo='"+teacherNo+"'";
		List<Course> ls = sc.query(sql);
		for (int i = 0; i < ls.size() - 1; i++) {
            for (int j = ls.size() - 1; j > i; j--) {
                if (ls.get(j).getCourseName().equals(ls.get(i).getCourseName())) {
                	ls.remove(j);
                }
            }
		}
            for(int d=0;d<ls.size();d++){
            	comboBox.addItem(ls.get(d).getCourseName());
            }	
		
		
		JButton button_1 = new JButton("\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				String sql = "select * from sc where teacherNo='"+teacherNo+"' and courseName='"
				+String.valueOf(comboBox.getSelectedItem())+"' and score<60";
				queryAllSc_t(tablemodel,sql);
				table.validate();
				table.validate();
				textField.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_1.setFont(new Font("����", Font.PLAIN, 18));
		button_1.setBounds(495, 302, 113, 27);
		add(button_1);
		
		JLabel label_1 = new JLabel("\u73ED\u7EA7");
		label_1.setFont(new Font("����", Font.PLAIN, 18));
		label_1.setBounds(164, 361, 72, 27);
		add(label_1);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(233, 364, 200, 24);
		add(comboBox_1);
		ShokeDao sd =new ShokeDao();
		String sql1 ="select * from shoke where teacherNo='"+teacherNo+"' and shokeban is NOT NULL";
		String[] ssd = sd.query1(sql1);
		for(int d =0 ;d<ssd.length;d++){
			comboBox_1.addItem(ssd[d]);
		}
		
		JButton button_2 = new JButton("\u67E5\u8BE2");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tablemodel.setRowCount(0);
				String sql = "select * from student,shoke,sc where shoke.shokeban=student.banji and sc.id=student.id and shoke.teacherNo='"+teacherNo+"' and shoke.shokeban='"
				+comboBox_1.getSelectedItem()+"' and score<60";
				queryAllSc_t(tablemodel,sql);
				table.validate();
				table.validate();
				textField.setText("��"+tablemodel.getRowCount()+"��¼");
			}
		});
		button_2.setFont(new Font("����", Font.PLAIN, 18));
		button_2.setBounds(495, 363, 113, 27);
		add(button_2);
		
		textField = new JTextField();
		textField.setText("��"+tablemodel.getRowCount()+"��¼");
		textField.setEditable(false);
		textField.setBounds(762, 270, 86, 24);
		add(textField);
		textField.setColumns(10);

	}
	public static void queryAllSc_t(DefaultTableModel tablemodel,String sql){
		tablemodel.setRowCount(0);//���
		ScDao sd = new ScDao();
		StudentDao st =new StudentDao();
		CourseDao cd =new CourseDao();
		List<SC> list = sd.query1(sql);
		String[] s = new String[8];
		for(int i=0;i<list.size();i++)
		{
			SC sc=list.get(i);			
			s[0]=sc.getId();
			List<Student> lss = st.query("select * from student where id="+"'"+sc.getId()+"'");
			Student sv = lss.get(0);
			s[1]=sv.getName();
			s[2]=sc.getCourseName();
			List<Course> cs = cd.query("select * from course where courseName="+"'"+sc.getCourseName()+"'");
			Course c = cs.get(0);
			s[3]=c.getXingzhi();
			s[4]=String.valueOf(c.getXueshi());
			s[5]=String.valueOf(c.getXuefen());
			s[6]=String.valueOf(sc.getScore());
			tablemodel.addRow(s);
		  } 
	 }
}
